package app.notifyios27

import android.app.Activity
import android.graphics.Typeface
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.TextView

class AboutPage : SettingsPage {
    override val title: String = "Giới thiệu"

    override fun build(a: Activity, push: (SettingsPage) -> Unit): View {
        val dark = Prefs.isDark(a)
        val wrap = ViewGroup.LayoutParams.WRAP_CONTENT
        val match = ViewGroup.LayoutParams.MATCH_PARENT
        val b = LinearLayout(a)
        b.orientation = LinearLayout.VERTICAL

        val head = LinearLayout(a)
        head.orientation = LinearLayout.VERTICAL
        head.gravity = Gravity.CENTER_HORIZONTAL
        head.setPadding(0, UiKit.dp(a, 8), 0, UiKit.dp(a, 8))
        val name = TextView(a)
        name.text = "notifyIOS27"
        name.textSize = 26f
        name.typeface = Typeface.DEFAULT_BOLD
        name.setTextColor(UiKit.primary(dark))
        head.addView(name)
        val ver = TextView(a)
        ver.text = "Phiên bản 2.0"
        ver.textSize = 14f
        ver.setTextColor(UiKit.secondary(dark))
        head.addView(ver)
        b.addView(head, LinearLayout.LayoutParams(match, wrap))
        b.addView(SettingsKit.spacer(a, 8))

        val s1 = SettingsKit.section(a, "Tính năng")
        val feat = TextView(a)
        feat.text = "• Trung tâm thông báo kiểu iOS 27 với kính Liquid Glass\n" +
            "• Banner, Dynamic Island, nhắc lại và ghim thông báo\n" +
            "• Focus, tóm tắt, bộ lọc và quy tắc theo từng ứng dụng\n" +
            "• Lịch sử, thống kê, màn hình khóa và widget\n" +
            "• Sao lưu và khôi phục cài đặt"
        feat.textSize = 14.5f
        feat.setTextColor(UiKit.primary(dark))
        feat.setPadding(UiKit.dp(a, 16), UiKit.dp(a, 6), UiKit.dp(a, 16), UiKit.dp(a, 14))
        s1.addView(feat, LinearLayout.LayoutParams(match, wrap))
        b.addView(s1, LinearLayout.LayoutParams(match, wrap))
        b.addView(SettingsKit.spacer(a, 16))

        val s2 = SettingsKit.section(a, "Mẹo")
        val tip = TextView(a)
        tip.text = "Nếu không bật được quyền truy cập thông báo, vào Cài đặt > Ứng dụng > notifyIOS27 > " +
            "menu ba chấm > \"Cho phép cài đặt bị hạn chế\", rồi cấp quyền lại."
        tip.textSize = 14.5f
        tip.setTextColor(UiKit.primary(dark))
        tip.setPadding(UiKit.dp(a, 16), UiKit.dp(a, 6), UiKit.dp(a, 16), UiKit.dp(a, 14))
        s2.addView(tip, LinearLayout.LayoutParams(match, wrap))
        b.addView(s2, LinearLayout.LayoutParams(match, wrap))
        return b
    }
}

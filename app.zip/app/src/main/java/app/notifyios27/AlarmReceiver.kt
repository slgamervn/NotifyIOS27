package app.notifyios27

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class AlarmReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        try {
            val i = intent ?: return
            val c = context.applicationContext
            when (i.action) {
                "app.notifyios27.SNOOZE_FIRE" -> {
                    val key = i.getStringExtra("key")
                    if (key != null) Snooze.fire(c, key)
                }
                "app.notifyios27.SUMMARY_FIRE" -> {
                    Summary.deliverNow(c)
                    Summary.reschedule(c)
                }
            }
        } catch (e: Exception) {
        }
    }
}

package app.notifyios27

import android.content.Context
import android.graphics.drawable.Drawable
import android.util.LruCache

object AppIcons {
    private val icons = LruCache<String, Drawable>(64)
    private val labels = LruCache<String, String>(128)

    fun icon(c: Context, pkg: String): Drawable? {
        val cached = icons.get(pkg)
        if (cached != null) return copyOf(cached)
        val pm = c.applicationContext.packageManager
        val d: Drawable? = try {
            pm.getApplicationIcon(pkg)
        } catch (e: Exception) {
            try { pm.defaultActivityIcon } catch (e2: Exception) { null }
        }
        if (d != null) icons.put(pkg, d)
        return d?.let { copyOf(it) }
    }

    private fun copyOf(d: Drawable): Drawable {
        return try {
            d.constantState?.newDrawable()?.mutate() ?: d
        } catch (e: Exception) {
            d
        }
    }

    @Suppress("DEPRECATION")
    fun label(c: Context, pkg: String): String {
        val cached = labels.get(pkg)
        if (cached != null) return cached
        val pm = c.applicationContext.packageManager
        val l: String = try {
            pm.getApplicationLabel(pm.getApplicationInfo(pkg, 0)).toString()
        } catch (e: Exception) {
            pkg
        }
        labels.put(pkg, l)
        return l
    }
}

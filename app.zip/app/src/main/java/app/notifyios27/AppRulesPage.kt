package app.notifyios27

import android.app.Activity
import android.content.Intent
import android.provider.Settings
import android.text.Editable
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.Switch
import android.widget.TextView
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class AppRulesPage : SettingsPage {
    override val title: String = "Ứng dụng"

    private val refreshers = ArrayList<() -> Unit>()

    override fun build(a: Activity, push: (SettingsPage) -> Unit): View {
        refreshers.clear()
        val dark = Prefs.isDark(a)
        val mp = ViewGroup.LayoutParams.MATCH_PARENT
        val wc = ViewGroup.LayoutParams.WRAP_CONTENT
        val root = LinearLayout(a)
        root.orientation = LinearLayout.VERTICAL

        val search = EditText(a)
        search.hint = "Tìm ứng dụng"
        search.setSingleLine(true)
        search.setTextColor(UiKit.primary(dark))
        search.setHintTextColor(UiKit.secondary(dark))
        val searchBox = SettingsKit.section(a, null)
        val pad = LinearLayout(a)
        pad.setPadding(UiKit.dp(a, 14), UiKit.dp(a, 4), UiKit.dp(a, 14), UiKit.dp(a, 4))
        pad.addView(search, LinearLayout.LayoutParams(mp, wc))
        searchBox.addView(pad, LinearLayout.LayoutParams(mp, wc))
        root.addView(searchBox, LinearLayout.LayoutParams(mp, wc))
        root.addView(SettingsKit.spacer(a, 8))

        val list = SettingsKit.section(a, null)
        root.addView(list, LinearLayout.LayoutParams(mp, wc))

        val apps = n27LauncherPkgs(a).map { Pair(it, Rules.displayName(a, it)) }
            .sortedBy { it.second.lowercase() }
        val searchKeys = ArrayList<Pair<View, () -> String>>()
        val timeFmt = SimpleDateFormat("HH:mm", Locale.getDefault())

        for ((pkg, _) in apps) {
            val item = LinearLayout(a)
            item.orientation = LinearLayout.VERTICAL

            val head = LinearLayout(a)
            head.orientation = LinearLayout.HORIZONTAL
            head.gravity = Gravity.CENTER_VERTICAL
            head.setPadding(UiKit.dp(a, 16), UiKit.dp(a, 10), UiKit.dp(a, 16), UiKit.dp(a, 10))
            head.addView(UiKit.iconView(a, pkg, 40), LinearLayout.LayoutParams(UiKit.dp(a, 40), UiKit.dp(a, 40)))

            val col = LinearLayout(a)
            col.orientation = LinearLayout.VERTICAL
            val nameTv = TextView(a)
            nameTv.textSize = 16f
            nameTv.setTextColor(UiKit.primary(dark))
            nameTv.setSingleLine(true)
            val statusTv = TextView(a)
            statusTv.textSize = 12.5f
            statusTv.setTextColor(UiKit.secondary(dark))
            col.addView(nameTv, LinearLayout.LayoutParams(mp, wc))
            col.addView(statusTv, LinearLayout.LayoutParams(mp, wc))
            head.addView(col, LinearLayout.LayoutParams(0, wc, 1f).apply {
                leftMargin = UiKit.dp(a, 12)
                rightMargin = UiKit.dp(a, 8)
            })

            val master = Switch(a)
            head.addView(master, LinearLayout.LayoutParams(wc, wc))
            item.addView(head, LinearLayout.LayoutParams(mp, wc))

            val detail = LinearLayout(a)
            detail.orientation = LinearLayout.VERTICAL
            detail.visibility = View.GONE
            item.addView(detail, LinearLayout.LayoutParams(mp, wc))
            var built = false

            lateinit var refresh: () -> Unit

            fun buildDetail() {
                detail.removeAllViews()
                val r = Rules.appRule(a, pkg)
                detail.addView(SettingsKit.switchRow(a, "Banner", null, r.banner) {
                    Rules.setAppRule(a, Rules.appRule(a, pkg).copy(banner = it))
                })
                detail.addView(SettingsKit.switchRow(a, "Âm thanh", null, r.sound) {
                    Rules.setAppRule(a, Rules.appRule(a, pkg).copy(sound = it))
                    statusTv.post { refresh() }
                })
                detail.addView(SettingsKit.switchRow(a, "Gộp vào tóm tắt", null, r.summary) {
                    Rules.setAppRule(a, Rules.appRule(a, pkg).copy(summary = it))
                    statusTv.post { refresh() }
                })
                detail.addView(SettingsKit.switchRow(a, "Hiện trên Dynamic Island", null, r.island) {
                    Rules.setAppRule(a, Rules.appRule(a, pkg).copy(island = it))
                })
                detail.addView(SettingsKit.buttonRow(a, "Tên hiển thị", Rules.displayName(a, pkg)) {
                    SettingsKit.inputDialog(a, "Tên hiển thị", "Tên ứng dụng", r.alias ?: "") { s ->
                        val v = s.trim()
                        Rules.setAppRule(a, Rules.appRule(a, pkg).copy(alias = if (v.isEmpty()) null else v))
                        refresh()
                    }
                })
                val btns = LinearLayout(a)
                btns.orientation = LinearLayout.HORIZONTAL
                btns.setPadding(UiKit.dp(a, 12), UiKit.dp(a, 8), UiKit.dp(a, 12), UiKit.dp(a, 12))
                fun mb(text: String, click: () -> Unit) {
                    val b = UiKit.pillButton(a, text, false)
                    b.setOnClickListener {
                        click()
                        refresh()
                    }
                    btns.addView(b, LinearLayout.LayoutParams(0, wc, 1f).apply {
                        leftMargin = UiKit.dp(a, 3)
                        rightMargin = UiKit.dp(a, 3)
                    })
                }
                mb("1 giờ") { Rules.muteApp(a, pkg, 60) }
                mb("Đến hết ngày") { Rules.muteApp(a, pkg, -1) }
                mb("Bỏ tắt tiếng") { Rules.unmuteApp(a, pkg) }
                detail.addView(btns, LinearLayout.LayoutParams(mp, wc))

                val sysBtn = UiKit.pillButton(a, "Thông báo của app này", false)
                sysBtn.setOnClickListener {
                    try {
                        val i = Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS)
                        i.putExtra(Settings.EXTRA_APP_PACKAGE, pkg)
                        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        UiKit.safeStart(a, i)
                    } catch (e: Exception) {
                    }
                }
                detail.addView(sysBtn, LinearLayout.LayoutParams(mp, wc).apply {
                    leftMargin = UiKit.dp(a, 12)
                    rightMargin = UiKit.dp(a, 12)
                })
                val sysHint = TextView(a)
                sysHint.text = "Nếu thông báo của app này bị tắt trong hệ thống, notifyIOS27 không thể nhìn thấy chúng."
                sysHint.textSize = 12.5f
                sysHint.setTextColor(UiKit.secondary(dark))
                sysHint.setPadding(UiKit.dp(a, 16), UiKit.dp(a, 6), UiKit.dp(a, 16), UiKit.dp(a, 12))
                detail.addView(sysHint, LinearLayout.LayoutParams(mp, wc))
            }

            refresh = {
                val r = Rules.appRule(a, pkg)
                nameTv.text = Rules.displayName(a, pkg)
                val parts = ArrayList<String>()
                if (r.mutedUntil > System.currentTimeMillis()) {
                    parts.add("Đang tắt đến " + timeFmt.format(Date(r.mutedUntil)))
                } else if (!r.sound) {
                    parts.add("Tắt tiếng")
                }
                if (r.summary) parts.add("Tóm tắt")
                statusTv.text = parts.joinToString(" · ")
                statusTv.visibility = if (parts.isEmpty()) View.GONE else View.VISIBLE
                val en = Prefs.isAppEnabled(pkg)
                if (master.isChecked != en) master.isChecked = en
                if (built && detail.visibility == View.VISIBLE) buildDetail()
            }

            master.isChecked = Prefs.isAppEnabled(pkg)
            master.setOnCheckedChangeListener { _, on -> Prefs.setAppEnabled(pkg, on) }
            head.setOnClickListener {
                if (detail.visibility == View.VISIBLE) {
                    detail.visibility = View.GONE
                } else {
                    buildDetail()
                    built = true
                    detail.visibility = View.VISIBLE
                }
            }
            refresh()
            refreshers.add(refresh)
            searchKeys.add(Pair<View, () -> String>(item, { nameTv.text.toString().lowercase() + " " + pkg.lowercase() }))
            list.addView(item, LinearLayout.LayoutParams(mp, wc))
        }

        search.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: Editable?) {
                val q = (s?.toString() ?: "").trim().lowercase()
                for ((v, key) in searchKeys) v.visibility = if (q.isEmpty() || key().contains(q)) View.VISIBLE else View.GONE
            }
        })
        return root
    }

    override fun onResume() {
        for (r in refreshers.toList()) {
            try {
                r()
            } catch (e: Exception) {
            }
        }
    }
}

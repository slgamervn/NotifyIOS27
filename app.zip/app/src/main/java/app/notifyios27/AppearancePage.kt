package app.notifyios27

import android.app.Activity
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import java.io.File
import java.io.FileOutputStream
import kotlin.math.roundToInt

class AppearancePage : SettingsPage {
    override val title: String = "Giao diện"
    private var box: LinearLayout? = null

    private val swatches = intArrayOf(
        Color.parseColor("#0A84FF"), Color.parseColor("#30D158"), Color.parseColor("#FF9F0A"),
        Color.parseColor("#FF453A"), Color.parseColor("#BF5AF2"), Color.parseColor("#FF375F"),
        Color.parseColor("#64D2FF"), Color.parseColor("#FFD60A")
    )

    override fun build(a: Activity, push: (SettingsPage) -> Unit): View {
        val b = LinearLayout(a)
        b.orientation = LinearLayout.VERTICAL
        box = b
        fill(a, b)
        return b
    }

    private fun toast(a: Activity, m: String) {
        try { Toast.makeText(a, m, Toast.LENGTH_SHORT).show() } catch (e: Exception) { }
    }

    private fun paletteRow(a: Activity, b: LinearLayout): View {
        val row = LinearLayout(a)
        row.orientation = LinearLayout.HORIZONTAL
        row.setPadding(UiKit.dp(a, 10), UiKit.dp(a, 12), UiKit.dp(a, 10), UiKit.dp(a, 12))
        val cur = Prefs.accent
        for (c in swatches) {
            val holder = FrameLayout(a)
            val dot = View(a)
            val g = GradientDrawable()
            g.shape = GradientDrawable.OVAL
            g.setColor(c)
            if (c == cur) g.setStroke(UiKit.dp(a, 3), Color.WHITE)
            dot.background = g
            val size = UiKit.dp(a, 30)
            holder.addView(dot, FrameLayout.LayoutParams(size, size, Gravity.CENTER))
            holder.setOnClickListener {
                Prefs.accent = c
                fill(a, b)
            }
            row.addView(holder, LinearLayout.LayoutParams(0, UiKit.dp(a, 36), 1f))
        }
        return row
    }

    private fun wallpaperGrid(a: Activity, b: LinearLayout): View {
        val presets = UiKit.presetWallpapers()
        val acc = UiKit.accent(a)
        val outer = LinearLayout(a)
        outer.orientation = LinearLayout.VERTICAL
        outer.setPadding(UiKit.dp(a, 10), UiKit.dp(a, 10), UiKit.dp(a, 10), UiKit.dp(a, 4))
        var idx = 0
        while (idx < presets.size) {
            val row = LinearLayout(a)
            row.orientation = LinearLayout.HORIZONTAL
            for (k in 0 until 3) {
                val i = idx + k
                if (i < presets.size) {
                    val t = TextView(a)
                    t.text = presets[i].first
                    t.textSize = 11.5f
                    t.typeface = Typeface.DEFAULT_BOLD
                    t.setTextColor(Color.WHITE)
                    t.gravity = Gravity.BOTTOM or Gravity.START
                    t.setPadding(UiKit.dp(a, 8), 0, UiKit.dp(a, 8), UiKit.dp(a, 6))
                    val g = GradientDrawable(GradientDrawable.Orientation.TL_BR, presets[i].second)
                    g.cornerRadius = UiKit.dpf(a, 12f)
                    if (Prefs.wallpaperMode == 0 && Prefs.wallpaperIndex == i) g.setStroke(UiKit.dp(a, 3), acc)
                    t.background = g
                    t.setOnClickListener {
                        Prefs.wallpaperMode = 0
                        Prefs.wallpaperIndex = i
                        fill(a, b)
                    }
                    row.addView(t, LinearLayout.LayoutParams(0, UiKit.dp(a, 70), 1f).apply {
                        leftMargin = UiKit.dp(a, 4)
                        rightMargin = UiKit.dp(a, 4)
                        bottomMargin = UiKit.dp(a, 8)
                    })
                } else {
                    row.addView(View(a), LinearLayout.LayoutParams(0, UiKit.dp(a, 70), 1f))
                }
            }
            outer.addView(row, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
            idx += 3
        }
        return outer
    }

    private fun pickImage(a: Activity, b: LinearLayout) {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT)
        i.addCategory(Intent.CATEGORY_OPENABLE)
        i.type = "image/*"
        (a as? SettingsActivity)?.startForResult(i) { data ->
            val uri = data?.data
            if (uri != null) importWallpaper(a, b, uri)
        }
    }

    private fun importWallpaper(a: Activity, b: LinearLayout, uri: Uri) {
        Thread {
            var ok = false
            try {
                val cr = a.contentResolver
                val o = BitmapFactory.Options()
                o.inJustDecodeBounds = true
                cr.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, o) }
                if (o.outWidth > 0 && o.outHeight > 0) {
                    var s = 1
                    while (Math.max(o.outWidth, o.outHeight) / s > 2880) s *= 2
                    val o2 = BitmapFactory.Options()
                    o2.inSampleSize = s
                    val bmp = cr.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, o2) }
                    if (bmp != null) {
                        val longSide = Math.max(bmp.width, bmp.height)
                        val out: Bitmap = if (longSide > 1440) {
                            val f = 1440f / longSide
                            Bitmap.createScaledBitmap(
                                bmp, Math.max(1, (bmp.width * f).toInt()), Math.max(1, (bmp.height * f).toInt()), true
                            )
                        } else bmp
                        val file = File(a.filesDir, "wallpaper.jpg")
                        FileOutputStream(file).use { out.compress(Bitmap.CompressFormat.JPEG, 90, it) }
                        Prefs.wallpaperPath = file.absolutePath
                        Prefs.wallpaperMode = 1
                        ok = true
                    }
                }
            } catch (e: Throwable) {
                ok = false
            }
            a.runOnUiThread {
                toast(a, if (ok) "Đã đặt ảnh nền" else "Không đọc được ảnh")
                fill(a, b)
            }
        }.start()
    }

    private fun fill(a: Activity, b: LinearLayout) {
        b.removeAllViews()
        val wrap = ViewGroup.LayoutParams.WRAP_CONTENT
        val match = ViewGroup.LayoutParams.MATCH_PARENT

        val s1 = SettingsKit.section(a, "Chủ đề")
        s1.addView(SettingsKit.segmented(a, listOf("Tự động", "Sáng", "Tối"), Prefs.theme) {
            Prefs.theme = it
            a.recreate()
        })
        b.addView(s1, LinearLayout.LayoutParams(match, wrap))
        b.addView(SettingsKit.spacer(a, 16))

        val s2 = SettingsKit.section(a, "Màu nhấn")
        s2.addView(paletteRow(a, b))
        b.addView(s2, LinearLayout.LayoutParams(match, wrap))
        b.addView(SettingsKit.spacer(a, 16))

        val s3 = SettingsKit.section(a, "Hình nền")
        s3.addView(wallpaperGrid(a, b))
        s3.addView(SettingsKit.buttonRow(a, "Chọn ảnh từ máy", if (Prefs.wallpaperMode == 1) "Đang dùng ảnh của bạn" else null) {
            pickImage(a, b)
        })
        s3.addView(SettingsKit.buttonRow(a, "Dùng nền gradient", null) {
            Prefs.wallpaperMode = 0
            fill(a, b)
        })
        b.addView(s3, LinearLayout.LayoutParams(match, wrap))
        b.addView(SettingsKit.spacer(a, 16))

        val s4 = SettingsKit.section(a, "Kính và chữ")
        s4.addView(SettingsKit.sliderRow(a, "Độ trong của kính", 0.15f, 0.80f, Prefs.glass,
            { v -> "${(v * 100f).roundToInt()}%" }) { v -> Prefs.glass = v })
        s4.addView(SettingsKit.switchRow(a, "Làm mờ nền (Liquid Glass)", null, Prefs.glassBlur) {
            Prefs.glassBlur = it
        })
        s4.addView(SettingsKit.sliderRow(a, "Độ mờ", 8f, 40f, Prefs.glassBlurRadius.toFloat(),
            { v -> "${v.roundToInt()} dp" }) { v -> Prefs.glassBlurRadius = v.roundToInt() })
        val capable = Glass.deviceBlurCapable(a)
        s4.addView(settingsCaption(a, if (capable) "Máy hỗ trợ làm mờ nền"
        else "Máy không hỗ trợ làm mờ nền: banner dùng kính đục hơn"))
        s4.addView(SettingsKit.sliderRow(a, "Cỡ chữ", 0.8f, 1.4f, Prefs.fontScale,
            { v -> "${(v * 100f).roundToInt()}%" }) { v -> Prefs.fontScale = v })
        s4.addView(SettingsKit.switchRow(a, "Giảm chuyển động", "Rút ngắn hoặc bỏ hiệu ứng", Prefs.reduceMotion) {
            Prefs.reduceMotion = it
        })
        b.addView(s4, LinearLayout.LayoutParams(match, wrap))
        b.addView(SettingsKit.spacer(a, 16))

        val s5 = SettingsKit.section(a, "Màn hình khóa")
        s5.addView(SettingsKit.segmented(a, listOf("Lớn", "Nhỏ gọn"), Prefs.lockClockMode) { Prefs.lockClockMode = it })
        s5.addView(SettingsKit.switchRow(a, "Giữ màn hình sáng", null, Prefs.lockKeepScreenOn) {
            Prefs.lockKeepScreenOn = it
        })
        b.addView(s5, LinearLayout.LayoutParams(match, wrap))
    }
}

package app.notifyios27

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

object Backup {
    private val FILES = listOf("n27", "n27_rules", "n27_focus", "n27_summary", "n27_snooze")

    private fun entryOf(v: Any?): JSONObject? {
        val e = JSONObject()
        when (v) {
            is Boolean -> { e.put("t", "Boolean"); e.put("v", v) }
            is Int -> { e.put("t", "Int"); e.put("v", v) }
            is Long -> { e.put("t", "Long"); e.put("v", v) }
            is Float -> {
                if (v.isNaN() || v.isInfinite()) return null
                e.put("t", "Float"); e.put("v", v.toDouble())
            }
            is String -> { e.put("t", "String"); e.put("v", v) }
            is Set<*> -> {
                val arr = JSONArray()
                for (s in v) if (s is String) arr.put(s)
                e.put("t", "StringSet"); e.put("v", arr)
            }
            else -> return null
        }
        return e
    }

    fun exportJson(c: Context): String {
        val root = JSONObject()
        for (name in FILES) {
            try {
                val sp = c.applicationContext.getSharedPreferences(name, Context.MODE_PRIVATE)
                val f = JSONObject()
                for ((k, v) in sp.all) {
                    try {
                        val e = entryOf(v)
                        if (e != null) f.put(k, e)
                    } catch (e: Exception) {
                    }
                }
                root.put(name, f)
            } catch (e: Exception) {
            }
        }
        return root.toString()
    }

    private class Entry(val key: String, val value: Any)

    fun importJson(c: Context, json: String): Boolean {
        try {
            val root = JSONObject(json)
            val plan = LinkedHashMap<String, List<Entry>>()
            for (name in FILES) {
                if (!root.has(name)) continue
                val fo = root.optJSONObject(name) ?: return false
                val list = ArrayList<Entry>()
                val keys = fo.keys()
                while (keys.hasNext()) {
                    val k = keys.next()
                    val e = fo.optJSONObject(k) ?: return false
                    if (!e.has("v")) return false
                    val raw = e.get("v")
                    val v: Any = when (e.optString("t", "")) {
                        "Boolean" -> (raw as? Boolean) ?: return false
                        "Int" -> when {
                            raw is Int -> raw
                            raw is Long && raw >= Int.MIN_VALUE.toLong() && raw <= Int.MAX_VALUE.toLong() -> raw.toInt()
                            else -> return false
                        }
                        "Long" -> when (raw) {
                            is Int -> raw.toLong()
                            is Long -> raw
                            else -> return false
                        }
                        "Float" -> {
                            if (raw !is Number) return false
                            val f = raw.toFloat()
                            if (f.isNaN() || f.isInfinite()) return false
                            f
                        }
                        "String" -> (raw as? String) ?: return false
                        "StringSet" -> {
                            val arr = (raw as? JSONArray) ?: return false
                            val s = HashSet<String>()
                            for (i in 0 until arr.length()) {
                                s.add((arr.get(i) as? String) ?: return false)
                            }
                            s
                        }
                        else -> return false
                    }
                    list.add(Entry(k, v))
                }
                plan[name] = list
            }
            if (plan.isEmpty()) return false

            var ok = true
            for ((name, list) in plan) {
                val ed = c.applicationContext.getSharedPreferences(name, Context.MODE_PRIVATE).edit()
                ed.clear()
                for (en in list) {
                    val v = en.value
                    when (v) {
                        is Boolean -> ed.putBoolean(en.key, v)
                        is Int -> ed.putInt(en.key, v)
                        is Long -> ed.putLong(en.key, v)
                        is Float -> ed.putFloat(en.key, v)
                        is String -> ed.putString(en.key, v)
                        is Set<*> -> {
                            val set = HashSet<String>()
                            for (s in v) if (s is String) set.add(s)
                            ed.putStringSet(en.key, set)
                        }
                        else -> {}
                    }
                }
                if (!ed.commit()) ok = false
            }
            return ok
        } catch (e: Exception) {
            return false
        }
    }
}

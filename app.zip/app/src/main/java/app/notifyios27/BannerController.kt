package app.notifyios27

import android.content.Context
import android.graphics.PixelFormat
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.WindowManager

object BannerController {

    private const val MAX_WAITING = 3

    private val handler = Handler(Looper.getMainLooper())
    private val queue = ArrayList<NotifItem>()
    private var view: BannerView? = null
    private var wm: WindowManager? = null
    private var appCtx: Context? = null
    private var current: NotifItem? = null
    private var dismissing = false
    private var touching = false

    private val autoDismiss = Runnable { dismissCurrent() }

    fun show(c: Context, i: NotifItem) {
        val app = c.applicationContext ?: c
        appCtx = app
        val v = view
        if (v != null) {
            if (!dismissing && current?.key == i.key) {
                current = i
                try { v.bind(i) } catch (e: Exception) { }
                if (!touching) scheduleDismiss()
                return
            }
            val idx = queue.indexOfFirst { it.key == i.key }
            if (idx >= 0) {
                queue[idx] = i
            } else {
                queue.add(i)
                while (queue.size > MAX_WAITING) queue.removeAt(0)
            }
            return
        }
        display(app, i)
    }

    fun dismissAll() {
        queue.clear()
        handler.removeCallbacks(autoDismiss)
        val v = view
        if (v != null) {
            try { v.cancelAnimations() } catch (e: Exception) { }
            removeNow(v)
        }
    }

    private fun statusBarHeight(ctx: Context): Int {
        val res = ctx.resources
        val id = res.getIdentifier("status_bar_height", "dimen", "android")
        return if (id > 0) res.getDimensionPixelSize(id) else 0
    }

    private fun display(ctx: Context, item: NotifItem) {
        var v: BannerView? = null
        var manager: WindowManager? = null
        try {
            manager = ctx.getSystemService(Context.WINDOW_SERVICE) as WindowManager
            val bv = BannerView(ctx)
            v = bv
            bv.bind(item)
            bv.onTap = { onTapped() }
            bv.onSwipeDismiss = { dismissCurrent() }
            bv.onTouchStart = {
                touching = true
                handler.removeCallbacks(autoDismiss)
            }
            bv.onTouchEnd = {
                touching = false
                if (view === bv && !dismissing) scheduleDismiss()
            }

            val flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
            val lp = WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                flags,
                PixelFormat.TRANSLUCENT
            )
            lp.gravity = Gravity.TOP
            lp.y = statusBarHeight(ctx) + (6f * ctx.resources.displayMetrics.density + 0.5f).toInt()
            lp.alpha = 1f

            manager.addView(bv, lp)
            view = bv
            wm = manager
            current = item
            dismissing = false
            touching = false
            bv.animateIn()
            scheduleDismiss()
        } catch (e: WindowManager.BadTokenException) {
            failed(v, manager)
        } catch (e: SecurityException) {
            failed(v, manager)
        } catch (e: Exception) {
            failed(v, manager)
        }
    }

    // Something went wrong while adding: make sure nothing leaks and stop the queue.
    private fun failed(v: BannerView?, manager: WindowManager?) {
        handler.removeCallbacks(autoDismiss)
        if (v != null && view !== v) {
            try { manager?.removeViewImmediate(v) } catch (e: Exception) { }
        }
        val cur = view
        if (cur != null) removeNow(cur)
        queue.clear()
        view = null
        current = null
        dismissing = false
        touching = false
    }

    private fun scheduleDismiss() {
        handler.removeCallbacks(autoDismiss)
        handler.postDelayed(autoDismiss, Prefs.bannerSeconds.coerceIn(2, 10) * 1000L)
    }

    private fun onTapped() {
        val item = current
        val ctx = appCtx
        if (item != null && ctx != null) {
            try { NotifStore.open(ctx, item) } catch (e: Exception) { }
        }
        dismissCurrent()
    }

    private fun dismissCurrent() {
        val v = view ?: return
        if (dismissing) return
        dismissing = true
        handler.removeCallbacks(autoDismiss)
        try {
            v.animateOut { finish(v) }
        } catch (e: Exception) {
            finish(v)
            return
        }
        // Fallback in case the end action never fires (idempotent).
        handler.postDelayed({ finish(v) }, 600L)
    }

    private fun finish(v: BannerView) {
        if (view !== v) return
        removeNow(v)
        showNext()
    }

    private fun removeNow(v: BannerView) {
        handler.removeCallbacks(autoDismiss)
        try { wm?.removeViewImmediate(v) } catch (e: Exception) { }
        if (view === v) {
            view = null
            current = null
            dismissing = false
            touching = false
        }
    }

    private fun showNext() {
        if (view != null || queue.isEmpty()) return
        val ctx = appCtx ?: return
        val next = queue.removeAt(0)
        display(ctx, next)
    }
}

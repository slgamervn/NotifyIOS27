@file:Suppress("DEPRECATION")
package app.notifyios27


import android.content.ComponentCallbacks2
import android.content.Context
import android.content.res.Configuration
import android.graphics.PixelFormat
import android.media.AudioAttributes
import android.media.Ringtone
import android.media.RingtoneManager
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.VibrationEffect
import android.os.Vibrator
import android.view.Gravity
import android.view.WindowManager
import android.view.inputmethod.InputMethodManager

object BannerController {

    private const val MAX_WAITING = 3

    private class Q(var item: NotifItem, var sound: Boolean, var dnd: Boolean = false)

    private val handler = Handler(Looper.getMainLooper())
    private val queue = ArrayList<Q>()
    private var view: BannerView? = null
    private var wm: WindowManager? = null
    private var lpCur: WindowManager.LayoutParams? = null
    private var appCtx: Context? = null
    private var current: NotifItem? = null
    private var dismissing = false
    private var touching = false
    private var replyMode = false
    private var ringtone: Ringtone? = null

    private val autoDismiss = Runnable { dismissCurrent() }

    private class Spec(val winW: Int, val restY: Int)

    private var cbCtx: Context? = null
    private val cb = object : ComponentCallbacks2 {
        override fun onConfigurationChanged(newConfig: Configuration) {
            handler.post { relayout() }
        }
        override fun onLowMemory() {}
        override fun onTrimMemory(level: Int) {}
    }

    private fun registerCb(ctx: Context) {
        if (cbCtx != null) return
        try {
            ctx.registerComponentCallbacks(cb)
            cbCtx = ctx
        } catch (e: Throwable) {
        }
    }

    private fun unregisterCb() {
        val c = cbCtx ?: return
        cbCtx = null
        try { c.unregisterComponentCallbacks(cb) } catch (e: Throwable) { }
    }

    private fun spec(ctx: Context): Spec {
        val dm = ctx.resources.displayMetrics
        val d = dm.density
        val ins = UiKit.safeInsets(ctx)
        val margin = Math.max((12f * d + 0.5f).toInt(), Math.max(ins[0], ins[2]))
        val wide = dm.widthPixels > dm.heightPixels || ctx.resources.configuration.smallestScreenWidthDp >= 600
        val avail = dm.widthPixels - 2 * margin
        val w = if (wide) Math.min(avail, (420f * d + 0.5f).toInt()) else avail
        val y = if (Prefs.bannerPosition == 1) {
            (dm.heightPixels * 0.30f).toInt()
        } else {
            ins[1] + (6f * d + 0.5f).toInt()
        }
        return Spec(Math.max(w, (200f * d).toInt()), y)
    }

    // Rotation: re-lays the current banner out without touching its timer.
    private fun relayout() {
        val v = view ?: return
        val lp = lpCur ?: return
        val ctx = appCtx ?: return
        try {
            val sp = spec(ctx)
            if (Glass.blurSupported(ctx)) lp.width = sp.winW
            v.relayout(sp.winW, sp.restY)
        } catch (e: Throwable) {
        }
    }

    fun show(c: Context, i: NotifItem, sound: Boolean = true, dnd: Boolean = false) {
        if (i.silent) return
        val app = c.applicationContext ?: c
        appCtx = app

        if (Prefs.bannerStyle == 2) {
            val handled = try { Island.showNotification(app, i, sound, dnd) } catch (e: Exception) { false }
            if (handled) return
        }

        val v = view
        if (v != null) {
            if (!dismissing && current?.key == i.key) {
                current = i
                try { v.bind(i) } catch (e: Exception) { }
                try { v.setDnd(dnd) } catch (e: Exception) { }
                if (!touching) scheduleDismiss()
                return
            }
            val idx = queue.indexOfFirst { it.item.key == i.key }
            if (idx >= 0) {
                queue[idx].item = i
                queue[idx].sound = sound
                queue[idx].dnd = dnd
            } else {
                queue.add(Q(i, sound, dnd))
                while (queue.size > MAX_WAITING) queue.removeAt(0)
            }
            return
        }
        display(app, Q(i, sound))
    }

    fun dismissAll() {
        queue.clear()
        handler.removeCallbacks(autoDismiss)
        val v = view
        if (v != null) {
            try { v.cancelAnimations() } catch (e: Exception) { }
            removeNow(v)
        }
    }

    private fun statusBarHeight(ctx: Context): Int {
        val res = ctx.resources
        val id = res.getIdentifier("status_bar_height", "dimen", "android")
        return if (id > 0) res.getDimensionPixelSize(id) else 0
    }

    private fun display(ctx: Context, q: Q) {
        var v: BannerView? = null
        var manager: WindowManager? = null
        try {
            manager = ctx.getSystemService(Context.WINDOW_SERVICE) as WindowManager
            val style = if (Prefs.bannerStyle == 1) 1 else 0
            val blur = Glass.blurSupported(ctx)
            val sp = spec(ctx)
            val restY = sp.restY

            val bv = BannerView(ctx, blur, style, restY)
            bv.setSpec(sp.winW, restY)
            v = bv
            bv.bind(q.item)
            bv.setDnd(q.dnd)
            bv.onTap = { onTapped() }
            bv.onSwipeDismiss = { dismissCurrent() }
            bv.onDismissRequest = { dismissCurrent() }
            bv.onTouchStart = {
                touching = true
                handler.removeCallbacks(autoDismiss)
            }
            bv.onTouchEnd = {
                touching = false
                if (view === bv && !dismissing) scheduleDismiss()
            }
            bv.onExpandChanged = { handler.removeCallbacks(autoDismiss) }
            bv.onReplyVisible = { on -> setReplyMode(bv, on) }
            bv.host = object : BannerView.Host {
                override fun place(x: Int, y: Int, blurPx: Int) {
                    placeWindow(bv, x, y, blurPx)
                }
            }

            val flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
            val lp = WindowManager.LayoutParams(
                if (blur) sp.winW else WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                flags,
                PixelFormat.TRANSLUCENT
            )
            lp.gravity = if (blur) (Gravity.TOP or Gravity.CENTER_HORIZONTAL) else Gravity.TOP
            lp.x = 0
            lp.y = if (blur) restY else 0
            lp.alpha = 1f
            Glass.applyBlur(ctx, lp)

            bv.prepare()
            if (blur) {
                // start fully off-screen and unblurred; the entrance ramps both up
                lp.x = bv.startX()
                lp.y = restY + bv.startY()
                if (Build.VERSION.SDK_INT >= 31) lp.blurBehindRadius = 0
            }

            manager.addView(bv, lp)
            view = bv
            wm = manager
            lpCur = lp
            registerCb(ctx)
            current = q.item
            dismissing = false
            touching = false
            replyMode = false
            bv.animateIn()
            scheduleDismiss()
            if (q.sound) {
                feedback(
                    ctx,
                    Dnd.effectiveSound(ctx, true, q.dnd),
                    Dnd.effectiveHaptic(ctx, Prefs.haptic, q.dnd)
                )
            }
        } catch (e: WindowManager.BadTokenException) {
            failed(v, manager)
        } catch (e: SecurityException) {
            failed(v, manager)
        } catch (e: Exception) {
            failed(v, manager)
        }
    }

    // One layout pass per call: moves the window and (when blur is on) sets the blur radius.
    private fun placeWindow(bv: BannerView, x: Int, y: Int, blurPx: Int) {
        val lp = lpCur ?: return
        if (view !== bv) return
        lp.x = x
        lp.y = y
        try {
            val ctx = appCtx ?: bv.context
            if (Glass.blurSupported(ctx)) {
                Glass.setBlurRadius(ctx, bv, lp, blurPx)
            } else {
                wm?.updateViewLayout(bv, lp)
            }
        } catch (e: Exception) {
        }
    }

    private fun setReplyMode(bv: BannerView, on: Boolean) {
        val lp = lpCur ?: return
        if (view !== bv) return
        replyMode = on
        if (on) {
            lp.flags = lp.flags and WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE.inv()
            lp.softInputMode = WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE
        } else {
            lp.flags = lp.flags or WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
            lp.softInputMode = WindowManager.LayoutParams.SOFT_INPUT_ADJUST_UNSPECIFIED
        }
        try { wm?.updateViewLayout(bv, lp) } catch (e: Exception) { }
    }

    private fun feedback(ctx: Context, playSound: Boolean, playHaptic: Boolean) {
        try {
            val s = Prefs.soundUri
            if (playSound && s != "none") {
                val uri: Uri? = if (s.isEmpty()) {
                    RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)
                } else {
                    Uri.parse(s)
                }
                if (uri != null) {
                    try { ringtone?.stop() } catch (e: Exception) { }
                    val r = RingtoneManager.getRingtone(ctx, uri)
                    if (r != null) {
                        try {
                            r.setAudioAttributes(
                                AudioAttributes.Builder()
                                    .setUsage(AudioAttributes.USAGE_NOTIFICATION)
                                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                                    .build()
                            )
                        } catch (e: Exception) {
                        }
                        ringtone = r
                        r.play()
                    }
                }
            }
        } catch (e: Throwable) {
        }
        try {
            if (playHaptic) {
                @Suppress("DEPRECATION")
                val vib = ctx.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
                if (vib != null && vib.hasVibrator()) {
                    val effect = if (Build.VERSION.SDK_INT >= 29) {
                        VibrationEffect.createPredefined(VibrationEffect.EFFECT_CLICK)
                    } else {
                        VibrationEffect.createOneShot(15L, VibrationEffect.DEFAULT_AMPLITUDE)
                    }
                    vib.vibrate(effect)
                }
            }
        } catch (e: Throwable) {
        }
    }

    // Something went wrong while adding: make sure nothing leaks and stop the queue.
    private fun failed(v: BannerView?, manager: WindowManager?) {
        handler.removeCallbacks(autoDismiss)
        if (v != null && view !== v) {
            try { v.cancelAnimations() } catch (e: Exception) { }
            try { manager?.removeViewImmediate(v) } catch (e: Exception) { }
        }
        val cur = view
        if (cur != null) removeNow(cur)
        queue.clear()
        unregisterCb()
        view = null
        lpCur = null
        current = null
        dismissing = false
        touching = false
        replyMode = false
    }

    private fun scheduleDismiss() {
        handler.removeCallbacks(autoDismiss)
        if (view?.expanded == true) return
        handler.postDelayed(autoDismiss, Prefs.bannerSeconds.coerceIn(2, 10) * 1000L)
    }

    private fun onTapped() {
        val item = current
        val ctx = appCtx
        if (item != null && ctx != null) {
            try { NotifStore.open(ctx, item) } catch (e: Exception) { }
        }
        dismissCurrent()
    }

    private fun dismissCurrent() {
        val v = view ?: return
        if (dismissing) return
        dismissing = true
        handler.removeCallbacks(autoDismiss)
        try {
            v.animateOut { finish(v) }
        } catch (e: Exception) {
            finish(v)
            return
        }
        // Fallback in case the end action never fires (idempotent).
        handler.postDelayed({ finish(v) }, 700L)
    }

    private fun finish(v: BannerView) {
        if (view !== v) return
        removeNow(v)
        showNext()
    }

    private fun removeNow(v: BannerView) {
        handler.removeCallbacks(autoDismiss)
        try { v.cancelAnimations() } catch (e: Exception) { }
        if (view === v) {
            if (replyMode) {
                try {
                    val imm = v.context.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
                    imm.hideSoftInputFromWindow(v.windowToken, 0)
                } catch (e: Exception) {
                }
                setReplyMode(v, false)
            }
        }
        try { wm?.removeViewImmediate(v) } catch (e: Exception) { }
        if (view === v) {
            unregisterCb()
            view = null
            lpCur = null
            current = null
            dismissing = false
            touching = false
            replyMode = false
        }
    }

    private fun showNext() {
        if (view != null || queue.isEmpty()) return
        val ctx = appCtx ?: return
        val next = queue.removeAt(0)
        display(ctx, next)
    }
}

@file:Suppress("DEPRECATION")
package app.notifyios27


import android.content.ComponentCallbacks2
import android.content.Context
import android.content.res.Configuration
import android.graphics.PixelFormat
import android.media.AudioAttributes
import android.media.Ringtone
import android.media.RingtoneManager
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.VibrationEffect
import android.os.Vibrator
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.inputmethod.InputMethodManager
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView

object BannerController {

    private const val MAX_WAITING = 3
    private const val MAX_KEEP = 20

    private class Q(var item: NotifItem, var sound: Boolean, var dnd: Boolean = false, var count: Int = 1)

    private val handler = Handler(Looper.getMainLooper())
    private val queue = ArrayList<Q>()
    private val stack = ArrayList<Q>()
    private var view: BannerView? = null
    private var spare: BannerView? = null
    private var wm: WindowManager? = null
    private var lpCur: WindowManager.LayoutParams? = null
    private var appCtx: Context? = null
    private var current: NotifItem? = null
    private var dismissing = false
    private var touching = false
    private var replyMode = false
    private var ringtone: Ringtone? = null

    // list window (mode 2, or an expanded stack)
    private var listView: ListRoot? = null
    private var listLp: WindowManager.LayoutParams? = null
    private var listFromStack = false

    private val autoDismiss = Runnable { dismissCurrent() }
    private var finishTarget: BannerView? = null
    private val finishFallback = Runnable { finishTarget?.let { finish(it) } }

    private class Spec(val winW: Int, val restY: Int)

    private var cbCtx: Context? = null
    private val cb = object : ComponentCallbacks2 {
        override fun onConfigurationChanged(newConfig: Configuration) {
            handler.post { relayout() }
        }
        override fun onLowMemory() {
            spare = null
        }
        override fun onTrimMemory(level: Int) {
            if (level >= ComponentCallbacks2.TRIM_MEMORY_BACKGROUND) spare = null
        }
    }

    private fun registerCb(ctx: Context) {
        if (cbCtx != null) return
        try {
            ctx.registerComponentCallbacks(cb)
            cbCtx = ctx
        } catch (e: Throwable) {
        }
    }

    private fun unregisterCb() {
        val c = cbCtx ?: return
        cbCtx = null
        try { c.unregisterComponentCallbacks(cb) } catch (e: Throwable) { }
    }

    private fun spec(ctx: Context): Spec {
        val dm = ctx.resources.displayMetrics
        val d = dm.density
        val ins = UiKit.safeInsets(ctx)
        val margin = Math.max((12f * d + 0.5f).toInt(), Math.max(ins[0], ins[2]))
        val wide = dm.widthPixels > dm.heightPixels || ctx.resources.configuration.smallestScreenWidthDp >= 600
        val avail = dm.widthPixels - 2 * margin
        val w = if (wide) Math.min(avail, (420f * d + 0.5f).toInt()) else avail
        val y = if (Prefs.bannerPosition == 1) {
            (dm.heightPixels * 0.30f).toInt()
        } else {
            ins[1] + (6f * d + 0.5f).toInt()
        }
        return Spec(Math.max(w, (200f * d).toInt()), y)
    }

    // Rotation: re-lays the current banner out without touching its timer.
    private fun relayout() {
        val v = view ?: return
        val lp = lpCur ?: return
        val ctx = appCtx ?: return
        try {
            val sp = spec(ctx)
            if (Glass.blurSupported(ctx)) lp.width = sp.winW
            v.relayout(sp.winW, sp.restY)
        } catch (e: Throwable) {
        }
    }

    private fun stackMode(): Int = try { Prefs.bannerStackMode } catch (e: Throwable) { 1 }

    private fun depth(): Int = if (Perf.lite) 2 else Prefs.bannerStackMax.coerceIn(2, 5)

    // same key, same group of one app, or same sender of one app
    private fun sameConversation(a: NotifItem, b: NotifItem): Boolean {
        if (a.key == b.key) return true
        if (a.pkg != b.pkg) return false
        if (!a.groupKey.isNullOrEmpty() && a.groupKey == b.groupKey) return true
        return a.title.isNotBlank() && a.title == b.title
    }

    fun show(c: Context, i: NotifItem, sound: Boolean = true, dnd: Boolean = false) {
        if (i.silent) return
        val app = c.applicationContext ?: c
        appCtx = app

        if (Prefs.bannerStyle == 2) {
            val handled = try { Island.showNotification(app, i, sound, dnd) } catch (e: Exception) { false }
            if (handled) return
        }

        val mode = stackMode()
        if (listView != null) {
            merge(Q(i, sound, dnd))
            rebuildList()
            scheduleDismiss()
            if (sound) playFeedback(app, dnd, i)
            return
        }
        if (mode == 2 && view == null) {
            stack.clear()
            stack.add(Q(i, sound, dnd))
            showList(app, false)
            if (sound) playFeedback(app, dnd, i)
            return
        }

        val v = view
        if (v != null) {
            if (mode == 0 && !dismissing) {
                val wasTop = stack.isNotEmpty() && sameConversation(stack[0].item, i)
                merge(Q(i, sound, dnd))
                current = stack[0].item
                try {
                    v.bind(stack[0].item)
                    v.setDnd(dnd)
                    v.setStack(layersFor(), labelFor())
                    if (!wasTop) v.pushIn()
                } catch (e: Exception) {
                }
                if (!touching) scheduleDismiss()
                if (sound) playFeedback(app, dnd, i)
                return
            }
            if (!dismissing && current?.key == i.key) {
                current = i
                try { v.bind(i) } catch (e: Exception) { }
                try { v.setDnd(dnd) } catch (e: Exception) { }
                if (!touching) scheduleDismiss()
                return
            }
            val idx = queue.indexOfFirst { it.item.key == i.key }
            if (idx >= 0) {
                queue[idx].item = i
                queue[idx].sound = sound
                queue[idx].dnd = dnd
            } else {
                queue.add(Q(i, sound, dnd))
                while (queue.size > MAX_WAITING) queue.removeAt(0)
            }
            return
        }
        stack.clear()
        stack.add(Q(i, sound, dnd))
        display(app, Q(i, sound, dnd))
    }

    /** Puts an arrival on top of the stack, merging it with the same conversation. */
    private fun merge(q: Q) {
        val idx = stack.indexOfFirst { sameConversation(it.item, q.item) }
        if (idx >= 0) {
            val old = stack.removeAt(idx)
            q.count = if (old.item.key == q.item.key && old.item.text == q.item.text) old.count else old.count + 1
        }
        stack.add(0, q)
        while (stack.size > MAX_KEEP) stack.removeAt(stack.size - 1)
    }

    private fun layersFor(): Int = Math.min(depth() - 1, stack.size - 1).coerceIn(0, 2)

    private fun labelFor(): String? {
        if (stack.isEmpty()) return null
        val parts = ArrayList<String>(2)
        val top = stack[0]
        if (top.count > 1) parts.add("${top.count} tin mới")
        val hidden = stack.size - 1 - layersFor()
        if (hidden > 0) parts.add("+$hidden")
        return if (parts.isEmpty()) null else parts.joinToString(" · ")
    }

    fun dismissAll() {
        queue.clear()
        stack.clear()
        handler.removeCallbacks(autoDismiss)
        removeList()
        val v = view
        if (v != null) {
            try { v.cancelAnimations() } catch (e: Exception) { }
            removeNow(v)
        }
    }

    private fun obtainView(ctx: Context, blur: Boolean, style: Int, restY: Int): BannerView {
        val s = spare
        spare = null
        if (s != null && s.parent == null && !s.isAttachedToWindow && s.matches(blur, style)) {
            s.reset()
            return s
        }
        return BannerView(ctx, blur, style, restY)
    }

    private fun display(ctx: Context, q: Q) {
        var v: BannerView? = null
        var manager: WindowManager? = null
        try {
            manager = ctx.getSystemService(Context.WINDOW_SERVICE) as WindowManager
            val style = if (Prefs.bannerStyle == 1) 1 else 0
            val blur = Glass.blurSupported(ctx)
            val sp = spec(ctx)
            val restY = sp.restY
            val mode = stackMode()

            val bv = obtainView(ctx, blur, style, restY)
            bv.setSpec(sp.winW, restY)
            v = bv
            bv.bind(q.item)
            bv.setDnd(q.dnd)
            if (mode == 0) bv.setStack(layersFor(), labelFor())
            bv.onTap = { onTapped() }
            bv.onSwipeDismiss = { onSwiped() }
            bv.onDismissRequest = { dismissCurrent() }
            bv.onTouchStart = {
                touching = true
                handler.removeCallbacks(autoDismiss)
            }
            bv.onTouchEnd = {
                touching = false
                if (view === bv && !dismissing) scheduleDismiss()
            }
            bv.onExpandChanged = { handler.removeCallbacks(autoDismiss) }
            bv.onReplyVisible = { on -> setReplyMode(bv, on) }
            bv.onPeekTap = { expandStack() }
            bv.host = object : BannerView.Host {
                override fun place(x: Int, y: Int, blurPx: Int) {
                    placeWindow(bv, x, y, blurPx, -1f)
                }

                override fun placeA(x: Int, y: Int, blurPx: Int, alpha: Float) {
                    placeWindow(bv, x, y, blurPx, alpha)
                }
            }

            val flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
            val lp = WindowManager.LayoutParams(
                if (blur) sp.winW else WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                flags,
                PixelFormat.TRANSLUCENT
            )
            lp.gravity = if (blur) (Gravity.TOP or Gravity.CENTER_HORIZONTAL) else Gravity.TOP
            lp.x = 0
            lp.y = if (blur) restY else 0
            lp.alpha = if (blur) 0f else 1f
            if (Build.VERSION.SDK_INT >= 28) {
                lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            }
            Glass.applyBlur(ctx, lp)

            bv.prepare()
            if (blur) {
                // start fully off-screen and unblurred; the entrance ramps both up
                lp.x = bv.startX()
                lp.y = restY + bv.startY()
                if (Build.VERSION.SDK_INT >= 31) lp.blurBehindRadius = 0
            }

            manager.addView(bv, lp)
            view = bv
            wm = manager
            lpCur = lp
            registerCb(ctx)
            current = q.item
            dismissing = false
            touching = false
            replyMode = false
            bv.animateIn()
            scheduleDismiss()
            if (q.sound) playFeedback(ctx, q.dnd, q.item)
        } catch (e: WindowManager.BadTokenException) {
            failed(v, manager)
        } catch (e: SecurityException) {
            failed(v, manager)
        } catch (e: Exception) {
            failed(v, manager)
        }
    }

    private fun playFeedback(ctx: Context, dnd: Boolean, item: NotifItem) {
        val st = Style.resolve(ctx, item)
        feedback(
            ctx, Dnd.effectiveSound(ctx, true, dnd),
            st.haptic != Style.HAPTIC_OFF && Dnd.effectiveHaptic(ctx, Prefs.haptic, dnd),
            st.soundUri, st.haptic
        )
    }

    // One layout pass per call: moves the window and (when blur is on) sets the blur radius.
    private fun placeWindow(bv: BannerView, x: Int, y: Int, blurPx: Int, alpha: Float) {
        val lp = lpCur ?: return
        if (view !== bv) return
        lp.x = x
        lp.y = y
        if (alpha >= 0f) lp.alpha = alpha.coerceIn(0f, 1f)
        try {
            val ctx = appCtx ?: bv.context
            if (Glass.blurSupported(ctx)) {
                Glass.setBlurRadius(ctx, bv, lp, blurPx)
            } else {
                wm?.updateViewLayout(bv, lp)
            }
        } catch (e: Exception) {
        }
    }

    private fun setReplyMode(bv: BannerView, on: Boolean) {
        val lp = lpCur ?: return
        if (view !== bv) return
        replyMode = on
        if (on) {
            lp.flags = lp.flags and WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE.inv()
            lp.softInputMode = WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE
        } else {
            lp.flags = lp.flags or WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
            lp.softInputMode = WindowManager.LayoutParams.SOFT_INPUT_ADJUST_UNSPECIFIED
        }
        try { wm?.updateViewLayout(bv, lp) } catch (e: Exception) { }
    }

    private fun feedback(ctx: Context, playSound: Boolean, playHaptic: Boolean, s: String, hapticStyle: Int) {
        try {
            if (playSound && s != "none") {
                val uri: Uri? = if (s.isEmpty()) {
                    RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)
                } else {
                    Uri.parse(s)
                }
                if (uri != null) {
                    try { ringtone?.stop() } catch (e: Exception) { }
                    val r = RingtoneManager.getRingtone(ctx, uri)
                    if (r != null) {
                        try {
                            r.setAudioAttributes(
                                AudioAttributes.Builder()
                                    .setUsage(AudioAttributes.USAGE_NOTIFICATION)
                                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                                    .build()
                            )
                        } catch (e: Exception) {
                        }
                        ringtone = r
                        r.play()
                    }
                }
            }
        } catch (e: Throwable) {
        }
        try {
            if (playHaptic) {
                @Suppress("DEPRECATION")
                val vib = ctx.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
                if (vib != null && vib.hasVibrator()) {
                    val effect = if (Build.VERSION.SDK_INT >= 29) {
                        VibrationEffect.createPredefined(
                            when (hapticStyle) {
                                Style.HAPTIC_LIGHT -> VibrationEffect.EFFECT_TICK
                                Style.HAPTIC_STRONG -> VibrationEffect.EFFECT_HEAVY_CLICK
                                else -> VibrationEffect.EFFECT_CLICK
                            }
                        )
                    } else {
                        VibrationEffect.createOneShot(
                            when (hapticStyle) { Style.HAPTIC_LIGHT -> 8L; Style.HAPTIC_STRONG -> 35L; else -> 15L },
                            VibrationEffect.DEFAULT_AMPLITUDE
                        )
                    }
                    vib.vibrate(effect)
                }
            }
        } catch (e: Throwable) {
        }
    }

    // Something went wrong while adding: make sure nothing leaks and stop the queue.
    private fun failed(v: BannerView?, manager: WindowManager?) {
        handler.removeCallbacks(autoDismiss)
        if (v != null && view !== v) {
            try { v.cancelAnimations() } catch (e: Exception) { }
            try { manager?.removeViewImmediate(v) } catch (e: Exception) { }
        }
        val cur = view
        if (cur != null) removeNow(cur)
        queue.clear()
        stack.clear()
        unregisterCb()
        view = null
        lpCur = null
        current = null
        dismissing = false
        touching = false
        replyMode = false
    }

    private fun scheduleDismiss() {
        handler.removeCallbacks(autoDismiss)
        if (view?.expanded == true) return
        if (listView != null && listFromStack) return
        handler.postDelayed(autoDismiss, Prefs.bannerSeconds.coerceIn(2, 10) * 1000L)
    }

    private fun onTapped() {
        val item = current
        val ctx = appCtx
        if (item != null && ctx != null) {
            try { NotifStore.open(ctx, item) } catch (e: Exception) { }
        }
        stack.clear()
        dismissCurrent()
    }

    // Swipe removes only the top card; the next one rises from behind.
    private fun onSwiped() {
        val v = view ?: return
        if (stackMode() != 0 || stack.size <= 1) {
            stack.clear()
            dismissCurrent()
            return
        }
        stack.removeAt(0)
        dismissing = true
        handler.removeCallbacks(autoDismiss)
        try {
            v.animateOut {
                if (view !== v) return@animateOut
                dismissing = false
                val top = stack.firstOrNull()
                if (top == null) {
                    finish(v)
                } else {
                    current = top.item
                    v.bind(top.item)
                    v.setDnd(top.dnd)
                    v.setStack(layersFor(), labelFor())
                    v.popNext()
                    if (!touching) scheduleDismiss()
                }
            }
        } catch (e: Exception) {
            stack.clear()
            finish(v)
        }
    }

    private fun dismissCurrent() {
        if (listView != null && view == null) {
            stack.clear()
            removeList()
            showNext()
            return
        }
        val v = view ?: return
        if (dismissing) return
        dismissing = true
        handler.removeCallbacks(autoDismiss)
        try {
            v.animateOut { finish(v) }
        } catch (e: Exception) {
            finish(v)
            return
        }
        // Fallback in case the end action never fires (idempotent).
        finishTarget = v
        handler.removeCallbacks(finishFallback)
        handler.postDelayed(finishFallback, 700L)
    }

    private fun finish(v: BannerView) {
        if (view !== v) return
        handler.removeCallbacks(finishFallback)
        finishTarget = null
        stack.clear()
        removeNow(v)
        showNext()
    }

    private fun removeNow(v: BannerView) {
        handler.removeCallbacks(autoDismiss)
        try { v.cancelAnimations() } catch (e: Exception) { }
        if (view === v) {
            if (replyMode) {
                try {
                    val imm = v.context.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
                    imm.hideSoftInputFromWindow(v.windowToken, 0)
                } catch (e: Exception) {
                }
                setReplyMode(v, false)
            }
        }
        try { wm?.removeViewImmediate(v) } catch (e: Exception) { }
        if (view === v) {
            if (listView == null) unregisterCb()
            view = null
            lpCur = null
            current = null
            dismissing = false
            touching = false
            replyMode = false
            // kept for the next banner so its first frame does not stutter
            if (v.parent == null && !v.isAttachedToWindow) {
                try { v.reset() } catch (e: Exception) { }
                spare = v
            }
        }
    }

    private fun showNext() {
        if (view != null || listView != null || queue.isEmpty()) return
        val ctx = appCtx ?: return
        val next = queue.removeAt(0)
        stack.clear()
        stack.add(next)
        display(ctx, next)
        // whatever else waited joins the stack
        if (stackMode() == 0) {
            while (queue.isNotEmpty() && view != null) {
                val q = queue.removeAt(0)
                show(ctx, q.item, false, q.dnd)
            }
        }
    }

    // ================= list window =================

    private class ListRoot(c: Context) : FrameLayout(c) {
        var onOutside: (() -> Unit)? = null
        var onTouchState: ((Boolean) -> Unit)? = null
        val scroll = ScrollView(c)
        val col = LinearLayout(c)

        init {
            col.orientation = LinearLayout.VERTICAL
            scroll.isVerticalScrollBarEnabled = false
            scroll.overScrollMode = View.OVER_SCROLL_NEVER
            scroll.addView(col, LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT))
            addView(scroll, LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT))
        }

        override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
            val cap = (resources.displayMetrics.heightPixels * 0.6f).toInt()
            super.onMeasure(widthMeasureSpec, MeasureSpec.makeMeasureSpec(cap, MeasureSpec.AT_MOST))
        }

        override fun dispatchTouchEvent(ev: MotionEvent): Boolean {
            when (ev.actionMasked) {
                MotionEvent.ACTION_OUTSIDE -> {
                    onOutside?.invoke()
                    return true
                }
                MotionEvent.ACTION_DOWN -> onTouchState?.invoke(true)
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> onTouchState?.invoke(false)
            }
            return super.dispatchTouchEvent(ev)
        }
    }

    /** Tap on the peeking layers: the stack opens into a list with "Xoá tất cả". */
    private fun expandStack() {
        val ctx = appCtx ?: return
        val v = view ?: return
        if (stack.size <= 1) return
        handler.removeCallbacks(autoDismiss)
        removeNow(v)
        showList(ctx, true)
    }

    private fun showList(ctx: Context, fromStack: Boolean) {
        try {
            val manager = ctx.getSystemService(Context.WINDOW_SERVICE) as WindowManager
            val sp = spec(ctx)
            val root = ListRoot(ctx)
            root.onOutside = { if (listFromStack) collapseList() }
            root.onTouchState = { down ->
                touching = down
                if (down) handler.removeCallbacks(autoDismiss) else scheduleDismiss()
            }
            val flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or
                WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH
            val lp = WindowManager.LayoutParams(
                sp.winW, WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY, flags, PixelFormat.TRANSLUCENT
            )
            lp.gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
            lp.y = sp.restY
            if (Build.VERSION.SDK_INT >= 28) {
                lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            }
            listView = root
            listLp = lp
            listFromStack = fromStack
            wm = manager
            rebuildList()
            manager.addView(root, lp)
            registerCb(ctx)
            val d = Perf.dur(200L)
            if (d > 0L) {
                root.alpha = 0f
                root.translationY = -UiKit.dpf(ctx, 12f)
                root.animate().alpha(1f).translationY(0f).setDuration(d).setInterpolator(Perf.SPRING_SOFT).withLayer().start()
            }
            scheduleDismiss()
        } catch (e: Throwable) {
            listView = null
            listLp = null
            stack.clear()
        }
    }

    private fun rebuildList() {
        val root = listView ?: return
        val ctx = root.context
        val dark = Prefs.isDark(ctx)
        val col = root.col
        col.removeAllViews()
        val gap = UiKit.dp(ctx, 8)
        if (stack.size > 1 || listFromStack) {
            val bar = LinearLayout(ctx)
            bar.orientation = LinearLayout.HORIZONTAL
            bar.gravity = Gravity.END
            if (listFromStack) {
                bar.addView(StackViews.glassButton(ctx, "Thu gọn", dark) { collapseList() },
                    LinearLayout.LayoutParams(-2, -2).apply { rightMargin = gap })
            }
            bar.addView(StackViews.glassButton(ctx, "Xoá tất cả", dark) {
                stack.clear()
                removeList()
                showNext()
            }, LinearLayout.LayoutParams(-2, -2))
            col.addView(bar, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = gap })
        }
        val max = if (listFromStack) MAX_KEEP else depth()
        for (q in stack.take(max)) {
            val item = q.item
            val card = StackViews.card(ctx, item, dark, true, if (q.count > 1) "${q.count} tin mới" else null)
            val row = N27SwipeRow(ctx, card, {
                try { NotifStore.open(ctx, item) } catch (e: Exception) { }
                stack.clear()
                removeList()
                showNext()
            }, {
                stack.removeAll { it.item.key == item.key }
                if (stack.isEmpty()) {
                    removeList()
                    showNext()
                } else {
                    rebuildList()
                }
            })
            col.addView(row, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = gap })
        }
    }

    private fun collapseList() {
        val ctx = appCtx ?: return
        if (listView == null) return
        removeList()
        val top = stack.firstOrNull() ?: return
        display(ctx, Q(top.item, false, top.dnd, top.count))
    }

    private fun removeList() {
        val r = listView ?: return
        listView = null
        listLp = null
        listFromStack = false
        handler.removeCallbacks(autoDismiss)
        try { r.animate().cancel() } catch (e: Throwable) { }
        try { wm?.removeViewImmediate(r) } catch (e: Throwable) { }
        touching = false
        if (view == null) unregisterCb()
    }
}

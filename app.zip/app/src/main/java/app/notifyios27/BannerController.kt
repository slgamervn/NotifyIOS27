package app.notifyios27

import android.content.Context
import android.graphics.PixelFormat
import android.media.AudioAttributes
import android.media.Ringtone
import android.media.RingtoneManager
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.VibrationEffect
import android.os.Vibrator
import android.view.Gravity
import android.view.WindowManager
import android.view.inputmethod.InputMethodManager

object BannerController {

    private const val MAX_WAITING = 3

    private class Q(var item: NotifItem, var sound: Boolean)

    private val handler = Handler(Looper.getMainLooper())
    private val queue = ArrayList<Q>()
    private var view: BannerView? = null
    private var wm: WindowManager? = null
    private var lpCur: WindowManager.LayoutParams? = null
    private var appCtx: Context? = null
    private var current: NotifItem? = null
    private var dismissing = false
    private var touching = false
    private var replyMode = false
    private var ringtone: Ringtone? = null

    private val autoDismiss = Runnable { dismissCurrent() }

    fun show(c: Context, i: NotifItem, sound: Boolean = true) {
        if (i.silent) return
        val app = c.applicationContext ?: c
        appCtx = app

        if (Prefs.bannerStyle == 2) {
            val handled = try { Island.showNotification(app, i, sound) } catch (e: Exception) { false }
            if (handled) return
        }

        val v = view
        if (v != null) {
            if (!dismissing && current?.key == i.key) {
                current = i
                try { v.bind(i) } catch (e: Exception) { }
                if (!touching) scheduleDismiss()
                return
            }
            val idx = queue.indexOfFirst { it.item.key == i.key }
            if (idx >= 0) {
                queue[idx].item = i
                queue[idx].sound = sound
            } else {
                queue.add(Q(i, sound))
                while (queue.size > MAX_WAITING) queue.removeAt(0)
            }
            return
        }
        display(app, Q(i, sound))
    }

    fun dismissAll() {
        queue.clear()
        handler.removeCallbacks(autoDismiss)
        val v = view
        if (v != null) {
            try { v.cancelAnimations() } catch (e: Exception) { }
            removeNow(v)
        }
    }

    private fun statusBarHeight(ctx: Context): Int {
        val res = ctx.resources
        val id = res.getIdentifier("status_bar_height", "dimen", "android")
        return if (id > 0) res.getDimensionPixelSize(id) else 0
    }

    private fun display(ctx: Context, q: Q) {
        var v: BannerView? = null
        var manager: WindowManager? = null
        try {
            manager = ctx.getSystemService(Context.WINDOW_SERVICE) as WindowManager
            val style = if (Prefs.bannerStyle == 1) 1 else 0
            val blur = Glass.blurSupported(ctx)
            val dm = ctx.resources.displayMetrics
            val side = (12f * dm.density + 0.5f).toInt()
            val restY = if (Prefs.bannerPosition == 1) {
                (dm.heightPixels * 0.30f).toInt()
            } else {
                statusBarHeight(ctx) + (6f * dm.density + 0.5f).toInt()
            }

            val bv = BannerView(ctx, blur, style, restY)
            v = bv
            bv.bind(q.item)
            bv.onTap = { onTapped() }
            bv.onSwipeDismiss = { dismissCurrent() }
            bv.onDismissRequest = { dismissCurrent() }
            bv.onTouchStart = {
                touching = true
                handler.removeCallbacks(autoDismiss)
            }
            bv.onTouchEnd = {
                touching = false
                if (view === bv && !dismissing) scheduleDismiss()
            }
            bv.onExpandChanged = { handler.removeCallbacks(autoDismiss) }
            bv.onReplyVisible = { on -> setReplyMode(bv, on) }
            bv.host = object : BannerView.Host {
                override fun place(x: Int, y: Int, blurPx: Int) {
                    placeWindow(bv, x, y, blurPx)
                }
            }

            val flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
            val lp = WindowManager.LayoutParams(
                if (blur) dm.widthPixels - 2 * side else WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                flags,
                PixelFormat.TRANSLUCENT
            )
            lp.gravity = if (blur) (Gravity.TOP or Gravity.CENTER_HORIZONTAL) else Gravity.TOP
            lp.x = 0
            lp.y = if (blur) restY else 0
            lp.alpha = 1f
            Glass.applyBlur(ctx, lp)

            bv.prepare()
            if (blur) {
                // start fully off-screen and unblurred; the entrance ramps both up
                lp.x = bv.startX()
                lp.y = restY + bv.startY()
                if (Build.VERSION.SDK_INT >= 31) lp.blurBehindRadius = 0
            }

            manager.addView(bv, lp)
            view = bv
            wm = manager
            lpCur = lp
            current = q.item
            dismissing = false
            touching = false
            replyMode = false
            bv.animateIn()
            scheduleDismiss()
            if (q.sound) feedback(ctx)
        } catch (e: WindowManager.BadTokenException) {
            failed(v, manager)
        } catch (e: SecurityException) {
            failed(v, manager)
        } catch (e: Exception) {
            failed(v, manager)
        }
    }

    // One layout pass per call: moves the window and (when blur is on) sets the blur radius.
    private fun placeWindow(bv: BannerView, x: Int, y: Int, blurPx: Int) {
        val lp = lpCur ?: return
        if (view !== bv) return
        lp.x = x
        lp.y = y
        try {
            val ctx = appCtx ?: bv.context
            if (Glass.blurSupported(ctx)) {
                Glass.setBlurRadius(ctx, bv, lp, blurPx)
            } else {
                wm?.updateViewLayout(bv, lp)
            }
        } catch (e: Exception) {
        }
    }

    private fun setReplyMode(bv: BannerView, on: Boolean) {
        val lp = lpCur ?: return
        if (view !== bv) return
        replyMode = on
        if (on) {
            lp.flags = lp.flags and WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE.inv()
            lp.softInputMode = WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE
        } else {
            lp.flags = lp.flags or WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
            lp.softInputMode = WindowManager.LayoutParams.SOFT_INPUT_ADJUST_UNSPECIFIED
        }
        try { wm?.updateViewLayout(bv, lp) } catch (e: Exception) { }
    }

    private fun feedback(ctx: Context) {
        try {
            val s = Prefs.soundUri
            if (s != "none") {
                val uri: Uri? = if (s.isEmpty()) {
                    RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)
                } else {
                    Uri.parse(s)
                }
                if (uri != null) {
                    try { ringtone?.stop() } catch (e: Exception) { }
                    val r = RingtoneManager.getRingtone(ctx, uri)
                    if (r != null) {
                        try {
                            r.setAudioAttributes(
                                AudioAttributes.Builder()
                                    .setUsage(AudioAttributes.USAGE_NOTIFICATION)
                                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                                    .build()
                            )
                        } catch (e: Exception) {
                        }
                        ringtone = r
                        r.play()
                    }
                }
            }
        } catch (e: Throwable) {
        }
        try {
            if (Prefs.haptic) {
                @Suppress("DEPRECATION")
                val vib = ctx.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
                if (vib != null && vib.hasVibrator()) {
                    val effect = if (Build.VERSION.SDK_INT >= 29) {
                        VibrationEffect.createPredefined(VibrationEffect.EFFECT_CLICK)
                    } else {
                        VibrationEffect.createOneShot(15L, VibrationEffect.DEFAULT_AMPLITUDE)
                    }
                    vib.vibrate(effect)
                }
            }
        } catch (e: Throwable) {
        }
    }

    // Something went wrong while adding: make sure nothing leaks and stop the queue.
    private fun failed(v: BannerView?, manager: WindowManager?) {
        handler.removeCallbacks(autoDismiss)
        if (v != null && view !== v) {
            try { v.cancelAnimations() } catch (e: Exception) { }
            try { manager?.removeViewImmediate(v) } catch (e: Exception) { }
        }
        val cur = view
        if (cur != null) removeNow(cur)
        queue.clear()
        view = null
        lpCur = null
        current = null
        dismissing = false
        touching = false
        replyMode = false
    }

    private fun scheduleDismiss() {
        handler.removeCallbacks(autoDismiss)
        if (view?.expanded == true) return
        handler.postDelayed(autoDismiss, Prefs.bannerSeconds.coerceIn(2, 10) * 1000L)
    }

    private fun onTapped() {
        val item = current
        val ctx = appCtx
        if (item != null && ctx != null) {
            try { NotifStore.open(ctx, item) } catch (e: Exception) { }
        }
        dismissCurrent()
    }

    private fun dismissCurrent() {
        val v = view ?: return
        if (dismissing) return
        dismissing = true
        handler.removeCallbacks(autoDismiss)
        try {
            v.animateOut { finish(v) }
        } catch (e: Exception) {
            finish(v)
            return
        }
        // Fallback in case the end action never fires (idempotent).
        handler.postDelayed({ finish(v) }, 700L)
    }

    private fun finish(v: BannerView) {
        if (view !== v) return
        removeNow(v)
        showNext()
    }

    private fun removeNow(v: BannerView) {
        handler.removeCallbacks(autoDismiss)
        try { v.cancelAnimations() } catch (e: Exception) { }
        if (view === v) {
            if (replyMode) {
                try {
                    val imm = v.context.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
                    imm.hideSoftInputFromWindow(v.windowToken, 0)
                } catch (e: Exception) {
                }
                setReplyMode(v, false)
            }
        }
        try { wm?.removeViewImmediate(v) } catch (e: Exception) { }
        if (view === v) {
            view = null
            lpCur = null
            current = null
            dismissing = false
            touching = false
            replyMode = false
        }
    }

    private fun showNext() {
        if (view != null || queue.isEmpty()) return
        val ctx = appCtx ?: return
        val next = queue.removeAt(0)
        display(ctx, next)
    }
}

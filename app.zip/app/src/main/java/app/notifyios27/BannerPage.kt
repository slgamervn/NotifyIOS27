package app.notifyios27

import android.app.Activity
import android.content.Intent
import android.media.RingtoneManager
import android.net.Uri
import android.os.Build
import android.provider.Settings
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import kotlin.math.roundToInt

class BannerPage : SettingsPage {
    override val title: String = "Banner"
    private var box: LinearLayout? = null

    override fun build(a: Activity, push: (SettingsPage) -> Unit): View {
        val b = LinearLayout(a)
        b.orientation = LinearLayout.VERTICAL
        box = b
        fill(a, b)
        return b
    }

    private fun soundName(a: Activity): String {
        val u = Prefs.soundUri
        if (u.isEmpty()) return "Mặc định"
        if (u == "none") return "Im lặng"
        return try {
            RingtoneManager.getRingtone(a, Uri.parse(u))?.getTitle(a) ?: "Tùy chọn"
        } catch (e: Exception) {
            "Tùy chọn"
        }
    }

    @Suppress("DEPRECATION")
    private fun pickedUri(data: Intent): Uri? {
        return if (Build.VERSION.SDK_INT >= 33) {
            data.getParcelableExtra(RingtoneManager.EXTRA_RINGTONE_PICKED_URI, Uri::class.java)
        } else {
            data.getParcelableExtra<Uri>(RingtoneManager.EXTRA_RINGTONE_PICKED_URI)
        }
    }

    private fun pickSound(a: Activity, b: LinearLayout) {
        val i = Intent(RingtoneManager.ACTION_RINGTONE_PICKER)
        i.putExtra(RingtoneManager.EXTRA_RINGTONE_TYPE, RingtoneManager.TYPE_NOTIFICATION)
        i.putExtra(RingtoneManager.EXTRA_RINGTONE_SHOW_DEFAULT, true)
        i.putExtra(RingtoneManager.EXTRA_RINGTONE_SHOW_SILENT, true)
        i.putExtra(RingtoneManager.EXTRA_RINGTONE_TITLE, "Âm thanh thông báo")
        val cur = Prefs.soundUri
        val existing: Uri? = when {
            cur.isEmpty() -> Settings.System.DEFAULT_NOTIFICATION_URI
            cur == "none" -> null
            else -> try { Uri.parse(cur) } catch (e: Exception) { null }
        }
        i.putExtra(RingtoneManager.EXTRA_RINGTONE_EXISTING_URI, existing)
        (a as? SettingsActivity)?.startForResult(i) { data ->
            if (data != null) {
                val u = pickedUri(data)
                Prefs.soundUri = when {
                    u == null -> "none"
                    u == Settings.System.DEFAULT_NOTIFICATION_URI -> ""
                    else -> u.toString()
                }
                fill(a, b)
            }
        }
    }

    private fun fill(a: Activity, b: LinearLayout) {
        b.removeAllViews()
        val wrap = ViewGroup.LayoutParams.WRAP_CONTENT
        val match = ViewGroup.LayoutParams.MATCH_PARENT

        val s1 = SettingsKit.section(a, null)
        s1.addView(SettingsKit.switchRow(a, "Hiện banner", "Hiển thị thông báo dạng banner trên mọi ứng dụng", Prefs.bannerEnabled) {
            Prefs.bannerEnabled = it
        })
        s1.addView(SettingsKit.switchRow(a, "Ẩn khi xoay ngang", "Không hiện banner khi màn hình nằm ngang (tránh bấm nhầm lúc chơi game)", Prefs.bannerHideLandscape) {
            Prefs.bannerHideLandscape = it
        })
        b.addView(s1, LinearLayout.LayoutParams(match, wrap))
        b.addView(SettingsKit.spacer(a, 16))

        val s2 = SettingsKit.section(a, "Kiểu banner")
        s2.addView(SettingsKit.segmented(
            a, listOf("Trượt từ trái - iOS 27", "Trượt từ trên", "Dynamic Island"), Prefs.bannerStyle
        ) { Prefs.bannerStyle = it })
        b.addView(s2, LinearLayout.LayoutParams(match, wrap))
        b.addView(SettingsKit.spacer(a, 16))

        val s3 = SettingsKit.section(a, "Vị trí")
        s3.addView(SettingsKit.segmented(a, listOf("Trên cùng", "Hơi thấp"), Prefs.bannerPosition) {
            Prefs.bannerPosition = it
        })
        s3.addView(SettingsKit.sliderRow(
            a, "Thời gian hiển thị", 2f, 10f, Prefs.bannerSeconds.toFloat(),
            { v -> "${v.roundToInt()} giây" }
        ) { v -> Prefs.bannerSeconds = v.roundToInt() })
        b.addView(s3, LinearLayout.LayoutParams(match, wrap))
        b.addView(SettingsKit.spacer(a, 16))

        val s4 = SettingsKit.section(a, "Âm thanh và rung")
        s4.addView(SettingsKit.buttonRow(a, "Âm thanh thông báo", soundName(a)) { pickSound(a, b) })
        s4.addView(SettingsKit.switchRow(a, "Rung", null, Prefs.haptic) { Prefs.haptic = it })
        b.addView(s4, LinearLayout.LayoutParams(match, wrap))
        b.addView(SettingsKit.spacer(a, 16))

        val s5 = SettingsKit.section(a, "Khác")
        s5.addView(SettingsKit.switchRow(a, "Tự sao chép mã OTP", "Sao chép mã xác thực khi thông báo đến", Prefs.autoCopyOtp) {
            Prefs.autoCopyOtp = it
        })
        s5.addView(SettingsKit.switchRow(a, "Ẩn thông báo gốc", "Tự xóa thông báo gốc của hệ thống", Prefs.hideOriginal) {
            Prefs.hideOriginal = it
        })
        s5.addView(SettingsKit.switchRow(a, "Đồng bộ xóa", "Xóa ở đây sẽ xóa cả thông báo hệ thống", Prefs.syncClear) {
            Prefs.syncClear = it
        })
        b.addView(s5, LinearLayout.LayoutParams(match, wrap))
        b.addView(SettingsKit.spacer(a, 16))

        val s6 = SettingsKit.section(a, "Không làm phiền")
        s6.addView(SettingsKit.segmented(
            a, listOf("Ẩn banner", "Hiện im lặng", "Bỏ qua"), Prefs.dndMode
        ) { Prefs.dndMode = it })
        s6.addView(SettingsKit.switchRow(
            a, "Tôn trọng chế độ chuông", "Chế độ im lặng hoặc rung sẽ tắt âm thanh và rung của banner", Prefs.respectRinger
        ) { Prefs.respectRinger = it })
        s6.addView(SettingsKit.textRow(a, "Không làm phiền", if (Dnd.active(a)) "Đang bật" else "Đang tắt"))
        b.addView(s6, LinearLayout.LayoutParams(match, wrap))
    }
}

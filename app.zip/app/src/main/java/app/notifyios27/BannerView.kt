package app.notifyios27

import android.animation.ObjectAnimator
import android.content.Context
import android.graphics.Color
import android.graphics.Outline
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.LayerDrawable
import android.os.Build
import android.util.TypedValue
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.ViewOutlineProvider
import android.view.animation.AccelerateInterpolator
import android.view.animation.OvershootInterpolator
import android.text.TextUtils
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView

class BannerView(context: Context) : FrameLayout(context) {

    var onTap: (() -> Unit)? = null
    var onSwipeDismiss: (() -> Unit)? = null
    var onTouchStart: (() -> Unit)? = null
    var onTouchEnd: (() -> Unit)? = null

    private val card = LinearLayout(context)
    private val icon = ImageView(context)
    private val appNameView = TextView(context)
    private val urgentView = TextView(context)
    private val timeView = TextView(context)
    private val titleView = TextView(context)
    private val textView = TextView(context)

    private val slop = ViewConfiguration.get(context).scaledTouchSlop
    private var downRaw = 0f
    private var startTx = 0f
    private var lastRaw = 0f
    private var lastT = 0L
    private var vx = 0f
    private var dragging = false
    private var exiting = false
    private var enterAlpha: ObjectAnimator? = null

    private fun px(dp: Float): Int = (dp * resources.displayMetrics.density + 0.5f).toInt()
    private fun pxf(dp: Float): Float = dp * resources.displayMetrics.density
    private fun screenW(): Float = resources.displayMetrics.widthPixels.toFloat()

    init {
        clipChildren = false
        clipToPadding = false
        setPadding(px(12f), px(4f), px(12f), px(14f))

        card.orientation = LinearLayout.HORIZONTAL
        card.gravity = Gravity.TOP
        card.setPadding(px(14f), px(12f), px(14f), px(12f))
        card.elevation = pxf(10f)
        val radius = pxf(26f)
        card.outlineProvider = object : ViewOutlineProvider() {
            override fun getOutline(view: View, outline: Outline) {
                outline.setRoundRect(0, 0, view.width, view.height, radius)
                outline.alpha = 0.55f
            }
        }

        val iconSize = px(40f)
        val iconRadius = pxf(10f)
        icon.scaleType = ImageView.ScaleType.CENTER_CROP
        icon.outlineProvider = object : ViewOutlineProvider() {
            override fun getOutline(view: View, outline: Outline) {
                outline.setRoundRect(0, 0, view.width, view.height, iconRadius)
            }
        }
        icon.clipToOutline = true
        val iconLp = LinearLayout.LayoutParams(iconSize, iconSize)
        iconLp.marginEnd = px(10f)
        card.addView(icon, iconLp)

        val column = LinearLayout(context)
        column.orientation = LinearLayout.VERTICAL

        val header = LinearLayout(context)
        header.orientation = LinearLayout.HORIZONTAL
        header.gravity = Gravity.CENTER_VERTICAL

        appNameView.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11f)
        appNameView.setTypeface(Typeface.DEFAULT_BOLD)
        if (Build.VERSION.SDK_INT >= 28) appNameView.setAllCaps(true)
        appNameView.setLetterSpacing(0.06f)
        appNameView.maxLines = 1
        appNameView.ellipsize = TextUtils.TruncateAt.END
        header.addView(appNameView, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))

        urgentView.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11f)
        urgentView.setTypeface(Typeface.DEFAULT_BOLD)
        urgentView.setTextColor(Color.rgb(255, 149, 0))
        urgentView.text = "Khẩn cấp"
        urgentView.visibility = View.GONE
        val urgentLp = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT
        )
        urgentLp.marginStart = px(6f)
        header.addView(urgentView, urgentLp)

        timeView.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11f)
        timeView.maxLines = 1
        val timeLp = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT
        )
        timeLp.marginStart = px(8f)
        header.addView(timeView, timeLp)

        column.addView(
            header,
            LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
        )

        titleView.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15f)
        titleView.setTypeface(Typeface.DEFAULT_BOLD)
        titleView.maxLines = 1
        titleView.ellipsize = TextUtils.TruncateAt.END
        val titleLp = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
        )
        titleLp.topMargin = px(2f)
        column.addView(titleView, titleLp)

        textView.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f)
        textView.maxLines = 2
        textView.ellipsize = TextUtils.TruncateAt.END
        column.addView(
            textView,
            LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
        )

        card.addView(column, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        addView(card, LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT))

        // Start state: fully off-screen to the left and transparent.
        translationX = -screenW()
        alpha = 0f
    }

    fun bind(item: NotifItem) {
        val dark = Prefs.isDark(context)
        val glass = Prefs.glass.coerceIn(0.15f, 0.80f)
        card.background = buildBackground(dark, glass, item.timeSensitive)

        val primary = if (dark) Color.WHITE else Color.rgb(17, 17, 17)
        val secondary = if (dark) Color.argb(210, 255, 255, 255) else Color.argb(210, 0, 0, 0)
        val tertiary = if (dark) Color.argb(150, 255, 255, 255) else Color.argb(140, 0, 0, 0)
        appNameView.setTextColor(tertiary)
        timeView.setTextColor(tertiary)
        titleView.setTextColor(primary)
        textView.setTextColor(secondary)

        val name = if (item.appName.isNotBlank()) item.appName else AppIcons.label(context, item.pkg)
        appNameView.text = name
        urgentView.visibility = if (item.timeSensitive) View.VISIBLE else View.GONE
        timeView.text = relativeTime(item.time)
        titleView.text = item.title
        titleView.visibility = if (item.title.isBlank()) View.GONE else View.VISIBLE
        textView.text = item.text
        textView.visibility = if (item.text.isBlank()) View.GONE else View.VISIBLE

        val d = try { AppIcons.icon(context, item.pkg) } catch (e: Exception) { null }
        if (d != null) {
            icon.background = null
            icon.setImageDrawable(d)
        } else {
            icon.setImageDrawable(null)
            val ph = GradientDrawable()
            ph.shape = GradientDrawable.RECTANGLE
            ph.cornerRadius = pxf(10f)
            ph.setColor(if (dark) Color.argb(120, 255, 255, 255) else Color.argb(80, 0, 0, 0))
            icon.background = ph
        }
    }

    private fun relativeTime(t: Long): String {
        val age = (System.currentTimeMillis() - t) / 1000L
        return when {
            age < 60L -> "bây giờ"
            age < 3600L -> "${age / 60L} phút"
            age < 86400L -> "${age / 3600L} giờ"
            else -> "${age / 86400L} ngày"
        }
    }

    private fun buildBackground(dark: Boolean, glass: Float, urgent: Boolean): LayerDrawable {
        val r = pxf(26f)
        val baseRgb = if (dark) Color.rgb(18, 18, 22) else Color.WHITE
        val a1 = (glass * 255f).toInt().coerceIn(0, 255)
        val a2 = (glass * 0.5f * 255f).toInt().coerceIn(0, 255)

        val base = GradientDrawable()
        base.shape = GradientDrawable.RECTANGLE
        base.cornerRadius = r
        base.setColor(Color.argb(a1, Color.red(baseRgb), Color.green(baseRgb), Color.blue(baseRgb)))

        val tint = GradientDrawable(
            GradientDrawable.Orientation.TL_BR,
            intArrayOf(
                Color.argb(a2, 255, 255, 255),
                Color.argb(0, 255, 255, 255),
                Color.argb((a2 / 2).coerceIn(0, 255), baseRgb.let { Color.red(it) }, Color.green(baseRgb), Color.blue(baseRgb))
            )
        )
        tint.shape = GradientDrawable.RECTANGLE
        tint.cornerRadius = r

        val hiAlpha = if (dark) 70 else 150
        val highlight = GradientDrawable(
            GradientDrawable.Orientation.TOP_BOTTOM,
            intArrayOf(Color.argb(hiAlpha, 255, 255, 255), Color.argb(0, 255, 255, 255))
        )
        highlight.shape = GradientDrawable.RECTANGLE
        highlight.cornerRadius = r

        val border = GradientDrawable()
        border.shape = GradientDrawable.RECTANGLE
        border.cornerRadius = r
        border.setColor(Color.TRANSPARENT)
        val borderColor = when {
            urgent -> Color.argb(200, 255, 149, 0)
            dark -> Color.argb(70, 255, 255, 255)
            else -> Color.argb(180, 255, 255, 255)
        }
        border.setStroke(px(1f).coerceAtLeast(1), borderColor)

        val layers = LayerDrawable(arrayOf(base, tint, highlight, border))
        layers.setLayerHeight(2, px(28f))
        layers.setLayerGravity(2, Gravity.TOP)
        return layers
    }

    fun animateIn() {
        exiting = false
        enterAlpha?.cancel()
        val a = ObjectAnimator.ofFloat(this, View.ALPHA, 0f, 1f)
        a.duration = 260L
        enterAlpha = a
        a.start()
        animate().cancel()
        animate()
            .translationX(0f)
            .setDuration(420L)
            .setInterpolator(OvershootInterpolator(0.5f))
            .start()
    }

    fun animateOut(end: () -> Unit) {
        exiting = true
        enterAlpha?.cancel()
        animate().cancel()
        val w = if (width > 0) width.toFloat() else screenW()
        animate()
            .translationX(-(w + pxf(24f)))
            .alpha(0f)
            .setDuration(260L)
            .setInterpolator(AccelerateInterpolator())
            .withEndAction { end() }
            .start()
    }

    fun cancelAnimations() {
        enterAlpha?.cancel()
        animate().cancel()
    }

    private fun springBack() {
        animate().cancel()
        animate()
            .translationX(0f)
            .setDuration(250L)
            .setInterpolator(OvershootInterpolator(1.0f))
            .start()
    }

    override fun onTouchEvent(ev: MotionEvent): Boolean {
        if (exiting) return true
        when (ev.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                downRaw = ev.rawX
                lastRaw = ev.rawX
                lastT = ev.eventTime
                startTx = translationX
                vx = 0f
                dragging = false
                onTouchStart?.invoke()
                return true
            }
            MotionEvent.ACTION_MOVE -> {
                val dx = ev.rawX - downRaw
                if (!dragging && Math.abs(dx) > slop) {
                    dragging = true
                    cancelAnimations()
                    alpha = 1f
                }
                if (dragging) {
                    val t = startTx + dx
                    translationX = if (t <= 0f) t else t * 0.25f
                }
                val dt = ev.eventTime - lastT
                if (dt > 0L) {
                    val inst = (ev.rawX - lastRaw) / dt * 1000f
                    vx = 0.6f * inst + 0.4f * vx
                    lastRaw = ev.rawX
                    lastT = ev.eventTime
                }
                return true
            }
            MotionEvent.ACTION_UP -> {
                if (dragging) {
                    val w = (if (width > 0) width.toFloat() else screenW()).coerceAtLeast(1f)
                    if (translationX < -0.35f * w || vx < -pxf(600f)) {
                        onSwipeDismiss?.invoke()
                    } else {
                        springBack()
                        onTouchEnd?.invoke()
                    }
                } else {
                    onTap?.invoke()
                }
                dragging = false
                return true
            }
            MotionEvent.ACTION_CANCEL -> {
                if (dragging) springBack()
                dragging = false
                onTouchEnd?.invoke()
                return true
            }
        }
        return true
    }
}

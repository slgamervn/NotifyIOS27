package app.notifyios27

import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.TimeInterpolator
import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Color
import android.graphics.Outline
import android.graphics.Typeface
import android.graphics.drawable.Drawable
import android.graphics.drawable.LayerDrawable
import android.os.Build
import android.text.InputType
import android.text.TextUtils
import android.util.TypedValue
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.ViewOutlineProvider
import android.view.VelocityTracker
import android.view.animation.AccelerateInterpolator
import android.view.animation.DecelerateInterpolator
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView

/**
 * The banner card. In blur mode the window is exactly the card and motion is done by moving the window
 * (Host.place); otherwise the view is translated inside a full-width window.
 */
class BannerView(
    context: Context,
    private val blurMode: Boolean,
    private val style: Int,
    private var restY: Int
) : FrameLayout(context) {

    constructor(context: Context) : this(context, false, 0, 0)

    interface Host {
        fun place(x: Int, y: Int, blurPx: Int)

        /** Same as [place] plus the window alpha, in one layout pass. */
        fun placeA(x: Int, y: Int, blurPx: Int, alpha: Float) = place(x, y, blurPx)
    }

    var host: Host? = null
    var onTap: (() -> Unit)? = null
    var onSwipeDismiss: (() -> Unit)? = null
    var onTouchStart: (() -> Unit)? = null
    var onTouchEnd: (() -> Unit)? = null
    var onExpandChanged: (() -> Unit)? = null
    var onReplyVisible: ((Boolean) -> Unit)? = null
    var onDismissRequest: (() -> Unit)? = null
    /** Tap on the peeking layers below the card. */
    var onPeekTap: (() -> Unit)? = null
    /** Touch outside the window (needs FLAG_WATCH_OUTSIDE_TOUCH). */
    var onOutside: (() -> Unit)? = null

    var expanded = false
        private set

    private companion object {
        val DECEL: TimeInterpolator = DecelerateInterpolator()
        val ACCEL: TimeInterpolator = AccelerateInterpolator()
        val BOUNCE: TimeInterpolator = Perf.Damped(0.35f)
        val EDGE: TimeInterpolator = Perf.Damped(0.25f)
        const val MODE_NONE = 0
        const val MODE_HORIZ = 1
        const val MODE_VERT = 2
        const val MODE_DONE = 3
        const val DIR_DEFAULT = 0
        const val DIR_LEFT = 1
        const val DIR_RIGHT = 9
        const val DIR_UP = 2
    }

    private val card = LinearLayout(context)
    private val icon = ImageView(context)
    private val appNameView = TextView(context)
    private val urgentView = TextView(context)
    private val timeView = TextView(context)
    private val moonView = ImageView(context)
    private val moon = MoonDrawable(Color.WHITE)
    private val titleView = TextView(context)
    private val textView = TextView(context)
    private val stackChip = TextView(context)
    private val peeks = arrayOf(View(context), View(context))
    private var layers = 0
    private var peekDown = false
    private var vt: VelocityTracker? = null
    private var fullBlur = 0
    private var lastPx = Int.MIN_VALUE
    private var lastPy = Int.MIN_VALUE
    private var lastPb = Int.MIN_VALUE
    private var lastPa = -1f
    private var curA = 1f
    private var curS = 1f
    private var nextS = 1f
    private var lastS = 1f
    private var enter = 0
    private var exitStyle = 0
    private var curve = 0
    private var accentNow = 0
    private val details = LinearLayout(context)
    private val detailsScroll = CappedScroll(context)
    private var winW = 0

    private var cur: NotifItem? = null
    private var replyAction: NotifAction? = null
    private var replyEdit: EditText? = null

    private val slop = ViewConfiguration.get(context).scaledTouchSlop
    private var downX = 0f
    private var downY = 0f
    private var lastRawX = 0f
    private var lastRawY = 0f
    private var lastT = 0L
    private var vx = 0f
    private var vy = 0f
    private var startOx = 0f
    private var startOy = 0f
    private var mode = MODE_NONE
    private var consumed = false
    private var exiting = false
    private var exitDir = DIR_DEFAULT

    // logical offset from the rest position (px) and blur fraction 0..1
    private var curOx = 0f
    private var curOy = 0f
    private var curBlur = 0f
    private var anim: ValueAnimator? = null
    private var applyPending = false

    private val applyRunnable = Runnable {
        if (applyPending) applyNow()
    }
    private val longPress = Runnable {
        if (mode == MODE_NONE && !exiting) {
            consumed = true
            expand()
        }
    }

    private fun px(dp: Float): Int = (dp * resources.displayMetrics.density + 0.5f).toInt()
    private fun pxf(dp: Float): Float = dp * resources.displayMetrics.density
    private fun screenW(): Float = resources.displayMetrics.widthPixels.toFloat()
    private fun cardW(): Float = if (winW > 0) winW.toFloat() else screenW() - pxf(24f)

    /** Sets the window width and rest Y (px) chosen by the controller; call before prepare(). */
    fun setSpec(w: Int, y: Int) {
        winW = w
        restY = y
        applyPadding()
    }

    private fun peekSpace(): Int = layers.coerceAtLeast(0) * px(10f)

    private fun applyPadding() {
        if (!blurMode) {
            val side = ((screenW() - cardW()) / 2f).toInt().coerceAtLeast(0)
            setPadding(side, restY, side, peekSpace())
        } else {
            setPadding(0, 0, 0, peekSpace())
        }
    }

    /** Re-applies width and position after a rotation; does not touch any timer. */
    fun relayout(w: Int, y: Int) {
        setSpec(w, y)
        if (blurMode) {
            requestApply()
        } else {
            applyNow()
            requestLayout()
        }
    }

    // The expanded details scroll only when they do not fit in 85% of the screen height.
    private inner class CappedScroll(c: Context) : android.widget.ScrollView(c) {
        init {
            isVerticalScrollBarEnabled = false
            overScrollMode = View.OVER_SCROLL_NEVER
        }

        private fun canScroll(): Boolean = canScrollVertically(1) || canScrollVertically(-1)

        override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
            val cap = (resources.displayMetrics.heightPixels * 0.85f).toInt() - px(96f)
            super.onMeasure(
                widthMeasureSpec,
                MeasureSpec.makeMeasureSpec(Math.max(cap, px(80f)), MeasureSpec.AT_MOST)
            )
        }

        override fun onInterceptTouchEvent(ev: MotionEvent): Boolean =
            if (canScroll()) super.onInterceptTouchEvent(ev) else false

        override fun onTouchEvent(ev: MotionEvent): Boolean =
            if (canScroll()) super.onTouchEvent(ev) else false
    }
    private fun heightNow(): Float = if (height > 0) height.toFloat() else measuredHeight.toFloat()

    init {
        clipChildren = false
        clipToPadding = false
        if (!blurMode) setPadding(px(12f), restY, px(12f), 0)
        for (pv in peeks) {
            pv.visibility = View.GONE
            addView(pv, LayoutParams(LayoutParams.MATCH_PARENT, 0))
        }

        card.orientation = LinearLayout.VERTICAL
        card.setPadding(px(14f), px(12f), px(14f), px(12f))
        card.outlineProvider = object : ViewOutlineProvider() {
            override fun getOutline(view: View, outline: Outline) {
                outline.setRoundRect(0, 0, view.width, view.height, pxf(Theme.corner(26f)))
            }
        }
        card.clipToOutline = true

        val topRow = LinearLayout(context)
        topRow.orientation = LinearLayout.HORIZONTAL
        topRow.gravity = Gravity.TOP

        val iconSize = px(40f)
        icon.scaleType = ImageView.ScaleType.CENTER_CROP
        icon.outlineProvider = object : ViewOutlineProvider() {
            override fun getOutline(view: View, outline: Outline) {
                outline.setRoundRect(0, 0, view.width, view.height, Theme.iconRadius(view.width.toFloat()))
            }
        }
        icon.clipToOutline = true
        val iconLp = LinearLayout.LayoutParams(iconSize, iconSize)
        iconLp.marginEnd = px(10f)
        topRow.addView(icon, iconLp)

        val column = LinearLayout(context)
        column.orientation = LinearLayout.VERTICAL

        val header = LinearLayout(context)
        header.orientation = LinearLayout.HORIZONTAL
        header.gravity = Gravity.CENTER_VERTICAL

        appNameView.setTypeface(Typeface.DEFAULT_BOLD)
        if (Build.VERSION.SDK_INT >= 28) appNameView.setAllCaps(true)
        appNameView.setLetterSpacing(0.06f)
        appNameView.maxLines = 1
        appNameView.ellipsize = TextUtils.TruncateAt.END
        header.addView(appNameView, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))

        urgentView.setTypeface(Typeface.DEFAULT_BOLD)
        urgentView.setTextColor(Color.rgb(255, 149, 0))
        urgentView.text = "Khẩn cấp"
        urgentView.visibility = View.GONE
        val urgentLp = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT
        )
        urgentLp.marginStart = px(6f)
        header.addView(urgentView, urgentLp)

        stackChip.setTypeface(Typeface.DEFAULT_BOLD)
        stackChip.maxLines = 1
        stackChip.visibility = View.GONE
        stackChip.setPadding(px(6f), px(1f), px(6f), px(1f))
        val chipLp = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT
        )
        chipLp.marginStart = px(6f)
        header.addView(stackChip, chipLp)

        moonView.setImageDrawable(moon)
        moonView.visibility = View.GONE
        val moonLp = LinearLayout.LayoutParams(px(12f), px(12f))
        moonLp.marginStart = px(6f)
        header.addView(moonView, moonLp)

        timeView.maxLines = 1
        val timeLp = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT
        )
        timeLp.marginStart = px(8f)
        header.addView(timeView, timeLp)

        column.addView(
            header,
            LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
        )

        titleView.setTypeface(Typeface.DEFAULT_BOLD)
        titleView.maxLines = 1
        titleView.ellipsize = TextUtils.TruncateAt.END
        val titleLp = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
        )
        titleLp.topMargin = px(2f)
        column.addView(titleView, titleLp)

        textView.maxLines = 2
        textView.ellipsize = TextUtils.TruncateAt.END
        column.addView(
            textView,
            LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
        )

        topRow.addView(column, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        card.addView(
            topRow,
            LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
        )

        details.orientation = LinearLayout.VERTICAL
        details.visibility = View.GONE
        detailsScroll.addView(
            details,
            FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.WRAP_CONTENT)
        )
        card.addView(
            detailsScroll,
            LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
        )

        addView(card, LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT))
    }

    // ---------- content ----------

    fun bind(item: NotifItem) {
        cur = item
        val dark = Prefs.isDark(context)
        val fs = Prefs.fontScale

        val g: Drawable = Glass.drawable(context, 26f, true)
        if (item.timeSensitive) {
            val stroke = UiKit.flat(context, Color.TRANSPARENT, 26f, Color.argb(200, 255, 149, 0), 1f)
            card.background = LayerDrawable(arrayOf<Drawable>(g, stroke))
        } else {
            card.background = g
        }
        accentNow = Style.resolve(context, item).accent
        val isz = px(Prefs.iconSizeDp.toFloat())
        val ilp = icon.layoutParams
        if (ilp != null && ilp.width != isz) {
            ilp.width = isz
            ilp.height = isz
            icon.layoutParams = ilp
        }
        appNameView.typeface = Style.typeface(true)
        titleView.typeface = Style.typeface(true)
        textView.typeface = Style.typeface(false)
        stackChip.setTextSize(TypedValue.COMPLEX_UNIT_SP, 10.5f * fs)
        stackChip.setTextColor(if (dark) Color.WHITE else Color.rgb(28, 28, 30))
        stackChip.background = UiKit.flat(context, if (dark) Color.argb(46, 255, 255, 255) else Color.argb(26, 0, 0, 0), 8f)

        appNameView.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11f * fs)
        urgentView.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11f * fs)
        timeView.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11f * fs)
        titleView.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15f * fs)
        textView.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f * fs)

        val primary = if (dark) Color.WHITE else Color.rgb(17, 17, 17)
        val secondary = if (dark) Color.argb(210, 255, 255, 255) else Color.argb(210, 0, 0, 0)
        val tertiary = if (dark) Color.argb(150, 255, 255, 255) else Color.argb(140, 0, 0, 0)
        appNameView.setTextColor(tertiary)
        timeView.setTextColor(tertiary)
        titleView.setTextColor(primary)
        textView.setTextColor(secondary)

        val name = if (item.appName.isNotBlank()) item.appName else AppIcons.label(context, item.pkg)
        appNameView.text = name
        urgentView.visibility = if (item.timeSensitive) View.VISIBLE else View.GONE
        timeView.text = relativeTime(item.time)
        titleView.text = item.title
        titleView.visibility = if (item.title.isBlank()) View.GONE else View.VISIBLE
        textView.text = item.text
        textView.visibility = if (item.text.isBlank()) View.GONE else View.VISIBLE

        val d = try { AppIcons.icon(context, item.pkg) } catch (e: Exception) { null }
        if (d != null) {
            icon.background = null
            icon.setImageDrawable(d)
        } else {
            icon.setImageDrawable(null)
            icon.background = UiKit.flat(context, if (dark) Color.argb(120, 255, 255, 255) else Color.argb(80, 0, 0, 0), 10f)
        }

        if (expanded) refreshDetails()
    }

    /** Small moon beside the time while Do Not Disturb silenced this banner. */
    fun setDnd(on: Boolean) {
        moonView.visibility = if (on) View.VISIBLE else View.GONE
        if (on) moon.setColor(if (Prefs.isDark(context)) Color.argb(150, 255, 255, 255) else Color.argb(140, 0, 0, 0))
    }

    private fun relativeTime(t: Long): String {
        val age = (System.currentTimeMillis() - t) / 1000L
        return when {
            age < 60L -> "bây giờ"
            age < 3600L -> "${age / 60L} phút"
            age < 86400L -> "${age / 3600L} giờ"
            else -> "${age / 86400L} ngày"
        }
    }

    // ---------- expansion ----------

    private fun expand() {
        if (expanded) return
        expanded = true
        textView.maxLines = Int.MAX_VALUE
        textView.ellipsize = null
        titleView.maxLines = 3
        details.visibility = View.VISIBLE
        refreshDetails()
        Perf.haptic(this, Perf.H_KEY)
        onExpandChanged?.invoke()
    }

    // ---------- stack ----------

    /** Peeking layers behind the card (0..2) and the chip text ("3 tin mới", "+2"); null hides the chip. */
    fun setStack(n: Int, label: String?) {
        val l = n.coerceIn(0, 2)
        stackChip.text = label ?: ""
        stackChip.visibility = if (label.isNullOrEmpty()) View.GONE else View.VISIBLE
        if (l == layers) return
        layers = l
        for ((i, pv) in peeks.withIndex()) {
            if (i < l) {
                if (pv.background == null) pv.background = Glass.drawable(context, 26f, true)
                pv.alpha = if (i == 0) 0.8f else 0.6f
                pv.translationY = pxf(10f) * (i + 1)
                pv.visibility = View.VISIBLE
            } else {
                pv.visibility = View.GONE
            }
        }
        applyPadding()
        requestLayout()
    }

    /** Height including the peeking layers. */
    fun stackExtra(): Int = peekSpace()

    override fun onLayout(changed: Boolean, left: Int, top: Int, right: Int, bottom: Int) {
        super.onLayout(changed, left, top, right, bottom)
        for ((i, pv) in peeks.withIndex()) {
            if (pv.visibility != View.VISIBLE) continue
            pv.layout(card.left, card.top, card.right, card.bottom)
            pv.pivotX = card.width / 2f
            pv.pivotY = card.height.toFloat()
            val s = if (i == 0) 0.94f else 0.94f * 0.94f
            pv.scaleX = s
            pv.scaleY = s
        }
    }

    /** New arrival: the old card falls back into the stack while the new one comes in. */
    fun pushIn() {
        val d = Perf.dur(220L)
        card.animate().cancel()
        if (d == 0L) {
            card.alpha = 1f
            card.translationY = 0f
            card.scaleX = 1f
            card.scaleY = 1f
            return
        }
        card.alpha = 0.4f
        card.scaleX = 1.03f
        card.scaleY = 1.03f
        card.translationY = -pxf(8f)
        card.animate().alpha(1f).scaleX(1f).scaleY(1f).translationY(0f)
            .setDuration(d).setInterpolator(Perf.SPRING_SOFT).withLayer().start()
        for ((i, pv) in peeks.withIndex()) {
            if (pv.visibility != View.VISIBLE) continue
            val target = pxf(10f) * (i + 1)
            pv.translationY = target - pxf(10f)
            pv.animate().translationY(target).setDuration(d).start()
        }
    }

    /** After the top card left: snap back to rest and let the next card rise from behind. */
    fun popNext() {
        cancelAnimations()
        exiting = false
        exitDir = DIR_DEFAULT
        mode = MODE_NONE
        curOx = 0f
        curOy = 0f
        curBlur = 1f
        curA = 1f
        curS = 1f
        lastS = 1f
        applyNow()
        val d = Perf.dur(220L)
        card.animate().cancel()
        if (d == 0L) {
            card.alpha = 1f
            card.scaleX = 1f
            card.scaleY = 1f
            card.translationY = 0f
            return
        }
        card.alpha = 0.8f
        card.scaleX = 0.94f
        card.scaleY = 0.94f
        card.translationY = pxf(10f)
        card.animate().alpha(1f).scaleX(1f).scaleY(1f).translationY(0f)
            .setDuration(d).setInterpolator(Perf.SPRING).withLayer().start()
    }

    /** Back to a clean state so the same instance can show the next banner. */
    fun reset() {
        cancelAnimations()
        removeCallbacks(longPress)
        expanded = false
        replyAction = null
        replyEdit = null
        details.removeAllViews()
        details.visibility = View.GONE
        textView.maxLines = 2
        textView.ellipsize = TextUtils.TruncateAt.END
        titleView.maxLines = 1
        exiting = false
        exitDir = DIR_DEFAULT
        mode = MODE_NONE
        consumed = false
        peekDown = false
        lastPx = Int.MIN_VALUE
        lastPy = Int.MIN_VALUE
        lastPb = Int.MIN_VALUE
        lastPa = -1f
        curA = 1f
        curS = 1f
        nextS = 1f
        lastS = 1f
        card.animate().cancel()
        card.alpha = 1f
        card.scaleX = 1f
        card.scaleY = 1f
        card.translationY = 0f
        translationX = 0f
        translationY = 0f
        alpha = 1f
        host = null
        onTap = null
        onSwipeDismiss = null
        onTouchStart = null
        onTouchEnd = null
        onExpandChanged = null
        onReplyVisible = null
        onDismissRequest = null
        onPeekTap = null
        onOutside = null
        layers = -1
        for (pv in peeks) pv.background = null
        setStack(0, null)
    }

    /** Re-reads corner and icon shape after a settings change. */
    fun invalidateOutlineSafe() {
        card.invalidateOutline()
        icon.invalidateOutline()
    }

    /** True when this instance can be reused for a banner with these settings. */
    fun matches(blur: Boolean, st: Int): Boolean = blur == blurMode && st == style

    private fun chipFill(dark: Boolean): Int = if (dark) Color.rgb(50, 50, 56) else Color.rgb(232, 232, 238)

    private fun chip(label: String, onClick: () -> Unit): TextView {
        val dark = Prefs.isDark(context)
        val t = TextView(context)
        t.text = label
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f * Prefs.fontScale)
        t.setTypeface(Typeface.DEFAULT_BOLD)
        t.gravity = Gravity.CENTER
        t.maxLines = 1
        t.ellipsize = TextUtils.TruncateAt.END
        t.setTextColor(if (accentNow != 0) accentNow else UiKit.accent(context))
        t.setPadding(px(10f), px(9f), px(10f), px(9f))
        t.background = UiKit.flat(context, chipFill(dark), 14f)
        t.isClickable = true
        t.setOnClickListener {
            try { onClick() } catch (e: Exception) { }
        }
        return t
    }

    private fun refreshDetails() {
        val item = cur ?: return
        val dark = Prefs.isDark(context)
        val keepReply = replyEdit?.text?.toString()
        details.removeAllViews()
        replyEdit = null

        // big picture
        val bmp = item.bigPicture
        if (bmp != null && bmp.width > 0 && bmp.height > 0) {
            val iv = ImageView(context)
            iv.scaleType = ImageView.ScaleType.CENTER_CROP
            iv.setImageBitmap(bmp)
            val pr = pxf(14f)
            iv.outlineProvider = object : ViewOutlineProvider() {
                override fun getOutline(view: View, outline: Outline) {
                    outline.setRoundRect(0, 0, view.width, view.height, pr)
                }
            }
            iv.clipToOutline = true
            val innerW = cardW() - pxf(28f)
            val maxPic = (resources.displayMetrics.heightPixels * 0.4f).toInt()
            val h = Math.min(px(160f), (innerW * bmp.height.toFloat() / bmp.width.toFloat()).toInt())
                .coerceAtMost(maxPic)
                .coerceAtLeast(px(40f))
            val lp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, h)
            lp.topMargin = px(10f)
            details.addView(iv, lp)
        }

        // chips
        val chips = ArrayList<TextView>()
        val otp = item.otp
        if (otp != null) {
            chips.add(chip("Sao chép mã $otp") {
                ItemActions.copyOtp(context, item)
            })
        }
        chips.add(chip("Nhắc lại") {
            try { Snooze.snooze(context, item, 60) } catch (e: Exception) { }
            onDismissRequest?.invoke()
        })
        chips.add(chip("Tắt 1 giờ") {
            try { Rules.muteApp(context, item.pkg, 60) } catch (e: Exception) { }
            onDismissRequest?.invoke()
        })
        for (a in item.actions.take(3)) {
            chips.add(chip(a.title) {
                if (a.replyKey != null) {
                    showReply(a)
                } else {
                    ItemActions.runAction(context, item, a, null)
                    onDismissRequest?.invoke()
                }
            })
        }
        var i = 0
        while (i < chips.size) {
            val row = LinearLayout(context)
            row.orientation = LinearLayout.HORIZONTAL
            val left = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            left.marginEnd = px(4f)
            row.addView(chips[i], left)
            val right = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            right.marginStart = px(4f)
            if (i + 1 < chips.size) {
                row.addView(chips[i + 1], right)
            } else {
                row.addView(View(context), right)
            }
            val rlp = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
            )
            rlp.topMargin = px(8f)
            details.addView(row, rlp)
            i += 2
        }

        // reply field
        val ra = replyAction
        if (ra != null) {
            val row = LinearLayout(context)
            row.orientation = LinearLayout.HORIZONTAL
            row.gravity = Gravity.CENTER_VERTICAL

            val edit = EditText(context)
            edit.hint = "Trả lời…"
            edit.setSingleLine(true)
            edit.inputType = InputType.TYPE_CLASS_TEXT
            edit.imeOptions = EditorInfo.IME_ACTION_SEND or EditorInfo.IME_FLAG_NO_EXTRACT_UI or EditorInfo.IME_FLAG_NO_FULLSCREEN
            edit.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f * Prefs.fontScale)
            edit.setTextColor(if (dark) Color.WHITE else Color.rgb(17, 17, 17))
            edit.setHintTextColor(if (dark) Color.argb(150, 255, 255, 255) else Color.argb(140, 0, 0, 0))
            edit.setPadding(px(12f), px(8f), px(12f), px(8f))
            edit.background = UiKit.flat(context, chipFill(dark), 14f)
            if (!keepReply.isNullOrEmpty()) {
                edit.setText(keepReply)
                edit.setSelection(edit.text.length)
            }
            edit.setOnEditorActionListener { _, actionId, _ ->
                if (actionId == EditorInfo.IME_ACTION_SEND) {
                    sendReply()
                    true
                } else {
                    false
                }
            }
            replyEdit = edit
            row.addView(edit, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))

            val send = chip("Gửi") { sendReply() }
            val slp = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT
            )
            slp.marginStart = px(8f)
            row.addView(send, slp)

            val rlp = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
            )
            rlp.topMargin = px(8f)
            details.addView(row, rlp)
        }
    }

    private fun showReply(a: NotifAction) {
        replyAction = a
        refreshDetails()
        onReplyVisible?.invoke(true)
        val e = replyEdit ?: return
        e.requestFocus()
        e.postDelayed({
            try {
                val imm = context.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
                imm.showSoftInput(e, InputMethodManager.SHOW_IMPLICIT)
            } catch (ex: Exception) {
            }
        }, 250L)
    }

    private fun sendReply() {
        val a = replyAction ?: return
        val item = cur ?: return
        val t = replyEdit?.text?.toString()?.trim() ?: ""
        if (t.isEmpty()) return
        try { ItemActions.runAction(context, item, a, t) } catch (e: Exception) { }
        try {
            val imm = context.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
            imm.hideSoftInputFromWindow(windowToken, 0)
        } catch (e: Exception) {
        }
        onDismissRequest?.invoke()
    }

    // ---------- motion ----------

    private fun leftOut(): Float =
        if (blurMode) -(screenW() / 2f + cardW() / 2f + pxf(8f)) else -(screenW() + pxf(24f))

    private fun rightOut(): Float = -leftOut()

    private fun topOut(): Float =
        -(heightNow() + pxf(8f) + (if (blurMode) restY.toFloat() else 0f))

    /** Measures the card and puts it at its start (off-screen) position. Call before adding the window. */
    fun prepare() {
        fullBlur = Glass.radiusPx(context)
        val w = if (blurMode) cardW().toInt() else screenW().toInt()
        measure(
            MeasureSpec.makeMeasureSpec(w, MeasureSpec.EXACTLY),
            MeasureSpec.makeMeasureSpec(0, MeasureSpec.UNSPECIFIED)
        )
        val pe = Prefs.bannerEnter
        enter = if (style == 1 && pe == 0) 1 else pe
        exitStyle = Prefs.bannerExit
        curve = Prefs.animCurve
        curOx = if (enter == 0 || enter == 5) leftOut() else 0f
        curOy = if (enter == 1 || enter == 2) topOut() else 0f
        curBlur = 0f
        curA = 0f
        curS = if (enter == 3 && !blurMode) 0.85f else 1f
        lastS = -1f
        card.pivotX = card.measuredWidth / 2f
        card.pivotY = card.measuredHeight / 2f
        if (!blurMode) {
            translationX = curOx
            translationY = curOy
            alpha = 0f
            card.scaleX = curS
            card.scaleY = curS
        }
    }

    fun startX(): Int = curOx.toInt()
    fun startY(): Int = curOy.toInt()

    private fun applyNow() {
        applyPending = false
        if (blurMode) {
            val steps = Perf.blurSteps()
            val f = if (steps > 0) Math.round(curBlur * steps).toFloat() / steps else curBlur
            val x = curOx.toInt()
            val y = restY + curOy.toInt()
            val b = (f * fullBlur).toInt()
            // one window update per change, none for an unchanged frame
            if (x == lastPx && y == lastPy && b == lastPb && curA == lastPa) return
            lastPx = x
            lastPy = y
            lastPb = b
            lastPa = curA
            host?.placeA(x, y, b, curA)
        } else {
            translationX = curOx
            translationY = curOy
            alpha = curA
            // view scale only in the no-blur path
            if (curS != lastS) {
                lastS = curS
                card.scaleX = curS
                card.scaleY = curS
            }
        }
    }

    // At most one window update per frame while dragging.
    private fun requestApply() {
        if (!blurMode) {
            applyNow()
            return
        }
        if (!applyPending) {
            applyPending = true
            postOnAnimation(applyRunnable)
        }
    }

    private fun runMotion(
        toOx: Float,
        toOy: Float,
        toBlur: Float,
        dur: Long,
        interp: TimeInterpolator,
        fadeTo: Float,
        end: (() -> Unit)?
    ) {
        cancelAnimations()
        val fox = curOx
        val foy = curOy
        val fb = curBlur
        val fa = curA
        val ta = if (fadeTo >= 0f) fadeTo else curA
        val fs = curS
        val ts = nextS
        nextS = 1f
        if (dur <= 0L) {
            curOx = toOx
            curOy = toOy
            curBlur = toBlur.coerceIn(0f, 1f)
            curA = ta
            curS = ts
            applyNow()
            end?.invoke()
            return
        }
        if (!blurMode) setLayerType(View.LAYER_TYPE_HARDWARE, null)
        val a = ValueAnimator.ofFloat(0f, 1f)
        a.duration = dur
        a.addUpdateListener { va ->
            val t = va.animatedFraction
            val p = interp.getInterpolation(t)
            curOx = fox + (toOx - fox) * p
            curOy = foy + (toOy - foy) * p
            curBlur = (fb + (toBlur - fb) * t).coerceIn(0f, 1f)
            curA = (fa + (ta - fa) * t).coerceIn(0f, 1f)
            curS = fs + (ts - fs) * p
            applyNow()
        }
        a.addListener(object : AnimatorListenerAdapter() {
            private var cancelled = false
            override fun onAnimationCancel(animation: Animator) {
                cancelled = true
            }

            override fun onAnimationEnd(animation: Animator) {
                if (!blurMode) setLayerType(View.LAYER_TYPE_NONE, null)
                if (!cancelled) end?.invoke()
            }
        })
        anim = a
        a.start()
    }

    fun animateIn() {
        exiting = false
        val rm = Prefs.reduceMotion || Perf.lite
        val interp: TimeInterpolator = when {
            rm -> DECEL
            enter == 2 -> BOUNCE
            enter == 5 -> EDGE
            curve == 1 -> DECEL
            curve == 2 -> BOUNCE
            else -> Perf.SPRING
        }
        val ms = if (rm) 180L else if (enter == 2 || enter == 5) 520L else 420L
        runMotion(0f, 0f, 1f, Perf.dur(ms), interp, 1f, null)
    }

    fun animateOut(end: () -> Unit) {
        exiting = true
        removeCallbacks(longPress)
        val rm = Prefs.reduceMotion
        val tx: Float
        val ty: Float
        when {
            exitDir == DIR_LEFT -> { tx = leftOut(); ty = curOy }
            exitDir == DIR_RIGHT -> { tx = rightOut(); ty = curOy }
            exitDir == DIR_UP -> { tx = curOx; ty = topOut() }
            exitStyle == 1 -> { tx = curOx; ty = curOy }
            exitStyle == 2 -> {
                tx = curOx
                ty = if (blurMode) curOy - pxf(8f) else curOy
                if (!blurMode) {
                    card.pivotX = card.paddingLeft + icon.width / 2f
                    card.pivotY = card.paddingTop + icon.height / 2f
                    nextS = 0.3f
                }
            }
            enter == 1 || enter == 2 -> { tx = 0f; ty = topOut() }
            else -> { tx = leftOut(); ty = 0f }
        }
        runMotion(tx, ty, 0f, Perf.dur(if (rm) 120L else 260L), ACCEL, 0f, end)
    }

    fun cancelAnimations() {
        applyPending = false
        removeCallbacks(applyRunnable)
        anim?.cancel()
        anim = null
    }

    private fun springBack() {
        val rm = Prefs.reduceMotion || Perf.lite
        val interp: TimeInterpolator = if (rm) DECEL else Perf.SPRING
        runMotion(0f, 0f, 1f, Perf.dur(if (rm) 140L else 250L), interp, 1f, null)
    }

    private fun press(on: Boolean) {
        val s = if (on) 0.97f else 1f
        card.animate().scaleX(s).scaleY(s).setDuration(if (Perf.noMotion()) 0L else 60L).start()
    }

    override fun dispatchTouchEvent(ev: MotionEvent): Boolean {
        if (ev.actionMasked == MotionEvent.ACTION_OUTSIDE) {
            onOutside?.invoke()
            return true
        }
        return super.dispatchTouchEvent(ev)
    }

    override fun onDetachedFromWindow() {
        super.onDetachedFromWindow()
        removeCallbacks(longPress)
        cancelAnimations()
        vt?.recycle()
        vt = null
    }

    // ---------- touch ----------

    override fun onTouchEvent(ev: MotionEvent): Boolean {
        if (exiting) return true
        when (ev.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                if (layers > 0 && ev.x >= card.left && ev.x <= card.right && ev.y > card.bottom &&
                    ev.y <= card.bottom + peekSpace() + px(6f)
                ) {
                    peekDown = true
                    onTouchStart?.invoke()
                    return true
                }
                peekDown = false
                if (ev.x < card.left || ev.x > card.right || ev.y < card.top || ev.y > card.bottom) return false
                vt?.recycle()
                vt = VelocityTracker.obtain()
                vt?.addMovement(ev)
                press(true)
                downX = ev.rawX
                downY = ev.rawY
                lastRawX = ev.rawX
                lastRawY = ev.rawY
                lastT = ev.eventTime
                startOx = curOx
                startOy = curOy
                vx = 0f
                vy = 0f
                mode = MODE_NONE
                consumed = false
                onTouchStart?.invoke()
                removeCallbacks(longPress)
                postDelayed(longPress, ViewConfiguration.getLongPressTimeout().toLong())
                return true
            }
            MotionEvent.ACTION_MOVE -> {
                if (peekDown) return true
                vt?.addMovement(ev)
                val dx = ev.rawX - downX
                val dy = ev.rawY - downY
                if (mode == MODE_NONE && (Math.abs(dx) > slop || Math.abs(dy) > slop)) {
                    removeCallbacks(longPress)
                    mode = if (Math.abs(dx) > Math.abs(dy)) MODE_HORIZ else MODE_VERT
                    press(false)
                    cancelAnimations()
                    curA = 1f
                    if (!blurMode) alpha = 1f
                    curBlur = 1f
                    startOx = curOx
                    startOy = curOy
                }
                if (mode == MODE_HORIZ) {
                    val t = startOx + dx
                    curOx = t
                    requestApply()
                } else if (mode == MODE_VERT) {
                    if (dy < 0f) {
                        curOy = startOy + dy
                        requestApply()
                    } else {
                        curOy = startOy + Math.min(dy * 0.25f, pxf(12f))
                        requestApply()
                        if (!expanded && dy > pxf(28f)) {
                            consumed = true
                            mode = MODE_DONE
                            expand()
                            springBack()
                        }
                    }
                }
                return true
            }
            MotionEvent.ACTION_UP -> {
                if (peekDown) {
                    peekDown = false
                    onTouchEnd?.invoke()
                    Perf.haptic(this, Perf.H_KEY)
                    onPeekTap?.invoke()
                    return true
                }
                removeCallbacks(longPress)
                press(false)
                val tr = vt
                if (tr != null) {
                    tr.addMovement(ev)
                    tr.computeCurrentVelocity(1000)
                    vx = tr.xVelocity
                    vy = tr.yVelocity
                    tr.recycle()
                    vt = null
                }
                val w = cardW().coerceAtLeast(1f)
                val h = heightNow().coerceAtLeast(1f)
                if (consumed) {
                    if (mode != MODE_DONE && (curOx != 0f || curOy != 0f)) springBack()
                    onTouchEnd?.invoke()
                } else if (mode == MODE_HORIZ) {
                    if (curOx < -0.35f * w || vx < -pxf(600f)) {
                        exitDir = DIR_LEFT
                        Perf.haptic(this, Perf.H_CONFIRM)
                        onSwipeDismiss?.invoke()
                    } else if (curOx > 0.35f * w || vx > pxf(600f)) {
                        exitDir = DIR_RIGHT
                        Perf.haptic(this, Perf.H_CONFIRM)
                        onSwipeDismiss?.invoke()
                    } else {
                        springBack()
                        onTouchEnd?.invoke()
                    }
                } else if (mode == MODE_VERT) {
                    if (curOy < -0.25f * h || vy < -pxf(600f)) {
                        exitDir = DIR_UP
                        Perf.haptic(this, Perf.H_CONFIRM)
                        onSwipeDismiss?.invoke()
                    } else {
                        springBack()
                        onTouchEnd?.invoke()
                    }
                } else if (mode == MODE_NONE) {
                    onTap?.invoke()
                } else {
                    onTouchEnd?.invoke()
                }
                mode = MODE_NONE
                return true
            }
            MotionEvent.ACTION_CANCEL -> {
                removeCallbacks(longPress)
                press(false)
                vt?.recycle()
                vt = null
                peekDown = false
                if (mode == MODE_HORIZ || mode == MODE_VERT) springBack()
                mode = MODE_NONE
                onTouchEnd?.invoke()
                return true
            }
        }
        return true
    }
}

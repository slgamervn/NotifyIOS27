package app.notifyios27

import android.content.BroadcastReceiver
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.service.notification.NotificationListenerService

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        val c = context.applicationContext
        try {
            NotificationListenerService.requestRebind(ComponentName(c, N27ListenerService::class.java))
        } catch (e: Exception) {
        }
        try { Summary.reschedule(c) } catch (e: Exception) { }
        try { Snooze.restore(c) } catch (e: Exception) { }
    }
}

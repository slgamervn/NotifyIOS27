package app.notifyios27

import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.text.Editable
import android.text.TextUtils
import android.text.TextWatcher
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/** A tab of the Notification Center (Gần đây / Lịch sử / Thống kê). */
internal interface N27Tab {
    val view: View
    fun onShow()
    fun onHide()
    fun onStoreChanged()
    fun onTick()
}

internal object Cards {
    private const val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
    private const val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT

    fun animMs(ms: Long): Long = if (Prefs.reduceMotion) 0L else ms

    fun dialog(a: Activity): AlertDialog.Builder {
        val dark = Prefs.isDark(a)
        return AlertDialog.Builder(
            a,
            if (dark) android.R.style.Theme_DeviceDefault_Dialog_Alert
            else android.R.style.Theme_DeviceDefault_Light_Dialog_Alert
        )
    }

    fun toast(a: Context, msg: String) {
        try { Toast.makeText(a, msg, Toast.LENGTH_SHORT).show() } catch (e: Exception) { }
    }

    fun appLabel(a: Context, item: NotifItem): String =
        if (item.appName.isBlank()) AppIcons.label(a, item.pkg) else item.appName

    fun sectionHeader(a: Activity, text: String, dark: Boolean): TextView {
        val t = TextView(a)
        t.text = text
        t.textSize = 13f
        t.typeface = Typeface.DEFAULT_BOLD
        t.setTextColor(UiKit.secondary(dark))
        t.setPadding(UiKit.dp(a, 6), UiKit.dp(a, 6), 0, UiKit.dp(a, 8))
        return t
    }

    fun field(a: Activity, hint: String, dark: Boolean): EditText {
        val e = EditText(a)
        e.hint = hint
        e.textSize = 14.5f
        e.setSingleLine(true)
        e.setTextColor(UiKit.primary(dark))
        e.setHintTextColor(UiKit.secondary(dark))
        e.setPadding(UiKit.dp(a, 14), UiKit.dp(a, 10), UiKit.dp(a, 14), UiKit.dp(a, 10))
        e.background = UiKit.glass(a, 16f)
        e.imeOptions = EditorInfo.IME_ACTION_SEARCH
        return e
    }

    fun searchField(a: Activity, hint: String, dark: Boolean, onChange: (String) -> Unit): EditText {
        val e = field(a, hint, dark)
        e.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, af: Int) {}
            override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) {
                onChange(s?.toString() ?: "")
            }
        })
        return e
    }

    fun clearItem(item: NotifItem) {
        NotifStore.remove(item.key)
        if (Prefs.syncClear) {
            try { N27ListenerService.instance?.cancelNotification(item.key) } catch (e: Exception) { }
        }
    }

    fun openItem(a: Activity, item: NotifItem) {
        NotifStore.markRead(item.key)
        NotifStore.open(a, item)
    }

    fun snooze(a: Activity, item: NotifItem, minutes: Int) {
        try {
            Snooze.snooze(a, item, minutes)
            val label = when {
                minutes == 60 -> "1 giờ"
                minutes < 60 -> "$minutes phút"
                else -> "${minutes / 60} giờ ${minutes % 60} phút".replace(" 0 phút", "")
            }
            toast(a, "Sẽ nhắc lại sau $label")
        } catch (e: Exception) {
        }
    }

    fun showMenu(a: Activity, item: NotifItem) {
        val labels = ArrayList<String>()
        val acts = ArrayList<() -> Unit>()
        labels.add(if (item.pinned) "Bỏ ghim" else "Ghim")
        acts.add { NotifStore.setPinned(item.key, !item.pinned) }
        labels.add("Nhắc lại 15 phút")
        acts.add { snooze(a, item, 15) }
        labels.add("Nhắc lại 1 giờ")
        acts.add { snooze(a, item, 60) }
        labels.add("Nhắc lại tối nay")
        acts.add { snooze(a, item, Snooze.minutesUntilTonight()) }
        labels.add("Tắt app 1 giờ")
        acts.add {
            try {
                Rules.muteApp(a, item.pkg, 60)
                toast(a, "Đã tắt " + Rules.displayName(a, item.pkg) + " trong 1 giờ")
            } catch (e: Exception) {
            }
        }
        if (item.otp != null) {
            labels.add("Sao chép mã")
            acts.add { ItemActions.copyOtp(a, item) }
        }
        labels.add("Sao chép nội dung")
        acts.add {
            val txt = listOf(item.title, item.text).filter { it.isNotBlank() }.joinToString("\n")
            ItemActions.copyText(a, txt)
        }
        try {
            dialog(a).setTitle(appLabel(a, item))
                .setItems(labels.toTypedArray()) { _, which ->
                    if (which in 0 until acts.size) acts[which]()
                }.show()
        } catch (e: Exception) {
        }
    }

    private fun lp(w: Int, h: Int) = LinearLayout.LayoutParams(w, h)

    /** A notification card. [withActions] shows action buttons and the reply field. */
    fun card(
        a: Activity, item: NotifItem, dark: Boolean, withActions: Boolean,
        times: MutableList<Pair<TextView, Long>>?
    ): LinearLayout {
        val sec = UiKit.secondary(dark)
        val prim = UiKit.primary(dark)
        val acc = UiKit.accent(a)
        val card = LinearLayout(a)
        card.orientation = LinearLayout.HORIZONTAL
        card.setPadding(UiKit.dp(a, 14), UiKit.dp(a, 12), UiKit.dp(a, 14), UiKit.dp(a, 12))
        card.background = UiKit.glass(a, 24f)
        val isz = Prefs.iconSizeDp
        card.addView(UiKit.iconView(a, item.pkg, isz), lp(UiKit.dp(a, isz), UiKit.dp(a, isz)))

        val col = LinearLayout(a)
        col.orientation = LinearLayout.VERTICAL
        val top = LinearLayout(a)
        top.orientation = LinearLayout.HORIZONTAL
        top.gravity = Gravity.CENTER_VERTICAL

        if (!item.read) {
            val dot = View(a)
            dot.background = UiKit.rounded(a, acc, 4f)
            top.addView(dot, lp(UiKit.dp(a, 8), UiKit.dp(a, 8)).apply { rightMargin = UiKit.dp(a, 6) })
        }
        val name = TextView(a)
        name.text = appLabel(a, item)
        name.textSize = 12.5f
        name.setTextColor(sec)
        name.maxLines = 1
        name.ellipsize = TextUtils.TruncateAt.END
        top.addView(name, lp(0, WRAP).apply { weight = 1f })

        if (item.pinned) {
            val pin = android.widget.ImageView(a)
            pin.setImageDrawable(N27Icons.drawable(a, N27Icons.PIN, UiKit.accent(a), 14))
            top.addView(pin, lp(UiKit.dp(a, 14), UiKit.dp(a, 14)).apply { leftMargin = UiKit.dp(a, 6) })
        }
        if (item.timeSensitive) {
            val u = TextView(a)
            u.text = "Khẩn cấp"
            u.textSize = 11f
            u.typeface = Typeface.DEFAULT_BOLD
            u.setTextColor(UiKit.ORANGE)
            u.setPadding(UiKit.dp(a, 6), UiKit.dp(a, 1), UiKit.dp(a, 6), UiKit.dp(a, 1))
            u.background = UiKit.rounded(a, Color.argb(45, 255, 159, 10), 8f)
            top.addView(u, lp(WRAP, WRAP).apply { leftMargin = UiKit.dp(a, 6) })
        }
        val time = TextView(a)
        time.text = UiKit.relativeTime(item.time)
        time.textSize = 12.5f
        time.setTextColor(sec)
        times?.add(Pair(time, item.time))
        top.addView(time, lp(WRAP, WRAP).apply { leftMargin = UiKit.dp(a, 6) })
        col.addView(top, lp(MATCH, WRAP))

        if (item.title.isNotBlank()) {
            val t = TextView(a)
            t.text = item.title
            t.textSize = 15f
            t.typeface = Style.typeface(true)
            t.setTextColor(prim)
            t.maxLines = 1
            t.ellipsize = TextUtils.TruncateAt.END
            col.addView(t, lp(MATCH, WRAP).apply { topMargin = UiKit.dp(a, 2) })
        }
        if (item.text.isNotBlank()) {
            val t = TextView(a)
            t.text = item.text
            t.textSize = 14f
            t.typeface = Style.typeface(false)
            t.setTextColor(prim)
            t.maxLines = 3
            t.ellipsize = TextUtils.TruncateAt.END
            col.addView(t, lp(MATCH, WRAP).apply { topMargin = UiKit.dp(a, 1) })
        }

        if (withActions && item.actions.isNotEmpty()) {
            val plain = item.actions.filter { it.replyKey == null }.take(3)
            val reply = item.actions.firstOrNull { it.replyKey != null }
            if (plain.isNotEmpty()) {
                val row = LinearLayout(a)
                row.orientation = LinearLayout.HORIZONTAL
                for ((idx, act) in plain.withIndex()) {
                    val b = UiKit.pillButton(a, act.title, false)
                    b.maxLines = 1
                    b.ellipsize = TextUtils.TruncateAt.END
                    b.setOnClickListener {
                        val ok = try { ItemActions.runAction(a, item, act, null) } catch (e: Exception) { false }
                        if (ok) NotifStore.markRead(item.key)
                    }
                    row.addView(b, lp(0, WRAP).apply {
                        weight = 1f
                        if (idx > 0) leftMargin = UiKit.dp(a, 6)
                    })
                }
                col.addView(row, lp(MATCH, WRAP).apply { topMargin = UiKit.dp(a, 8) })
            }
            if (reply != null) {
                val row = LinearLayout(a)
                row.orientation = LinearLayout.HORIZONTAL
                row.gravity = Gravity.CENTER_VERTICAL
                val et = field(a, "Trả lời…", dark)
                et.imeOptions = EditorInfo.IME_ACTION_SEND
                row.addView(et, lp(0, WRAP).apply { weight = 1f })
                val send = UiKit.pillButton(a, "Gửi", true)
                send.setOnClickListener {
                    val txt = et.text.toString().trim()
                    if (txt.isNotEmpty()) {
                        val ok = try { ItemActions.runAction(a, item, reply, txt) } catch (e: Exception) { false }
                        if (ok) {
                            et.setText("")
                            NotifStore.markRead(item.key)
                            toast(a, "Đã gửi")
                        } else {
                            toast(a, "Không gửi được")
                        }
                    }
                }
                row.addView(send, lp(WRAP, WRAP).apply { leftMargin = UiKit.dp(a, 6) })
                col.addView(row, lp(MATCH, WRAP).apply { topMargin = UiKit.dp(a, 8) })
            }
        }
        card.addView(col, lp(0, WRAP).apply {
            weight = 1f
            leftMargin = UiKit.dp(a, 12)
        })
        return card
    }
}

/**
 * A card that can be swiped: left reveals "Xóa" (long swipe clears), right (when [onSnooze] is set)
 * triggers "Nhắc lại"; tap calls [onTap]; long press calls [onLong].
 */
internal class N27SwipeRow(
    ctx: Context,
    private val card: View,
    private val onTap: () -> Unit,
    private val onClear: () -> Unit,
    private val onSnooze: (() -> Unit)? = null,
    private val onLong: (() -> Unit)? = null
) : FrameLayout(ctx) {
    private val slop = ViewConfiguration.get(ctx).scaledTouchSlop
    private val revealW = UiKit.dp(ctx, 88)
    private val del = TextView(ctx)
    private val snz = TextView(ctx)
    private var downX = 0f
    private var downY = 0f
    private var startTx = 0f
    private var dragging = false
    private var done = false
    private var longFired = false
    private val longRun = Runnable {
        if (!dragging && !done) {
            longFired = true
            try { performHapticFeedback(HapticFeedbackConstants.LONG_PRESS) } catch (e: Exception) { }
            onLong?.invoke()
        }
    }

    init {
        del.text = "Xóa"
        del.textSize = 15f
        del.typeface = Typeface.DEFAULT_BOLD
        del.setTextColor(Color.WHITE)
        del.gravity = Gravity.CENTER
        del.background = UiKit.rounded(ctx, UiKit.RED, 24f)
        snz.text = "Nhắc lại"
        snz.textSize = 15f
        snz.typeface = Typeface.DEFAULT_BOLD
        snz.setTextColor(Color.WHITE)
        snz.gravity = Gravity.CENTER
        snz.background = UiKit.rounded(ctx, UiKit.accent(ctx), 24f)
        addView(del, FrameLayout.LayoutParams(revealW, ViewGroup.LayoutParams.MATCH_PARENT, Gravity.END))
        addView(snz, FrameLayout.LayoutParams(revealW, ViewGroup.LayoutParams.MATCH_PARENT, Gravity.START))
        addView(card, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        del.visibility = View.INVISIBLE
        snz.visibility = View.INVISIBLE
        del.setOnClickListener { dismiss() }
    }

    private fun syncBg() {
        val t = card.translationX
        if (t < 0f) {
            snz.visibility = View.INVISIBLE
            del.visibility = View.VISIBLE
            val w = max(revealW, (-t).toInt())
            val p = del.layoutParams
            if (p.width != w) {
                p.width = w
                del.layoutParams = p
            }
            del.alpha = min(1f, -t / revealW)
        } else if (t > 0f && onSnooze != null) {
            del.visibility = View.INVISIBLE
            snz.visibility = View.VISIBLE
            val w = max(revealW, t.toInt())
            val p = snz.layoutParams
            if (p.width != w) {
                p.width = w
                snz.layoutParams = p
            }
            snz.alpha = min(1f, t / revealW)
        } else {
            del.visibility = View.INVISIBLE
            snz.visibility = View.INVISIBLE
        }
    }

    private fun animateTo(target: Float, end: (() -> Unit)? = null) {
        card.animate().translationX(target).setDuration(Cards.animMs(160L))
            .setUpdateListener { syncBg() }
            .withEndAction {
                syncBg()
                end?.invoke()
            }
            .start()
    }

    private fun dismiss() {
        if (done) return
        done = true
        card.animate().translationX(-width.toFloat()).setDuration(Cards.animMs(160L))
            .setUpdateListener { syncBg() }
            .withEndAction { onClear() }
            .start()
    }

    private fun snoozeNow() {
        if (done) return
        done = true
        animateTo(0f) { onSnooze?.invoke() }
    }

    private fun settle() {
        val t = card.translationX
        if (t < -width * 0.55f) dismiss()
        else if (t < -revealW * 0.5f) animateTo(-revealW.toFloat())
        else if (onSnooze != null && t > width * 0.35f) snoozeNow()
        else animateTo(0f)
    }

    override fun onDetachedFromWindow() {
        removeCallbacks(longRun)
        super.onDetachedFromWindow()
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                downX = e.rawX
                downY = e.rawY
                startTx = card.translationX
                dragging = false
                longFired = false
                removeCallbacks(longRun)
                if (onLong != null && !done) {
                    postDelayed(longRun, ViewConfiguration.getLongPressTimeout().toLong())
                }
                return true
            }
            MotionEvent.ACTION_MOVE -> {
                val dx = e.rawX - downX
                val dy = e.rawY - downY
                if (!dragging && !longFired && abs(dx) > slop && abs(dx) > abs(dy)) {
                    dragging = true
                    removeCallbacks(longRun)
                    parent?.requestDisallowInterceptTouchEvent(true)
                }
                if (!dragging && (abs(dx) > slop || abs(dy) > slop)) removeCallbacks(longRun)
                if (dragging && !done) {
                    val raw = startTx + dx
                    card.translationX =
                        if (onSnooze != null) min(raw, width * 0.6f) else min(0f, raw)
                    syncBg()
                }
                return true
            }
            MotionEvent.ACTION_UP -> {
                removeCallbacks(longRun)
                if (dragging) {
                    settle()
                } else if (!longFired && abs(e.rawX - downX) < slop && abs(e.rawY - downY) < slop) {
                    if (card.translationX < -1f) animateTo(0f) else onTap()
                }
                dragging = false
                return true
            }
            MotionEvent.ACTION_CANCEL -> {
                removeCallbacks(longRun)
                if (dragging) settle()
                dragging = false
                return true
            }
        }
        return super.onTouchEvent(e)
    }
}

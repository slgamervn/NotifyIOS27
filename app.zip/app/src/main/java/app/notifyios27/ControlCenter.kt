package app.notifyios27

import android.app.Activity
import android.app.KeyguardManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.res.Configuration
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.Icon
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.provider.Settings
import android.service.quicksettings.Tile
import android.service.quicksettings.TileService
import android.view.Gravity
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView

/** Three-zone gestures: top-left strip opens the floating Notification Center, top-right the Control Center. */
object ControlCenter {
    private val main = Handler(Looper.getMainLooper())
    private var app: Context? = null
    private var started = false
    private var left: View? = null
    private var right: View? = null
    private var panel: PanelRoot? = null

    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            if (intent?.action == Intent.ACTION_SCREEN_OFF) close()
            sync()
        }
    }

    fun start(c: Context) {
        val ctx = c.applicationContext ?: c
        main.post {
            app = ctx
            if (!started) {
                started = true
                try {
                    val f = IntentFilter()
                    f.addAction(Intent.ACTION_SCREEN_ON)
                    f.addAction(Intent.ACTION_SCREEN_OFF)
                    f.addAction(Intent.ACTION_USER_PRESENT)
                    f.addAction(Intent.ACTION_CONFIGURATION_CHANGED)
                    if (Build.VERSION.SDK_INT >= 33) ctx.registerReceiver(receiver, f, Context.RECEIVER_NOT_EXPORTED)
                    else ctx.registerReceiver(receiver, f)
                } catch (e: Throwable) {
                }
            }
            sync()
        }
    }

    private fun canOverlay(c: Context): Boolean = try { Settings.canDrawOverlays(c) } catch (e: Throwable) { false }

    private fun stripsWanted(c: Context): Boolean {
        return try {
            if (!Prefs.ccOverlay || !Prefs.appEnabled || !canOverlay(c)) return false
            val pm = c.getSystemService(Context.POWER_SERVICE) as PowerManager
            if (!pm.isInteractive) return false
            val km = c.getSystemService(Context.KEYGUARD_SERVICE) as KeyguardManager
            if (km.isKeyguardLocked) return false
            c.resources.configuration.orientation != Configuration.ORIENTATION_LANDSCAPE
        } catch (e: Throwable) {
            false
        }
    }

    /** Adds or removes the two trigger strips to match the current state. */
    fun sync() {
        main.post {
            val c = app ?: return@post
            if (stripsWanted(c) && panel == null) {
                if (left == null) left = addStrip(c, false)
                if (right == null) right = addStrip(c, true)
            } else {
                removeStrips()
            }
        }
    }

    private fun statusBar(c: Context): Int {
        val id = c.resources.getIdentifier("status_bar_height", "dimen", "android")
        val h = if (id > 0) c.resources.getDimensionPixelSize(id) else 0
        return if (h > 0) h else UiKit.dp(c, 24)
    }

    private fun addStrip(c: Context, isRight: Boolean): View? {
        return try {
            val wm = c.getSystemService(Context.WINDOW_SERVICE) as WindowManager
            val v = Strip(c) { if (isRight) openPanel(c) else openCenter(c) }
            val lp = WindowManager.LayoutParams(
                UiKit.dp(c, 100), statusBar(c),
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                    WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT
            )
            lp.gravity = Gravity.TOP or (if (isRight) Gravity.END else Gravity.START)
            // right under the system bar, which keeps its own touches
            lp.y = statusBar(c)
            if (Build.VERSION.SDK_INT >= 28) {
                lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            }
            wm.addView(v, lp)
            v
        } catch (e: Throwable) {
            null
        }
    }

    private fun removeStrips() {
        val c = app ?: return
        val wm = c.getSystemService(Context.WINDOW_SERVICE) as WindowManager
        left?.let { try { wm.removeViewImmediate(it) } catch (e: Throwable) { } }
        right?.let { try { wm.removeViewImmediate(it) } catch (e: Throwable) { } }
        left = null
        right = null
    }

    private class Strip(c: Context, private val fire: () -> Unit) : View(c) {
        private val trigger = UiKit.dp(c, 48)
        private var y0 = 0f
        private var fired = false

        override fun onTouchEvent(e: MotionEvent): Boolean {
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    y0 = e.rawY
                    fired = false
                }
                MotionEvent.ACTION_MOVE -> if (!fired && e.rawY - y0 >= trigger) {
                    fired = true
                    Perf.haptic(this, Perf.H_KEY)
                    fire()
                }
            }
            return true
        }
    }

    // ================= panel window =================

    private class PanelRoot(c: Context) : FrameLayout(c) {
        var onClose: (() -> Unit)? = null
        var sheet: View? = null
        private var y0 = 0f
        private val slop = ViewConfiguration.get(c).scaledTouchSlop

        override fun dispatchKeyEvent(event: KeyEvent): Boolean {
            if (event.keyCode == KeyEvent.KEYCODE_BACK) {
                if (event.action == KeyEvent.ACTION_UP) onClose?.invoke()
                return true
            }
            return super.dispatchKeyEvent(event)
        }

        override fun onInterceptTouchEvent(e: MotionEvent): Boolean {
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> y0 = e.rawY
                MotionEvent.ACTION_MOVE -> if (y0 - e.rawY > slop * 3 && sheet?.canScrollVertically(1) != true) return true
            }
            return false
        }

        override fun onTouchEvent(e: MotionEvent): Boolean {
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> y0 = e.rawY
                MotionEvent.ACTION_UP -> {
                    val s = sheet
                    val up = y0 - e.rawY > UiKit.dp(context, 48)
                    val outside = s == null || e.y < s.top || e.y > s.bottom || e.x < s.left || e.x > s.right
                    if (up || outside) onClose?.invoke()
                }
            }
            return true
        }
    }

    fun openPanel(c: Context) = open(c, true)

    fun openCenter(c: Context) = open(c, false)

    private fun open(c: Context, controls: Boolean) {
        val ctx = c.applicationContext ?: c
        main.post {
            app = ctx
            if (panel != null) return@post
            if (!canOverlay(ctx)) {
                removeStrips()
                return@post
            }
            try {
                val wm = ctx.getSystemService(Context.WINDOW_SERVICE) as WindowManager
                val root = PanelRoot(ctx)
                root.setBackgroundColor(if (Glass.blurSupported(ctx)) Color.argb(40, 0, 0, 0) else Color.argb(110, 0, 0, 0))
                root.isFocusableInTouchMode = true
                val ins = UiKit.safeInsets(ctx)
                val scroll = ScrollView(ctx)
                scroll.isVerticalScrollBarEnabled = false
                scroll.overScrollMode = View.OVER_SCROLL_NEVER
                val content: View = if (controls) ControlCenterPanel(ctx) { close() }
                else FloatingCenter(ctx) { close() }.also { it.background = Glass.drawable(ctx, 26f, true) }
                scroll.addView(content, FrameLayout.LayoutParams(-1, -2))
                val w = Math.min(UiKit.screenSize(ctx)[0] - UiKit.dp(ctx, 24), UiKit.dp(ctx, 420))
                val slp = FrameLayout.LayoutParams(w, -2, Gravity.TOP or Gravity.CENTER_HORIZONTAL)
                slp.topMargin = ins[1] + UiKit.dp(ctx, 8)
                slp.bottomMargin = ins[3] + UiKit.dp(ctx, 8)
                root.addView(scroll, slp)
                root.sheet = scroll
                root.onClose = { close() }
                val lp = WindowManager.LayoutParams(
                    WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT,
                    WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                    PixelFormat.TRANSLUCENT
                )
                if (Build.VERSION.SDK_INT >= 28) {
                    lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
                }
                Glass.applyBlur(ctx, lp)
                removeStrips()
                wm.addView(root, lp)
                panel = root
                root.requestFocus()
                val d = Perf.dur(260L)
                if (d > 0L) {
                    scroll.translationY = -UiKit.dpf(ctx, 40f)
                    scroll.alpha = 0f
                    scroll.animate().translationY(0f).alpha(1f).setDuration(d).setInterpolator(Perf.SPRING).withLayer().start()
                }
            } catch (e: Throwable) {
                panel = null
                sync()
            }
        }
    }

    fun close() {
        main.post {
            val p = panel ?: return@post
            panel = null
            val c = app ?: p.context
            val wm = c.getSystemService(Context.WINDOW_SERVICE) as WindowManager
            val s = p.sheet
            val d = Perf.dur(180L)
            if (s != null && d > 0L) {
                s.animate().translationY(-UiKit.dpf(c, 40f)).alpha(0f).setDuration(d).withEndAction {
                    try { wm.removeViewImmediate(p) } catch (e: Throwable) { }
                }.start()
            } else {
                try { wm.removeViewImmediate(p) } catch (e: Throwable) { }
            }
            sync()
        }
    }

    // ================= in-app =================

    private var inApp: FrameLayout? = null

    /** Shows the Control Center inside an activity (header button, Quick Settings tile). */
    fun showInApp(a: Activity) {
        if (inApp != null) return
        try {
            val decor = a.window.decorView as ViewGroup
            val root = FrameLayout(a)
            root.setBackgroundColor(Color.argb(120, 0, 0, 0))
            root.isClickable = true
            val ins = UiKit.safeInsets(a)
            val scroll = ScrollView(a)
            scroll.isVerticalScrollBarEnabled = false
            val panelView = ControlCenterPanel(a) { closeInApp() }
            scroll.addView(panelView, FrameLayout.LayoutParams(-1, -2))
            val w = Math.min(UiKit.screenSize(a)[0] - UiKit.dp(a, 24), UiKit.dp(a, 420))
            root.addView(scroll, FrameLayout.LayoutParams(w, -2, Gravity.TOP or Gravity.CENTER_HORIZONTAL).apply {
                topMargin = ins[1] + UiKit.dp(a, 8)
                bottomMargin = ins[3] + UiKit.dp(a, 8)
            })
            root.setOnClickListener { closeInApp() }
            decor.addView(root, FrameLayout.LayoutParams(-1, -1))
            inApp = root
            val d = Perf.dur(240L)
            if (d > 0L) {
                scroll.translationY = -UiKit.dpf(a, 40f)
                scroll.alpha = 0f
                scroll.animate().translationY(0f).alpha(1f).setDuration(d).setInterpolator(Perf.SPRING).start()
            }
        } catch (e: Throwable) {
            inApp = null
        }
    }

    /** Returns true when an in-app panel was open and is now closed. */
    fun closeInApp(): Boolean {
        val r = inApp ?: return false
        inApp = null
        try { (r.parent as? ViewGroup)?.removeView(r) } catch (e: Throwable) { }
        return true
    }
}

class CcTileService : TileService() {
    override fun onStartListening() {
        super.onStartListening()
        val t = qsTile ?: return
        try {
            t.state = Tile.STATE_INACTIVE
            t.label = "Trung tâm điều khiển"
            t.icon = Icon.createWithResource(this, R.drawable.n27w_tile_bell)
            t.updateTile()
        } catch (e: Throwable) {
        }
    }

    @Suppress("DEPRECATION")
    override fun onClick() {
        super.onClick()
        val i = Intent(this, MainActivity::class.java)
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
        i.putExtra(MainActivity.EXTRA_OPEN_CC, true)
        try {
            if (Build.VERSION.SDK_INT >= 34) {
                val pi = PendingIntent.getActivity(this, 31, i, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
                startActivityAndCollapse(pi)
            } else {
                startActivityAndCollapse(i)
            }
        } catch (e: Throwable) {
        }
    }
}

class ControlCenterPage : SettingsPage {
    override val title: String = "Trung tâm điều khiển"
    private var box: LinearLayout? = null

    override fun build(a: Activity, push: (SettingsPage) -> Unit): View {
        val b = LinearLayout(a)
        b.orientation = LinearLayout.VERTICAL
        box = b
        fill(a, b)
        return b
    }

    override fun onResume() {
        ControlCenter.sync()
    }

    private fun arrow(a: Activity, up: Boolean, onClick: () -> Unit): View {
        val dark = Prefs.isDark(a)
        val v = object : View(a) {
            private val p = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG)
            override fun onDraw(canvas: android.graphics.Canvas) {
                p.color = UiKit.primary(dark)
                p.strokeWidth = UiKit.dpf(a, 2f)
                p.strokeCap = android.graphics.Paint.Cap.ROUND
                val cx = width / 2f
                val cy = height / 2f
                val s = UiKit.dpf(a, 5f)
                val dy = if (up) -s / 2f else s / 2f
                canvas.drawLine(cx - s, cy - dy, cx, cy + dy, p)
                canvas.drawLine(cx, cy + dy, cx + s, cy - dy, p)
            }
        }
        v.setOnClickListener {
            Perf.haptic(v, Perf.H_TICK)
            onClick()
        }
        return v
    }

    private fun fill(a: Activity, b: LinearLayout) {
        b.removeAllViews()
        val dark = Prefs.isDark(a)
        val match = ViewGroup.LayoutParams.MATCH_PARENT
        val wrap = ViewGroup.LayoutParams.WRAP_CONTENT

        val s1 = SettingsKit.section(a, null)
        s1.addView(SettingsKit.switchRow(a, "Vuốt từ góc trên", "Góc trái mở thông báo, góc phải mở trung tâm điều khiển", Prefs.ccOverlay) { on ->
            if (on && !(try { Settings.canDrawOverlays(a) } catch (e: Exception) { false })) {
                UiKit.openOverlay(a)
            }
            Prefs.ccOverlay = on
            ControlCenter.start(a)
            ControlCenter.sync()
        })
        s1.addView(settingsCaption(a, "Hai dải trong suốt rộng 100 dp nằm ngay dưới thanh trạng thái ở hai góc trên, che một phần nhỏ màn hình. Chỉ có khi màn hình mở khoá và đang dọc."))
        s1.addView(SettingsKit.buttonRow(a, "Mở thử", null) { ControlCenter.showInApp(a) })
        b.addView(s1, LinearLayout.LayoutParams(match, wrap))
        b.addView(SettingsKit.spacer(a, 16))

        val s2 = SettingsKit.section(a, "Mô-đun")
        val list = CcModules.load()
        for ((i, m) in list.withIndex()) {
            val row = LinearLayout(a)
            row.orientation = LinearLayout.HORIZONTAL
            row.gravity = Gravity.CENTER_VERTICAL
            row.setPadding(UiKit.dp(a, 16), UiKit.dp(a, 6), UiKit.dp(a, 8), UiKit.dp(a, 6))
            row.minimumHeight = UiKit.dp(a, 48)
            val l = TextView(a)
            l.text = CcModules.label(m.first)
            l.textSize = 16f
            l.setTextColor(UiKit.primary(dark))
            row.addView(l, LinearLayout.LayoutParams(0, wrap, 1f))
            val sw = Switch(a)
            sw.isChecked = m.second
            sw.setOnCheckedChangeListener { _, on ->
                val cur = CcModules.load()
                val idx = cur.indexOfFirst { it.first == m.first }
                if (idx >= 0) cur[idx] = Pair(m.first, on)
                CcModules.save(cur)
            }
            row.addView(sw, LinearLayout.LayoutParams(wrap, wrap))
            val size = UiKit.dp(a, 36)
            row.addView(arrow(a, true) {
                if (i > 0) {
                    val cur = CcModules.load()
                    val t = cur[i - 1]; cur[i - 1] = cur[i]; cur[i] = t
                    CcModules.save(cur)
                    fill(a, b)
                }
            }, LinearLayout.LayoutParams(size, size).apply { leftMargin = UiKit.dp(a, 4) })
            row.addView(arrow(a, false) {
                if (i < list.size - 1) {
                    val cur = CcModules.load()
                    val t = cur[i + 1]; cur[i + 1] = cur[i]; cur[i] = t
                    CcModules.save(cur)
                    fill(a, b)
                }
            }, LinearLayout.LayoutParams(size, size))
            s2.addView(row)
        }
        b.addView(s2, LinearLayout.LayoutParams(match, wrap))
        b.addView(SettingsKit.spacer(a, 16))
        val note = settingsCaption(a, "Wi-Fi, Bluetooth và dữ liệu di động chỉ mở bảng của hệ thống: Android không cho ứng dụng tự bật tắt chúng.")
        b.addView(note)
    }
}

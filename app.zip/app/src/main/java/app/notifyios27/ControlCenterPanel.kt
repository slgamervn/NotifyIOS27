package app.notifyios27

import android.app.NotificationManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Typeface
import android.media.AudioManager
import android.media.MediaMetadata
import android.media.session.MediaController
import android.media.session.MediaSessionManager
import android.media.session.PlaybackState
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.provider.Settings
import android.text.TextUtils
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import org.json.JSONArray
import org.json.JSONObject

/** Control Center modules: ids, labels, user order and visibility (Prefs.ccModules). */
internal object CcModules {
    val ALL = listOf(
        "media", "volume", "connect", "torch", "timer", "calc", "camera",
        "ringer", "bright", "rotate", "saver", "banner", "island", "lock"
    )

    fun label(id: String): String = when (id) {
        "media" -> "Đang phát"
        "volume" -> "Âm lượng"
        "connect" -> "Kết nối"
        "torch" -> "Đèn pin"
        "timer" -> "Hẹn giờ"
        "calc" -> "Máy tính"
        "camera" -> "Máy ảnh"
        "ringer" -> "Chế độ chuông"
        "bright" -> "Độ sáng"
        "rotate" -> "Xoay màn hình"
        "saver" -> "Tiết kiệm pin"
        "banner" -> "Banner"
        "island" -> "Dynamic Island"
        "lock" -> "Màn hình khoá"
        else -> id
    }

    fun load(): MutableList<Pair<String, Boolean>> {
        val out = ArrayList<Pair<String, Boolean>>()
        try {
            val raw = Prefs.ccModules
            if (raw.isNotBlank()) {
                val arr = JSONArray(raw)
                for (i in 0 until arr.length()) {
                    val o = arr.getJSONObject(i)
                    val id = o.optString("id")
                    if (id in ALL && out.none { it.first == id }) out.add(Pair(id, o.optBoolean("on", true)))
                }
            }
        } catch (e: Exception) {
        }
        for (id in ALL) if (out.none { it.first == id }) out.add(Pair(id, true))
        return out
    }

    fun save(list: List<Pair<String, Boolean>>) {
        val arr = JSONArray()
        for (p in list) {
            val o = JSONObject()
            o.put("id", p.first)
            o.put("on", p.second)
            arr.put(o)
        }
        Prefs.ccModules = arr.toString()
    }
}

/** Code-drawn glyphs for the Control Center, in a 24 x 24 box. */
internal object CcGlyph {
    fun draw(cv: Canvas, id: String, p: Paint, path: Path, rf: RectF, color: Int, cut: Int, ringer: Int) {
        p.color = color
        p.strokeCap = Paint.Cap.ROUND
        p.strokeJoin = Paint.Join.ROUND
        p.style = Paint.Style.STROKE
        p.strokeWidth = 2.2f
        when (id) {
            "connect" -> {
                for (i in 1..3) {
                    val r = 3.5f + i * 3.6f
                    rf.set(12f - r, 18f - r, 12f + r, 18f + r)
                    cv.drawArc(rf, 225f, 90f, false, p)
                }
                p.style = Paint.Style.FILL
                cv.drawCircle(12f, 18f, 1.8f, p)
            }
            "torch" -> IslandGlyphs.draw(cv, IslandGlyphs.FLASH, p, path, rf, color, cut, 0.7f)
            "timer" -> IslandGlyphs.draw(cv, IslandGlyphs.TIMER, p, path, rf, color, cut, 0.7f)
            "saver" -> IslandGlyphs.draw(cv, IslandGlyphs.BATTERY, p, path, rf, color, cut, 0.5f)
            "ringer" -> IslandGlyphs.draw(
                cv, when (ringer) {
                    AudioManager.RINGER_MODE_VIBRATE -> IslandGlyphs.VIBRATE
                    AudioManager.RINGER_MODE_SILENT -> IslandGlyphs.BELL_SLASH
                    else -> IslandGlyphs.BELL
                }, p, path, rf, color, cut, 0.7f
            )
            "calc" -> {
                rf.set(5f, 3f, 19f, 21f)
                cv.drawRoundRect(rf, 3f, 3f, p)
                cv.drawLine(8f, 7.5f, 16f, 7.5f, p)
                p.style = Paint.Style.FILL
                for (r in 0..2) for (c in 0..2) cv.drawCircle(8.5f + c * 3.5f, 11.5f + r * 3.2f, 1.1f, p)
            }
            "camera" -> {
                rf.set(3f, 7f, 21f, 19f)
                cv.drawRoundRect(rf, 3f, 3f, p)
                cv.drawCircle(12f, 13f, 3.4f, p)
                cv.drawLine(8f, 7f, 9.5f, 4.5f, p)
                cv.drawLine(9.5f, 4.5f, 14.5f, 4.5f, p)
                cv.drawLine(14.5f, 4.5f, 16f, 7f, p)
            }
            "bright" -> {
                cv.drawCircle(12f, 12f, 4f, p)
                for (i in 0 until 8) {
                    val a = Math.toRadians(i * 45.0)
                    val c = Math.cos(a).toFloat()
                    val s = Math.sin(a).toFloat()
                    cv.drawLine(12f + c * 6.8f, 12f + s * 6.8f, 12f + c * 9f, 12f + s * 9f, p)
                }
            }
            "rotate" -> {
                rf.set(4f, 4f, 20f, 20f)
                cv.drawArc(rf, 200f, 290f, false, p)
                cv.drawLine(4.6f, 8.5f, 4.2f, 4.5f, p)
                cv.drawLine(4.6f, 8.5f, 8.4f, 7.6f, p)
                rf.set(9f, 11f, 15f, 16f)
                cv.drawRoundRect(rf, 1f, 1f, p)
                rf.set(10.2f, 8f, 13.8f, 12f)
                cv.drawArc(rf, 180f, 180f, false, p)
            }
            "banner" -> {
                rf.set(3f, 5f, 21f, 13f)
                cv.drawRoundRect(rf, 3f, 3f, p)
                cv.drawLine(5f, 17f, 19f, 17f, p)
                cv.drawLine(5f, 20.5f, 14f, 20.5f, p)
            }
            "island" -> {
                p.style = Paint.Style.FILL
                rf.set(4f, 9f, 20f, 15f)
                cv.drawRoundRect(rf, 3f, 3f, p)
            }
            "lock" -> {
                rf.set(6f, 10.5f, 18f, 20f)
                cv.drawRoundRect(rf, 2.5f, 2.5f, p)
                rf.set(8.5f, 4f, 15.5f, 13f)
                cv.drawArc(rf, 180f, 180f, false, p)
                cv.drawLine(8.5f, 8.5f, 8.5f, 10.5f, p)
                cv.drawLine(15.5f, 8.5f, 15.5f, 10.5f, p)
            }
            "panel" -> {
                // two switch tracks: the Control Center sign
                rf.set(3f, 4f, 21f, 10f)
                cv.drawRoundRect(rf, 3f, 3f, p)
                rf.set(3f, 14f, 21f, 20f)
                cv.drawRoundRect(rf, 3f, 3f, p)
                p.style = Paint.Style.FILL
                cv.drawCircle(17.5f, 7f, 2f, p)
                cv.drawCircle(6.5f, 17f, 2f, p)
            }
        }
        p.style = Paint.Style.FILL
    }
}

/** 20 dp Control Center sign for the app header. */
internal class CcIcon(c: Context, private val color: Int) : android.graphics.drawable.Drawable() {
    private val size = UiKit.dp(c, 20)
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val path = Path()
    private val rf = RectF()

    override fun getIntrinsicWidth(): Int = size
    override fun getIntrinsicHeight(): Int = size

    override fun draw(canvas: Canvas) {
        val b = bounds
        val s = b.width() / 24f
        canvas.save()
        canvas.translate(b.left.toFloat(), b.top.toFloat())
        canvas.scale(s, s)
        CcGlyph.draw(canvas, "panel", p, path, rf, color, Color.TRANSPARENT, 0)
        canvas.restore()
    }

    override fun setAlpha(alpha: Int) {}
    override fun setColorFilter(colorFilter: android.graphics.ColorFilter?) {}
    @Suppress("OVERRIDE_DEPRECATION")
    override fun getOpacity(): Int = android.graphics.PixelFormat.TRANSLUCENT
}

/** A square glass tile with a glyph; accent fill when on. */
internal class CcTile(c: Context, private val id: String, private val sizePx: Int) : View(c) {
    var on = false
        set(v) {
            field = v
            invalidate()
        }
    var ringer = AudioManager.RINGER_MODE_NORMAL
        set(v) {
            field = v
            invalidate()
        }
    private val dark = Prefs.isDark(c)
    private val accent = UiKit.accent(c)
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val gp = Paint(Paint.ANTI_ALIAS_FLAG)
    private val path = Path()
    private val rf = RectF()
    private val box = RectF()

    init {
        isClickable = true
        Perf.pressable(this)
    }

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        setMeasuredDimension(sizePx, sizePx)
    }

    override fun onDraw(canvas: Canvas) {
        val s = sizePx.toFloat()
        box.set(0f, 0f, s, s)
        p.style = Paint.Style.FILL
        p.color = if (on) accent else if (dark) Color.argb(46, 255, 255, 255) else Color.argb(22, 0, 0, 0)
        val r = s * 0.3f
        canvas.drawRoundRect(box, r, r, p)
        val fg = if (on) Color.WHITE else UiKit.primary(dark)
        val gs = s * 0.44f / 24f
        canvas.save()
        canvas.translate(s / 2f - 12f * gs, s / 2f - 12f * gs)
        canvas.scale(gs, gs)
        CcGlyph.draw(canvas, id, gp, path, rf, fg, p.color, ringer)
        canvas.restore()
    }
}

/**
 * The Control Center sheet. Code-built; the same view is used in an overlay window and inside the app.
 * Call [release] when it goes away.
 */
internal class ControlCenterPanel(c: Context, private val onClose: () -> Unit) : LinearLayout(c) {
    private val dark = Prefs.isDark(c)
    private val main = Handler(Looper.getMainLooper())
    private var controller: MediaController? = null
    private var mTitle: TextView? = null
    private var mArtist: TextView? = null
    private var mArt: ImageView? = null
    private var mPlay: GlyphButton? = null
    private var mSeek: SeekBar? = null
    private var seeking = false
    private var torchTile: CcTile? = null
    private val pills = ArrayList<VolumePill>()

    private val mediaCb = object : MediaController.Callback() {
        override fun onMetadataChanged(metadata: MediaMetadata?) { bindMedia() }
        override fun onPlaybackStateChanged(state: PlaybackState?) { bindMedia() }
        override fun onSessionDestroyed() { bindMedia() }
    }

    private val seekTick = object : Runnable {
        override fun run() {
            updateSeek()
            if (isAttachedToWindow) main.postDelayed(this, 1000L)
        }
    }

    private fun dp(v: Int): Int = UiKit.dp(context, v)

    init {
        orientation = VERTICAL
        setPadding(dp(16), dp(16), dp(16), dp(16))
        background = Glass.drawable(c, 26f, true)
        val mods = CcModules.load().filter { it.second }.map { it.first }
        if ("media" in mods) addView(mediaCard(), LayoutParams(-1, -2).apply { bottomMargin = dp(12) })
        if ("volume" in mods) addView(volumeRow(), LayoutParams(-1, -2).apply { bottomMargin = dp(12) })
        val tiles = mods.filter { it != "media" && it != "volume" && tileAvailable(it) }
        var row: LinearLayout? = null
        for ((i, id) in tiles.withIndex()) {
            if (i % 4 == 0) {
                row = LinearLayout(c)
                row.orientation = HORIZONTAL
                addView(row, LayoutParams(-1, -2).apply { bottomMargin = dp(10) })
            }
            row?.addView(tile(id), LayoutParams(0, -2, 1f))
        }
        val rem = tiles.size % 4
        if (rem != 0) for (k in rem until 4) row?.addView(View(c), LayoutParams(0, 1, 1f))
    }

    private fun tileAvailable(id: String): Boolean = when (id) {
        "torch" -> try { context.packageManager.hasSystemFeature(PackageManager.FEATURE_CAMERA_FLASH) } catch (e: Throwable) { false }
        else -> true
    }

    private fun caption(text: String): TextView {
        val t = TextView(context)
        t.text = text
        t.textSize = 11f
        t.gravity = Gravity.CENTER
        t.maxLines = 1
        t.ellipsize = TextUtils.TruncateAt.END
        t.setTextColor(UiKit.secondary(dark))
        return t
    }

    private fun start(i: Intent) {
        UiKit.safeStart(context, i)
        onClose()
    }

    private fun tile(id: String): View {
        val col = LinearLayout(context)
        col.orientation = VERTICAL
        col.gravity = Gravity.CENTER_HORIZONTAL
        val t = CcTile(context, id, dp(56))
        when (id) {
            "banner" -> t.on = Prefs.bannerEnabled
            "island" -> t.on = Prefs.islandEnabled
            "torch" -> {
                try { IslandTools.watchTorch(context) } catch (e: Throwable) { }
                t.on = IslandTools.torchOn
                torchTile = t
            }
            "ringer" -> {
                val am = context.getSystemService(Context.AUDIO_SERVICE) as? AudioManager
                t.ringer = am?.ringerMode ?: AudioManager.RINGER_MODE_NORMAL
                t.on = t.ringer != AudioManager.RINGER_MODE_NORMAL
            }
        }
        t.setOnClickListener {
            Perf.haptic(t, Perf.H_KEY)
            onTile(id, t)
        }
        col.addView(t, LayoutParams(dp(56), dp(56)))
        col.addView(caption(CcModules.label(id)), LayoutParams(-1, -2).apply { topMargin = dp(4) })
        return col
    }

    private fun onTile(id: String, t: CcTile) {
        val c = context
        when (id) {
            "connect" -> start(
                if (Build.VERSION.SDK_INT >= 29) Intent(Settings.Panel.ACTION_INTERNET_CONNECTIVITY)
                else Intent(Settings.ACTION_WIRELESS_SETTINGS)
            )
            "torch" -> {
                try { IslandTools.toggleTorch(c) } catch (e: Throwable) { }
                main.postDelayed({ t.on = IslandTools.torchOn }, 200L)
            }
            "timer" -> {
                onClose()
                try { Island.openTools(c) } catch (e: Throwable) { }
            }
            "calc" -> start(Intent.makeMainSelectorActivity(Intent.ACTION_MAIN, Intent.CATEGORY_APP_CALCULATOR))
            "camera" -> start(Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA))
            "ringer" -> {
                val am = c.getSystemService(Context.AUDIO_SERVICE) as? AudioManager ?: return
                val nm = c.getSystemService(Context.NOTIFICATION_SERVICE) as? NotificationManager
                val silentOk = try { nm?.isNotificationPolicyAccessGranted == true } catch (e: Throwable) { false }
                val next = when (am.ringerMode) {
                    AudioManager.RINGER_MODE_NORMAL -> AudioManager.RINGER_MODE_VIBRATE
                    AudioManager.RINGER_MODE_VIBRATE -> if (silentOk) AudioManager.RINGER_MODE_SILENT else AudioManager.RINGER_MODE_NORMAL
                    else -> AudioManager.RINGER_MODE_NORMAL
                }
                try { am.ringerMode = next } catch (e: Throwable) { }
                t.ringer = am.ringerMode
                t.on = t.ringer != AudioManager.RINGER_MODE_NORMAL
            }
            "bright", "rotate" -> start(Intent(Settings.ACTION_DISPLAY_SETTINGS))
            "saver" -> start(Intent(Settings.ACTION_BATTERY_SAVER_SETTINGS))
            "banner" -> {
                Prefs.bannerEnabled = !Prefs.bannerEnabled
                if (!Prefs.bannerEnabled) BannerController.dismissAll()
                t.on = Prefs.bannerEnabled
            }
            "island" -> {
                Prefs.islandEnabled = !Prefs.islandEnabled
                if (!Prefs.islandEnabled) Island.dismissAll(c)
                t.on = Prefs.islandEnabled
            }
            "lock" -> start(Intent(c, LockScreenActivity::class.java))
        }
    }

    // ---------- volume ----------

    private fun volumeRow(): View {
        val row = LinearLayout(context)
        row.orientation = HORIZONTAL
        val am = context.getSystemService(Context.AUDIO_SERVICE) as? AudioManager
        val streams = intArrayOf(AudioManager.STREAM_MUSIC, AudioManager.STREAM_RING, AudioManager.STREAM_ALARM, AudioManager.STREAM_NOTIFICATION)
        val names = listOf("Nhạc", "Chuông", "Báo thức", "Thông báo")
        for ((i, s) in streams.withIndex()) {
            val col = LinearLayout(context)
            col.orientation = VERTICAL
            col.gravity = Gravity.CENTER_HORIZONTAL
            val pill = VolumePill(context)
            val max = try { am?.getStreamMaxVolume(s) ?: 0 } catch (e: Throwable) { 0 }
            val cur = try { am?.getStreamVolume(s) ?: 0 } catch (e: Throwable) { 0 }
            pill.set(s, cur, max)
            pill.onLevel = { idx ->
                try { am?.setStreamVolume(s, idx, 0) } catch (e: SecurityException) { } catch (e: Throwable) { }
            }
            pills.add(pill)
            col.addView(pill, LayoutParams(dp(48), dp(132)))
            col.addView(caption(names[i]), LayoutParams(-1, -2).apply { topMargin = dp(6) })
            row.addView(col, LayoutParams(0, -2, 1f))
        }
        return row
    }

    // ---------- media ----------

    private fun findController(): MediaController? {
        try {
            val msm = context.getSystemService(Context.MEDIA_SESSION_SERVICE) as? MediaSessionManager
            val list = msm?.getActiveSessions(ComponentName(context, N27ListenerService::class.java))
            if (!list.isNullOrEmpty()) {
                return list.firstOrNull { it.playbackState?.state == PlaybackState.STATE_PLAYING } ?: list[0]
            }
        } catch (e: Throwable) {
        }
        return null
    }

    private fun mediaCard(): View {
        val card = LinearLayout(context)
        card.orientation = VERTICAL
        card.setPadding(dp(12), dp(12), dp(12), dp(12))
        card.background = UiKit.flat(context, if (dark) Color.argb(36, 255, 255, 255) else Color.argb(18, 0, 0, 0), 20f)
        val top = LinearLayout(context)
        top.gravity = Gravity.CENTER_VERTICAL
        val art = UiKit.roundedIcon(context, 48)
        top.addView(art, LayoutParams(dp(48), dp(48)))
        val tc = LinearLayout(context)
        tc.orientation = VERTICAL
        val title = TextView(context)
        title.textSize = 15f
        title.typeface = Typeface.DEFAULT_BOLD
        title.maxLines = 1
        title.ellipsize = TextUtils.TruncateAt.END
        title.setTextColor(UiKit.primary(dark))
        val artist = TextView(context)
        artist.textSize = 13f
        artist.maxLines = 1
        artist.ellipsize = TextUtils.TruncateAt.END
        artist.setTextColor(UiKit.secondary(dark))
        tc.addView(title)
        tc.addView(artist)
        top.addView(tc, LayoutParams(0, -2, 1f).apply { leftMargin = dp(12) })
        card.addView(top, LayoutParams(-1, -2))
        val seek = SeekBar(context)
        seek.max = 1000
        try {
            seek.progressTintList = android.content.res.ColorStateList.valueOf(UiKit.primary(dark))
            seek.thumbTintList = android.content.res.ColorStateList.valueOf(UiKit.primary(dark))
        } catch (e: Throwable) {
        }
        seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, progress: Int, fromUser: Boolean) {}
            override fun onStartTrackingTouch(sb: SeekBar?) { seeking = true }
            override fun onStopTrackingTouch(sb: SeekBar?) {
                seeking = false
                val mc = controller ?: return
                val dur = mc.metadata?.getLong(MediaMetadata.METADATA_KEY_DURATION) ?: 0L
                if (dur > 0L && sb != null) {
                    try { mc.transportControls.seekTo(dur * sb.progress / 1000L) } catch (e: Throwable) { }
                }
            }
        })
        card.addView(seek, LayoutParams(-1, -2).apply { topMargin = dp(8) })
        val btns = LinearLayout(context)
        btns.gravity = Gravity.CENTER
        val size = dp(44)
        val prev = GlyphButton(context, size, IslandGlyphs.PREV)
        val play = GlyphButton(context, size, IslandGlyphs.PLAY)
        val next = GlyphButton(context, size, IslandGlyphs.NEXT)
        for (b in listOf(prev, play, next)) {
            b.bg = Color.TRANSPARENT
            b.fg = UiKit.primary(dark)
        }
        prev.setOnClickListener { try { controller?.transportControls?.skipToPrevious() } catch (e: Throwable) { } }
        next.setOnClickListener { try { controller?.transportControls?.skipToNext() } catch (e: Throwable) { } }
        play.setOnClickListener {
            val mc = controller ?: return@setOnClickListener
            try {
                if (mc.playbackState?.state == PlaybackState.STATE_PLAYING) mc.transportControls.pause()
                else mc.transportControls.play()
            } catch (e: Throwable) {
            }
        }
        btns.addView(prev, LayoutParams(size, size))
        btns.addView(play, LayoutParams(size, size).apply { leftMargin = dp(24); rightMargin = dp(24) })
        btns.addView(next, LayoutParams(size, size))
        card.addView(btns, LayoutParams(-1, -2).apply { topMargin = dp(4) })
        mTitle = title
        mArtist = artist
        mArt = art
        mPlay = play
        mSeek = seek
        val mc = findController()
        controller = mc
        try { mc?.registerCallback(mediaCb, main) } catch (e: Throwable) { }
        bindMedia()
        return card
    }

    private fun bindMedia() {
        val mc = controller
        val md = try { mc?.metadata } catch (e: Throwable) { null }
        val t = md?.getString(MediaMetadata.METADATA_KEY_TITLE)
        mTitle?.text = if (t.isNullOrBlank()) "Không có nội dung đang phát" else t
        mArtist?.text = md?.getString(MediaMetadata.METADATA_KEY_ARTIST) ?: ""
        val bmp: Bitmap? = try {
            md?.getBitmap(MediaMetadata.METADATA_KEY_ALBUM_ART) ?: md?.getBitmap(MediaMetadata.METADATA_KEY_ART)
        } catch (e: Throwable) {
            null
        }
        val art = mArt
        if (art != null) {
            if (bmp != null) art.setImageBitmap(bmp)
            else if (mc != null) UiKit.bindIcon(art, mc.packageName)
            else art.setImageDrawable(null)
            if (bmp == null && mc == null) art.background = UiKit.flat(context, Color.argb(60, 128, 128, 128), 10f)
        }
        val playing = try { mc?.playbackState?.state == PlaybackState.STATE_PLAYING } catch (e: Throwable) { false }
        mPlay?.glyph = if (playing) IslandGlyphs.PAUSE else IslandGlyphs.PLAY
        mPlay?.invalidate()
        updateSeek()
    }

    private fun updateSeek() {
        val sb = mSeek ?: return
        if (seeking) return
        val mc = controller
        val dur = try { mc?.metadata?.getLong(MediaMetadata.METADATA_KEY_DURATION) ?: 0L } catch (e: Throwable) { 0L }
        val st = try { mc?.playbackState } catch (e: Throwable) { null }
        if (dur <= 0L || st == null) {
            sb.visibility = View.INVISIBLE
            return
        }
        sb.visibility = View.VISIBLE
        var pos = st.position
        if (st.state == PlaybackState.STATE_PLAYING) {
            pos += ((android.os.SystemClock.elapsedRealtime() - st.lastPositionUpdateTime) * st.playbackSpeed).toLong()
        }
        sb.progress = ((pos.coerceIn(0L, dur) * 1000L) / dur).toInt()
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        if (mSeek != null) {
            main.removeCallbacks(seekTick)
            main.postDelayed(seekTick, 1000L)
        }
    }

    override fun onDetachedFromWindow() {
        super.onDetachedFromWindow()
        release()
    }

    fun release() {
        main.removeCallbacks(seekTick)
        main.removeCallbacksAndMessages(null)
        try { controller?.unregisterCallback(mediaCb) } catch (e: Throwable) { }
        controller = null
        if (torchTile != null) {
            try { IslandTools.unwatchTorch(context) } catch (e: Throwable) { }
            torchTile = null
        }
    }
}

/** Floating Notification Center content: latest 20 items in StackGroups with "Xoá tất cả". */
internal class FloatingCenter(c: Context, private val onClose: () -> Unit) : LinearLayout(c) {
    private val dark = Prefs.isDark(c)
    private val expanded = HashSet<String>()
    private var justExpanded: String? = null
    private val body = LinearLayout(c)
    private val listener: () -> Unit = { rebuild() }

    private fun dp(v: Int): Int = UiKit.dp(context, v)

    init {
        orientation = VERTICAL
        setPadding(dp(12), dp(12), dp(12), dp(12))
        val head = LinearLayout(c)
        head.gravity = Gravity.CENTER_VERTICAL
        val title = TextView(c)
        title.text = "Thông báo"
        title.textSize = 22f
        title.typeface = Typeface.DEFAULT_BOLD
        title.setTextColor(UiKit.primary(dark))
        head.addView(title, LayoutParams(0, -2, 1f))
        head.addView(StackViews.glassButton(c, "Xoá tất cả", dark) {
            for (i in NotifStore.all()) if (!i.pinned) Cards.clearItem(i)
        }, LayoutParams(-2, -2))
        addView(head, LayoutParams(-1, -2).apply { bottomMargin = dp(10) })
        body.orientation = VERTICAL
        addView(body, LayoutParams(-1, -2))
        rebuild()
    }

    private fun row(item: NotifItem): View {
        val card = StackViews.card(context, item, dark, true, null)
        return N27SwipeRow(context, card, {
            NotifStore.markRead(item.key)
            NotifStore.open(context, item)
            onClose()
        }, { Cards.clearItem(item) })
    }

    private fun rebuild() {
        body.removeAllViews()
        val all = NotifStore.all().take(20)
        if (all.isEmpty()) {
            val t = TextView(context)
            t.text = "Không có thông báo"
            t.textSize = 15f
            t.gravity = Gravity.CENTER
            t.setTextColor(UiKit.secondary(dark))
            t.setPadding(0, dp(24), 0, dp(24))
            body.addView(t, LayoutParams(-1, -2))
            return
        }
        for (i in all) if (i.pinned) body.addView(row(i), LayoutParams(-1, -2).apply { bottomMargin = dp(8) })
        for (g in StackViews.group(all)) {
            val key = StackViews.groupKey(g[0])
            body.addView(StackGroup(
                context, g, dark, expanded.contains(key),
                { i -> StackViews.card(context, i, dark, true, null) },
                { i -> row(i) },
                { open ->
                    if (open) { expanded.add(key); justExpanded = key } else expanded.remove(key)
                    rebuild()
                },
                {
                    for (i in g) Cards.clearItem(i)
                    expanded.remove(key)
                },
                justExpanded == key
            ), LayoutParams(-1, -2).apply { bottomMargin = dp(8) })
        }
        justExpanded = null
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        NotifStore.addListener(listener)
    }

    override fun onDetachedFromWindow() {
        NotifStore.removeListener(listener)
        super.onDetachedFromWindow()
    }
}

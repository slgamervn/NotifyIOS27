package app.notifyios27

import android.app.Activity
import android.content.Intent
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.Toast

class DataPage : SettingsPage {
    override val title: String = "Lịch sử và dữ liệu"
    private var box: LinearLayout? = null
    private val dayValues = intArrayOf(7, 30, 90, 0)

    override fun build(a: Activity, push: (SettingsPage) -> Unit): View {
        val b = LinearLayout(a)
        b.orientation = LinearLayout.VERTICAL
        box = b
        fill(a, b)
        return b
    }

    private fun toast(a: Activity, m: String) {
        try { Toast.makeText(a, m, Toast.LENGTH_SHORT).show() } catch (e: Exception) { }
    }

    private fun export(a: Activity) {
        try {
            val send = Intent(Intent.ACTION_SEND)
            send.type = "text/plain"
            send.putExtra(Intent.EXTRA_TEXT, History.exportText(a))
            a.startActivity(Intent.createChooser(send, "Xuất lịch sử"))
        } catch (e: Exception) {
            toast(a, "Không thể xuất lịch sử")
        }
    }

    private fun backup(a: Activity) {
        val i = Intent(Intent.ACTION_CREATE_DOCUMENT)
        i.addCategory(Intent.CATEGORY_OPENABLE)
        i.type = "application/json"
        i.putExtra(Intent.EXTRA_TITLE, "n27-backup.json")
        (a as? SettingsActivity)?.startForResult(i) { data ->
            val uri = data?.data
            if (uri != null) {
                try {
                    val bytes = Backup.exportJson(a).toByteArray(Charsets.UTF_8)
                    val os = a.contentResolver.openOutputStream(uri, "wt")
                    if (os == null) {
                        toast(a, "Không thể ghi tệp sao lưu")
                    } else {
                        os.use { it.write(bytes) }
                        toast(a, "Đã sao lưu cài đặt")
                    }
                } catch (e: Exception) {
                    toast(a, "Không thể ghi tệp sao lưu")
                }
            }
        }
    }

    private fun restore(a: Activity) {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT)
        i.addCategory(Intent.CATEGORY_OPENABLE)
        i.type = "*/*"
        (a as? SettingsActivity)?.startForResult(i) { data ->
            val uri = data?.data
            if (uri != null) {
                try {
                    val text = a.contentResolver.openInputStream(uri)?.use { String(it.readBytes(), Charsets.UTF_8) }
                    val ok = text != null && Backup.importJson(a, text)
                    if (ok) {
                        toast(a, "Đã khôi phục cài đặt")
                        a.recreate()
                    } else {
                        toast(a, "Tệp sao lưu không hợp lệ")
                    }
                } catch (e: Exception) {
                    toast(a, "Tệp sao lưu không hợp lệ")
                }
            }
        }
    }

    private fun fill(a: Activity, b: LinearLayout) {
        b.removeAllViews()
        val wrap = ViewGroup.LayoutParams.WRAP_CONTENT
        val match = ViewGroup.LayoutParams.MATCH_PARENT

        val s1 = SettingsKit.section(a, "Lưu lịch sử")
        val cur = dayValues.indexOf(Prefs.historyDays).let { if (it < 0) 1 else it }
        s1.addView(SettingsKit.segmented(a, listOf("7 ngày", "30 ngày", "90 ngày", "Mãi mãi"), cur) {
            Prefs.historyDays = dayValues[it]
        })
        val count = try { History.count() } catch (e: Exception) { 0 }
        s1.addView(SettingsKit.textRow(a, "Đã lưu", "$count thông báo"))
        s1.addView(SettingsKit.buttonRow(a, "Xóa lịch sử", null) {
            SettingsKit.confirm(a, "Xóa toàn bộ lịch sử thông báo?") {
                try { History.clear() } catch (e: Exception) { }
                toast(a, "Đã xóa lịch sử")
                fill(a, b)
            }
        })
        s1.addView(SettingsKit.buttonRow(a, "Xuất lịch sử", "Chia sẻ dưới dạng văn bản") { export(a) })
        b.addView(s1, LinearLayout.LayoutParams(match, wrap))
        b.addView(SettingsKit.spacer(a, 16))

        val s2 = SettingsKit.section(a, "Sao lưu cài đặt")
        s2.addView(SettingsKit.buttonRow(a, "Sao lưu cài đặt", "Lưu ra tệp n27-backup.json") { backup(a) })
        s2.addView(SettingsKit.buttonRow(a, "Khôi phục cài đặt", "Đọc từ tệp sao lưu") { restore(a) })
        b.addView(s2, LinearLayout.LayoutParams(match, wrap))
    }
}

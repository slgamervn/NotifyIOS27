package app.notifyios27

import android.app.NotificationManager
import android.content.Context
import android.graphics.Canvas
import android.graphics.ColorFilter
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.Rect
import android.graphics.drawable.Drawable
import android.media.AudioManager
import android.service.notification.NotificationListenerService

object Dnd {

    fun active(c: Context): Boolean {
        return try {
            val nm = c.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            val f = nm.currentInterruptionFilter
            f != NotificationManager.INTERRUPTION_FILTER_ALL && f != NotificationManager.INTERRUPTION_FILTER_UNKNOWN
        } catch (e: Throwable) {
            false
        }
    }

    fun blocks(ranking: NotificationListenerService.Ranking): Boolean {
        return try {
            !ranking.matchesInterruptionFilter()
        } catch (e: Throwable) {
            false
        }
    }

    private fun silenced(blocked: Boolean): Boolean = blocked && Prefs.dndMode != 2

    private fun ringer(c: Context): Int {
        return try {
            (c.getSystemService(Context.AUDIO_SERVICE) as AudioManager).ringerMode
        } catch (e: Throwable) {
            AudioManager.RINGER_MODE_NORMAL
        }
    }

    fun effectiveSound(c: Context, wantSound: Boolean, blocked: Boolean): Boolean {
        if (!wantSound) return false
        if (silenced(blocked)) return false
        if (Prefs.respectRinger && ringer(c) != AudioManager.RINGER_MODE_NORMAL) return false
        try {
            val am = c.getSystemService(Context.AUDIO_SERVICE) as AudioManager
            if (am.getStreamVolume(AudioManager.STREAM_NOTIFICATION) == 0) return false
        } catch (e: Throwable) {
        }
        return true
    }

    fun effectiveHaptic(c: Context, wantHaptic: Boolean, blocked: Boolean): Boolean {
        if (!wantHaptic) return false
        if (silenced(blocked)) return false
        if (Prefs.respectRinger && ringer(c) == AudioManager.RINGER_MODE_SILENT) return false
        return true
    }
}

/** Small crescent moon drawn in code. */
class MoonDrawable(private var color: Int) : Drawable() {
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val path = Path()

    init {
        paint.color = color
    }

    fun setColor(c: Int) {
        color = c
        paint.color = c
        invalidateSelf()
    }

    override fun onBoundsChange(b: Rect) {
        super.onBoundsChange(b)
        val r = Math.min(b.width(), b.height()) / 2f
        val cx = b.exactCenterX()
        val cy = b.exactCenterY()
        path.reset()
        path.addCircle(cx, cy, r * 0.92f, Path.Direction.CW)
        val cut = Path()
        cut.addCircle(cx + r * 0.5f, cy - r * 0.35f, r * 0.78f, Path.Direction.CW)
        path.op(cut, Path.Op.DIFFERENCE)
    }

    override fun draw(canvas: Canvas) {
        canvas.drawPath(path, paint)
    }

    override fun setAlpha(alpha: Int) {
        paint.alpha = alpha
        invalidateSelf()
    }

    override fun setColorFilter(colorFilter: ColorFilter?) {
        paint.colorFilter = colorFilter
        invalidateSelf()
    }

    @Suppress("OVERRIDE_DEPRECATION")
    override fun getOpacity(): Int = PixelFormat.TRANSLUCENT
}

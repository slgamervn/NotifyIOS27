package app.notifyios27

import android.app.Activity
import android.graphics.Color
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.TextView

/** Minimal wrapping layout for chips. */
internal class N27Flow(a: Activity) : ViewGroup(a) {
    private val gap = UiKit.dp(a, 8)

    override fun onMeasure(widthSpec: Int, heightSpec: Int) {
        val maxW = MeasureSpec.getSize(widthSpec) - paddingLeft - paddingRight
        var x = 0
        var y = 0
        var rowH = 0
        for (i in 0 until childCount) {
            val c = getChildAt(i)
            if (c.visibility == View.GONE) continue
            c.measure(MeasureSpec.makeMeasureSpec(maxW, MeasureSpec.AT_MOST), MeasureSpec.makeMeasureSpec(0, MeasureSpec.UNSPECIFIED))
            if (x > 0 && x + c.measuredWidth > maxW) {
                x = 0
                y += rowH + gap
                rowH = 0
            }
            x += c.measuredWidth + gap
            if (c.measuredHeight > rowH) rowH = c.measuredHeight
        }
        val h = y + rowH + paddingTop + paddingBottom
        setMeasuredDimension(MeasureSpec.getSize(widthSpec), h)
    }

    override fun onLayout(changed: Boolean, l: Int, t: Int, r: Int, b: Int) {
        val maxW = r - l - paddingLeft - paddingRight
        var x = 0
        var y = 0
        var rowH = 0
        for (i in 0 until childCount) {
            val c = getChildAt(i)
            if (c.visibility == View.GONE) continue
            if (x > 0 && x + c.measuredWidth > maxW) {
                x = 0
                y += rowH + gap
                rowH = 0
            }
            c.layout(paddingLeft + x, paddingTop + y, paddingLeft + x + c.measuredWidth, paddingTop + y + c.measuredHeight)
            x += c.measuredWidth + gap
            if (c.measuredHeight > rowH) rowH = c.measuredHeight
        }
    }
}

/** Chips with a remove cross plus an "Thêm" chip. onChange gets the new list after every edit. */
internal fun n27WordChips(a: Activity, initial: List<String>, title: String, onChange: (List<String>) -> Unit): View {
    val dark = Prefs.isDark(a)
    val words = ArrayList<String>(initial)
    val flow = N27Flow(a)
    flow.setPadding(UiKit.dp(a, 14), UiKit.dp(a, 8), UiKit.dp(a, 14), UiKit.dp(a, 12))

    fun chip(text: String, filled: Boolean, click: () -> Unit): TextView {
        val t = TextView(a)
        t.text = text
        t.textSize = 14f
        t.setPadding(UiKit.dp(a, 12), UiKit.dp(a, 7), UiKit.dp(a, 12), UiKit.dp(a, 7))
        t.setTextColor(if (filled) Color.WHITE else UiKit.primary(dark))
        t.background = UiKit.rounded(
            a,
            if (filled) UiKit.accent(a) else if (dark) Color.argb(50, 255, 255, 255) else Color.argb(40, 0, 0, 0),
            16f
        )
        t.setOnClickListener { click() }
        return t
    }

    fun render() {
        flow.removeAllViews()
        for (w in words.toList()) {
            flow.addView(chip("$w   x", false) {
                words.remove(w)
                onChange(words.toList())
                render()
            })
        }
        flow.addView(chip("+ Thêm", true) {
            SettingsKit.inputDialog(a, title, "Nhập từ khóa", "") { s ->
                val v = s.trim()
                if (v.isNotEmpty() && words.none { it.equals(v, ignoreCase = true) }) {
                    words.add(v)
                    onChange(words.toList())
                    render()
                }
            }
        })
    }
    render()
    return flow
}

class FiltersPage : SettingsPage {
    override val title: String = "Bộ lọc"

    override fun build(a: Activity, push: (SettingsPage) -> Unit): View {
        val root = LinearLayout(a)
        root.orientation = LinearLayout.VERTICAL

        val block = SettingsKit.section(a, "Từ khóa chặn")
        block.addView(n27WordChips(a, Rules.blockWords(a), "Thêm từ khóa chặn") { Rules.setBlockWords(a, it) })
        root.addView(block, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        root.addView(n27Note(a, "Thông báo có chứa một trong các từ khóa này trong tiêu đề hoặc nội dung sẽ bị bỏ qua hoàn toàn."))

        root.addView(SettingsKit.spacer(a, 8))

        val hi = SettingsKit.section(a, "Từ khóa nổi bật")
        hi.addView(n27WordChips(a, Rules.highlightWords(a), "Thêm từ khóa nổi bật") { Rules.setHighlightWords(a, it) })
        root.addView(hi, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        root.addView(n27Note(a, "Thông báo chứa từ khóa này được xem là Time Sensitive: vẫn hiện banner dù đang bật Focus, tắt tiếng hoặc gộp tóm tắt."))
        return root
    }
}

package app.notifyios27

import android.content.Context
import android.content.SharedPreferences
import org.json.JSONArray
import org.json.JSONObject
import java.util.Calendar
import java.util.Locale
import java.util.concurrent.CopyOnWriteArrayList

data class FocusProfile(
    val id: String,
    val name: String,
    val emoji: String,
    val allowedPkgs: Set<String>,
    val allowedWords: List<String>,
    val days: Set<Int>,
    val startMin: Int,
    val endMin: Int,
    val scheduled: Boolean
)

object Focus {
    private val lock = Any()
    private val listeners = CopyOnWriteArrayList<() -> Unit>()

    private fun sp(c: Context): SharedPreferences =
        c.applicationContext.getSharedPreferences("n27_focus", Context.MODE_PRIVATE)

    private fun defaults(): List<FocusProfile> {
        val all = setOf(1, 2, 3, 4, 5, 6, 7)
        return listOf(
            FocusProfile("work", "Làm việc", "\uD83D\uDCBC", emptySet(), emptyList(), all, 540, 1020, false),
            FocusProfile("sleep", "Ngủ", "\uD83C\uDF19", emptySet(), emptyList(), all, 1380, 420, false),
            FocusProfile("study", "Học tập", "\uD83D\uDCDA", emptySet(), emptyList(), all, 1140, 1320, false)
        )
    }

    private fun toJson(p: FocusProfile): JSONObject {
        val o = JSONObject()
        o.put("id", p.id)
        o.put("name", p.name)
        o.put("emoji", p.emoji)
        val pk = JSONArray()
        for (s in p.allowedPkgs) pk.put(s)
        o.put("pkgs", pk)
        val w = JSONArray()
        for (s in p.allowedWords) w.put(s)
        o.put("words", w)
        val d = JSONArray()
        for (s in p.days) d.put(s)
        o.put("days", d)
        o.put("startMin", p.startMin)
        o.put("endMin", p.endMin)
        o.put("scheduled", p.scheduled)
        return o
    }

    private fun fromJson(o: JSONObject): FocusProfile {
        val pkgs = HashSet<String>()
        val pa = o.optJSONArray("pkgs")
        if (pa != null) for (i in 0 until pa.length()) pkgs.add(pa.getString(i))
        val words = ArrayList<String>()
        val wa = o.optJSONArray("words")
        if (wa != null) for (i in 0 until wa.length()) words.add(wa.getString(i))
        val days = HashSet<Int>()
        val da = o.optJSONArray("days")
        if (da != null) for (i in 0 until da.length()) days.add(da.getInt(i))
        return FocusProfile(
            id = o.getString("id"),
            name = o.optString("name"),
            emoji = o.optString("emoji"),
            allowedPkgs = pkgs,
            allowedWords = words,
            days = days,
            startMin = o.optInt("startMin", 0),
            endMin = o.optInt("endMin", 0),
            scheduled = o.optBoolean("scheduled", false)
        )
    }

    private fun write(c: Context, list: List<FocusProfile>) {
        val arr = JSONArray()
        for (p in list) arr.put(toJson(p))
        sp(c).edit().putString("profiles", arr.toString()).apply()
    }

    private fun read(c: Context): MutableList<FocusProfile> {
        val s = sp(c).getString("profiles", null)
        if (s != null) {
            try {
                val arr = JSONArray(s)
                val out = ArrayList<FocusProfile>()
                for (i in 0 until arr.length()) out.add(fromJson(arr.getJSONObject(i)))
                return out
            } catch (e: Exception) {
            }
        }
        val d = ArrayList(defaults())
        write(c, d)
        return d
    }

    private fun fire() {
        for (l in listeners) {
            try { l() } catch (e: Exception) { }
        }
    }

    fun profiles(c: Context): List<FocusProfile> = synchronized(lock) { read(c) }

    fun save(c: Context, p: FocusProfile) {
        synchronized(lock) {
            val list = read(c)
            val idx = list.indexOfFirst { it.id == p.id }
            if (idx >= 0) list[idx] = p else list.add(p)
            write(c, list)
        }
        fire()
    }

    fun delete(c: Context, id: String) {
        synchronized(lock) {
            val list = read(c)
            list.removeAll { it.id == id }
            write(c, list)
            if (sp(c).getString("manual", null) == id) sp(c).edit().remove("manual").apply()
        }
        fire()
    }

    fun manualId(c: Context): String? = synchronized(lock) { sp(c).getString("manual", null) }

    fun setManual(c: Context, id: String?) {
        synchronized(lock) {
            val e = sp(c).edit()
            if (id == null) e.remove("manual") else e.putString("manual", id)
            e.apply()
        }
        fire()
    }

    private fun inWindow(p: FocusProfile, dow: Int, min: Int): Boolean {
        if (p.endMin > p.startMin) {
            return p.days.contains(dow) && min >= p.startMin && min < p.endMin
        }
        // crosses midnight: the start day owns the whole window
        if (p.days.contains(dow) && min >= p.startMin) return true
        val prev = if (dow == 1) 7 else dow - 1
        return p.days.contains(prev) && min < p.endMin
    }

    fun active(c: Context): FocusProfile? {
        val list = profiles(c)
        val manual = manualId(c)
        if (manual != null) {
            val m = list.firstOrNull { it.id == manual }
            if (m != null) return m
        }
        val cal = Calendar.getInstance()
        val dow = cal.get(Calendar.DAY_OF_WEEK)
        val min = cal.get(Calendar.HOUR_OF_DAY) * 60 + cal.get(Calendar.MINUTE)
        return list.firstOrNull { it.scheduled && inWindow(it, dow, min) }
    }

    fun isAllowed(c: Context, item: NotifItem): Boolean {
        val p = active(c) ?: return true
        if (p.allowedPkgs.contains(item.pkg)) return true
        val cat = item.category
        if (cat == "call" || cat == "alarm") return true
        val hay = (item.title + " " + item.text).lowercase(Locale.ROOT)
        for (w in p.allowedWords) {
            val t = w.trim().lowercase(Locale.ROOT)
            if (t.isNotEmpty() && hay.contains(t)) return true
        }
        return false
    }

    fun addListener(l: () -> Unit) {
        listeners.add(l)
    }

    fun removeListener(l: () -> Unit) {
        listeners.remove(l)
    }
}

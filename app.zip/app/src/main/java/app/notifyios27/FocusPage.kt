package app.notifyios27

@file:Suppress("DEPRECATION")

import android.app.Activity
import android.app.TimePickerDialog
import android.graphics.Color
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.Switch
import android.widget.TextView
import java.util.Calendar

class FocusPage : SettingsPage {
    override val title: String = "Focus"
    private var list: LinearLayout? = null
    private var act: Activity? = null
    private var pushFn: ((SettingsPage) -> Unit)? = null

    override fun build(a: Activity, push: (SettingsPage) -> Unit): View {
        act = a
        pushFn = push
        val dark = Prefs.isDark(a)
        val mp = ViewGroup.LayoutParams.MATCH_PARENT
        val wc = ViewGroup.LayoutParams.WRAP_CONTENT
        val root = LinearLayout(a)
        root.orientation = LinearLayout.VERTICAL
        root.addView(n27Note(a, "Focus chỉ lọc banner của ứng dụng này; không thay đổi chế độ Không làm phiền của hệ thống."))
        val l = SettingsKit.section(a, null)
        list = l
        root.addView(l, LinearLayout.LayoutParams(mp, wc))
        root.addView(SettingsKit.spacer(a, 8))
        val add = SettingsKit.section(a, null)
        add.addView(SettingsKit.buttonRow(a, "Thêm Focus mới", null) {
            val id = java.util.UUID.randomUUID().toString()
            Focus.save(
                a,
                FocusProfile(
                    id, "Focus mới", "", emptySet(), emptyList(),
                    setOf(Calendar.MONDAY, Calendar.TUESDAY, Calendar.WEDNESDAY, Calendar.THURSDAY, Calendar.FRIDAY),
                    540, 1020, false
                )
            )
            push(FocusEditPage(id))
        })
        root.addView(add, LinearLayout.LayoutParams(mp, wc))
        render()
        return root
    }

    override fun onResume() {
        render()
    }

    private fun render() {
        val a = act ?: return
        val l = list ?: return
        val push = pushFn ?: return
        val dark = Prefs.isDark(a)
        val wc = ViewGroup.LayoutParams.WRAP_CONTENT
        l.removeAllViews()
        val manual = Focus.manualId(a)
        for (p in Focus.profiles(a)) {
            val row = LinearLayout(a)
            row.orientation = LinearLayout.HORIZONTAL
            row.gravity = Gravity.CENTER_VERTICAL
            row.setPadding(UiKit.dp(a, 16), UiKit.dp(a, 12), UiKit.dp(a, 16), UiKit.dp(a, 12))
            val em = TextView(a)
            em.text = p.name.trim().take(1).uppercase()
            em.textSize = 16f
            em.typeface = android.graphics.Typeface.DEFAULT_BOLD
            em.gravity = Gravity.CENTER
            em.setTextColor(android.graphics.Color.WHITE)
            em.background = UiKit.rounded(a, UiKit.accent(a), 18f)
            row.addView(em, LinearLayout.LayoutParams(UiKit.dp(a, 36), UiKit.dp(a, 36)).apply { rightMargin = UiKit.dp(a, 12) })
            val name = TextView(a)
            name.text = p.name
            name.textSize = 16f
            name.setTextColor(UiKit.primary(dark))
            row.addView(name, LinearLayout.LayoutParams(0, wc, 1f))
            val lbl = TextView(a)
            lbl.text = "Bật ngay"
            lbl.textSize = 12.5f
            lbl.setTextColor(UiKit.secondary(dark))
            row.addView(lbl, LinearLayout.LayoutParams(wc, wc).apply { rightMargin = UiKit.dp(a, 8) })
            val sw = Switch(a)
            sw.isChecked = manual == p.id
            sw.setOnCheckedChangeListener { _, on ->
                if (on) Focus.setManual(a, p.id)
                else if (Focus.manualId(a) == p.id) Focus.setManual(a, null)
                sw.post { render() }
            }
            row.addView(sw, LinearLayout.LayoutParams(wc, wc))
            row.setOnClickListener { push(FocusEditPage(p.id)) }
            l.addView(row, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, wc))
        }
    }
}

internal class FocusEditPage(private val id: String) : SettingsPage {
    private var t = "Focus"
    override val title: String get() = t

    override fun build(a: Activity, push: (SettingsPage) -> Unit): View {
        val root = LinearLayout(a)
        root.orientation = LinearLayout.VERTICAL
        var cur: FocusProfile = Focus.profiles(a).firstOrNull { it.id == id }
            ?: return n27Note(a, "Không tìm thấy Focus này.")
        t = cur.name
        val dark = Prefs.isDark(a)
        val mp = ViewGroup.LayoutParams.MATCH_PARENT
        val wc = ViewGroup.LayoutParams.WRAP_CONTENT

        fun commit(n: FocusProfile) {
            cur = n
            t = n.name
            Focus.save(a, n)
        }

        lateinit var render: () -> Unit

        fun pickTime(initial: Int, done: (Int) -> Unit) {
            try {
                TimePickerDialog(a, { _, h, m -> done(h * 60 + m) }, initial / 60, initial % 60, true).show()
            } catch (e: Exception) {
            }
        }

        render = {
            root.removeAllViews()
            val p = cur

            val s1 = SettingsKit.section(a, null)
            s1.addView(SettingsKit.buttonRow(a, "Tên", p.name) {
                SettingsKit.inputDialog(a, "Tên Focus", "Tên", p.name) { s ->
                    val v = s.trim()
                    if (v.isNotEmpty()) {
                        commit(cur.copy(name = v))
                        render()
                    }
                }
            })
            root.addView(s1, LinearLayout.LayoutParams(mp, wc))
            root.addView(SettingsKit.spacer(a, 8))

            val s2 = SettingsKit.section(a, "Cho phép")
            s2.addView(SettingsKit.buttonRow(a, "Ứng dụng được phép", "${p.allowedPkgs.size} ứng dụng") {
                PickerDialogs.pickApps(a, cur.allowedPkgs) { set ->
                    commit(cur.copy(allowedPkgs = set))
                    render()
                }
            })
            s2.addView(n27WordChips(a, p.allowedWords, "Thêm từ khóa được phép") { words ->
                commit(cur.copy(allowedWords = words))
            })
            root.addView(s2, LinearLayout.LayoutParams(mp, wc))
            root.addView(n27Note(a, "Khi Focus bật, chỉ thông báo từ ứng dụng được phép, chứa từ khóa được phép, cuộc gọi, báo thức hoặc Time Sensitive mới hiện banner."))

            val s3 = SettingsKit.section(a, "Lịch")
            s3.addView(SettingsKit.switchRow(a, "Hẹn giờ tự động", null, p.scheduled) {
                commit(cur.copy(scheduled = it))
                root.post { render() }
            })
            if (p.scheduled) {
                val labels = listOf("Thứ 2", "Thứ 3", "Thứ 4", "Thứ 5", "Thứ 6", "Thứ 7", "CN")
                val dows = listOf(
                    Calendar.MONDAY, Calendar.TUESDAY, Calendar.WEDNESDAY, Calendar.THURSDAY,
                    Calendar.FRIDAY, Calendar.SATURDAY, Calendar.SUNDAY
                )
                val dayRow = LinearLayout(a)
                dayRow.orientation = LinearLayout.HORIZONTAL
                dayRow.setPadding(UiKit.dp(a, 8), UiKit.dp(a, 8), UiKit.dp(a, 8), UiKit.dp(a, 8))
                for (i in labels.indices) {
                    val on = p.days.contains(dows[i])
                    val tv = TextView(a)
                    tv.text = labels[i]
                    tv.textSize = 11f
                    tv.setSingleLine(true)
                    tv.gravity = Gravity.CENTER
                    tv.setPadding(0, UiKit.dp(a, 8), 0, UiKit.dp(a, 8))
                    tv.setTextColor(if (on) Color.WHITE else UiKit.primary(dark))
                    tv.background = UiKit.rounded(
                        a,
                        if (on) UiKit.accent(a) else if (dark) Color.argb(50, 255, 255, 255) else Color.argb(40, 0, 0, 0),
                        10f
                    )
                    tv.setOnClickListener {
                        val d = HashSet<Int>(cur.days)
                        if (!d.remove(dows[i])) d.add(dows[i])
                        commit(cur.copy(days = d))
                        render()
                    }
                    dayRow.addView(tv, LinearLayout.LayoutParams(0, wc, 1f).apply {
                        leftMargin = UiKit.dp(a, 2)
                        rightMargin = UiKit.dp(a, 2)
                    })
                }
                s3.addView(dayRow, LinearLayout.LayoutParams(mp, wc))
                s3.addView(SettingsKit.buttonRow(a, "Bắt đầu", n27Hm(p.startMin)) {
                    pickTime(cur.startMin) { v ->
                        commit(cur.copy(startMin = v))
                        render()
                    }
                })
                s3.addView(SettingsKit.buttonRow(a, "Kết thúc", n27Hm(p.endMin)) {
                    pickTime(cur.endMin) { v ->
                        commit(cur.copy(endMin = v))
                        render()
                    }
                })
            }
            root.addView(s3, LinearLayout.LayoutParams(mp, wc))
            if (p.scheduled) root.addView(n27Note(a, "Nếu giờ kết thúc không muộn hơn giờ bắt đầu, Focus kết thúc vào ngày hôm sau."))

            root.addView(SettingsKit.spacer(a, 8))
            val s4 = SettingsKit.section(a, null)
            val del = TextView(a)
            del.text = "Xóa Focus này"
            del.textSize = 16f
            del.gravity = Gravity.CENTER
            del.setTextColor(UiKit.RED)
            del.setPadding(0, UiKit.dp(a, 14), 0, UiKit.dp(a, 14))
            del.setOnClickListener {
                SettingsKit.confirm(a, "Xóa Focus “${cur.name}”?") {
                    Focus.delete(a, id)
                    try {
                        a.onBackPressed()
                    } catch (e: Exception) {
                    }
                }
            }
            s4.addView(del, LinearLayout.LayoutParams(mp, wc))
            root.addView(s4, LinearLayout.LayoutParams(mp, wc))
        }
        render()
        return root
    }
}

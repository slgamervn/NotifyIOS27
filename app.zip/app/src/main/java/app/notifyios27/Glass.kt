package app.notifyios27

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ColorFilter
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.drawable.Drawable
import android.os.Build
import android.view.View
import android.view.WindowManager

/** The one place that draws Liquid Glass. */
object Glass {
    fun deviceBlurCapable(c: Context): Boolean {
        return try {
            if (Build.VERSION.SDK_INT < 31) {
                false
            } else {
                val wm = c.getSystemService(Context.WINDOW_SERVICE) as WindowManager
                wm.isCrossWindowBlurEnabled
            }
        } catch (e: Throwable) {
            false
        }
    }

    fun blurSupported(c: Context): Boolean {
        return try {
            Prefs.glassBlur && deviceBlurCapable(c)
        } catch (e: Throwable) {
            false
        }
    }

    fun drawable(c: Context, radiusDp: Float, overlay: Boolean = false): Drawable =
        GlassDrawable(c, radiusDp, overlay)

    @Suppress("DEPRECATION")
    fun applyBlur(c: Context, lp: WindowManager.LayoutParams, radiusPx: Int = -1) {
        try {
            if (blurSupported(c)) {
                lp.flags = lp.flags or WindowManager.LayoutParams.FLAG_BLUR_BEHIND
                if (Build.VERSION.SDK_INT >= 31) {
                    lp.blurBehindRadius =
                        if (radiusPx < 0) UiKit.dp(c, Prefs.glassBlurRadius) else radiusPx
                }
            } else {
                lp.flags = lp.flags and WindowManager.LayoutParams.FLAG_BLUR_BEHIND.inv()
                if (Build.VERSION.SDK_INT >= 31) lp.blurBehindRadius = 0
            }
        } catch (e: Throwable) {
        }
    }

    fun setBlurRadius(c: Context, view: View, lp: WindowManager.LayoutParams, radiusPx: Int) {
        if (!blurSupported(c)) return
        try {
            if (Build.VERSION.SDK_INT >= 31) {
                lp.blurBehindRadius = radiusPx
                val wm = c.getSystemService(Context.WINDOW_SERVICE) as WindowManager
                wm.updateViewLayout(view, lp)
            }
        } catch (e: Throwable) {
        }
    }

    private class GlassDrawable(c: Context, radiusDp: Float, overlay: Boolean) : Drawable() {
        private val dark: Boolean = try { Prefs.isDark(c) } catch (e: Throwable) { false }
        private val d: Float = c.resources.displayMetrics.density
        private val radius: Float = radiusDp * d
        private val rect = RectF()
        private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
        private val scrim = Paint(Paint.ANTI_ALIAS_FLAG)
        private val rim = Paint(Paint.ANTI_ALIAS_FLAG)
        private val hi = Paint(Paint.ANTI_ALIAS_FLAG)
        private val fillA: Int
        private val scrimA: Int
        private var gAlpha = 255
        private var filter: ColorFilter? = null

        init {
            var a = try { Prefs.glass } catch (e: Throwable) { 0.30f }
            a = a.coerceIn(0.05f, 1f)
            if (overlay && !Glass.blurSupported(c)) a = Math.max(a, 0.82f)
            fillA = (a * 255f).toInt().coerceIn(0, 255)
            scrimA = if (dark) 80 else 95
            fill.color = if (dark) Color.rgb(95, 95, 120) else Color.WHITE
            scrim.color = if (dark) Color.rgb(8, 8, 16) else Color.rgb(250, 250, 255)
            rim.style = Paint.Style.STROKE
            rim.strokeWidth = 1.2f * d
            hi.style = Paint.Style.STROKE
            hi.strokeWidth = 1f * d
            hi.strokeCap = Paint.Cap.ROUND
        }

        override fun onBoundsChange(b: Rect) {
            super.onBoundsChange(b)
            val inset = 0.6f * d
            rect.set(b.left + inset, b.top + inset, b.right - inset, b.bottom - inset)
            if (rect.width() <= 0f || rect.height() <= 0f) return
            val top: Int
            val mid: Int
            val bottom: Int
            if (dark) {
                top = Color.argb(170, 255, 255, 255)
                mid = Color.argb(34, 255, 255, 255)
                bottom = Color.argb(16, 255, 255, 255)
            } else {
                top = Color.argb(255, 255, 255, 255)
                mid = Color.argb(80, 255, 255, 255)
                bottom = Color.argb(46, 120, 120, 140)
            }
            rim.shader = LinearGradient(
                rect.left, rect.top, rect.right, rect.bottom,
                intArrayOf(top, mid, bottom), floatArrayOf(0f, 0.5f, 1f), Shader.TileMode.CLAMP
            )
            val clear = Color.argb(0, 255, 255, 255)
            val peak = Color.argb(if (dark) 110 else 200, 255, 255, 255)
            hi.shader = LinearGradient(
                rect.left, 0f, rect.right, 0f,
                intArrayOf(clear, peak, clear), floatArrayOf(0f, 0.5f, 1f), Shader.TileMode.CLAMP
            )
        }

        override fun draw(canvas: Canvas) {
            if (rect.width() <= 0f || rect.height() <= 0f) return
            val rr = Math.min(radius, Math.min(rect.width(), rect.height()) / 2f)
            scrim.alpha = scrimA * gAlpha / 255
            canvas.drawRoundRect(rect, rr, rr, scrim)
            fill.alpha = fillA * gAlpha / 255
            canvas.drawRoundRect(rect, rr, rr, fill)
            rim.alpha = gAlpha
            canvas.drawRoundRect(rect, rr, rr, rim)
            hi.alpha = gAlpha
            val y = rect.top + 1.8f * d
            val inset = rr * 0.8f
            if (rect.width() > inset * 2f) {
                canvas.drawLine(rect.left + inset, y, rect.right - inset, y, hi)
            }
        }

        override fun setAlpha(alpha: Int) {
            gAlpha = alpha.coerceIn(0, 255)
            invalidateSelf()
        }

        override fun setColorFilter(colorFilter: ColorFilter?) {
            filter = colorFilter
            fill.colorFilter = colorFilter
            scrim.colorFilter = colorFilter
            invalidateSelf()
        }

        @Suppress("OVERRIDE_DEPRECATION")
        override fun getOpacity(): Int = PixelFormat.TRANSLUCENT
    }
}

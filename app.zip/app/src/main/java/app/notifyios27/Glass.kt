package app.notifyios27

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ColorFilter
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.drawable.Drawable
import android.os.Build
import android.view.View
import android.view.WindowManager

/** The one place that draws Liquid Glass: flat tinted fill, 1 dp hairline rim, one solid 1 dp top highlight. */
object Glass {
    fun deviceBlurCapable(c: Context): Boolean {
        return try {
            if (Build.VERSION.SDK_INT < 31) {
                false
            } else {
                val wm = c.getSystemService(Context.WINDOW_SERVICE) as WindowManager
                wm.isCrossWindowBlurEnabled
            }
        } catch (e: Throwable) {
            false
        }
    }

    fun blurSupported(c: Context): Boolean {
        return try {
            Prefs.glassBlur && Perf.blurAllowed() && deviceBlurCapable(c)
        } catch (e: Throwable) {
            false
        }
    }

    /** Full blur radius in px after the tier cap. */
    fun radiusPx(c: Context): Int = Perf.blurPx(c, UiKit.dp(c, Prefs.glassBlurRadius))

    fun drawable(c: Context, radiusDp: Float, overlay: Boolean = false): Drawable =
        GlassDrawable(c, radiusDp, overlay)

    @Suppress("DEPRECATION")
    fun applyBlur(c: Context, lp: WindowManager.LayoutParams, radiusPx: Int = -1) {
        try {
            if (blurSupported(c)) {
                lp.flags = lp.flags or WindowManager.LayoutParams.FLAG_BLUR_BEHIND
                if (Build.VERSION.SDK_INT >= 31) {
                    lp.blurBehindRadius = if (radiusPx < 0) radiusPx(c) else Perf.blurPx(c, radiusPx)
                }
            } else {
                lp.flags = lp.flags and WindowManager.LayoutParams.FLAG_BLUR_BEHIND.inv()
                if (Build.VERSION.SDK_INT >= 31) lp.blurBehindRadius = 0
            }
        } catch (e: Throwable) {
        }
    }

    fun setBlurRadius(c: Context, view: View, lp: WindowManager.LayoutParams, radiusPx: Int) {
        if (!blurSupported(c)) return
        try {
            if (Build.VERSION.SDK_INT >= 31) {
                lp.blurBehindRadius = radiusPx
                val wm = c.getSystemService(Context.WINDOW_SERVICE) as WindowManager
                wm.updateViewLayout(view, lp)
            }
        } catch (e: Throwable) {
        }
    }

    // ---- contrast ----

    private fun lin(v: Int): Double {
        val s = v / 255.0
        return if (s <= 0.03928) s / 12.92 else Math.pow((s + 0.055) / 1.055, 2.4)
    }

    fun luminance(c: Int): Double =
        0.2126 * lin(Color.red(c)) + 0.7152 * lin(Color.green(c)) + 0.0722 * lin(Color.blue(c))

    fun contrast(a: Int, b: Int): Double {
        val la = luminance(a)
        val lb = luminance(b)
        return (Math.max(la, lb) + 0.05) / (Math.min(la, lb) + 0.05)
    }

    private fun mix(top: Int, a: Float, under: Int): Int = Color.rgb(
        (Color.red(top) * a + Color.red(under) * (1f - a)).toInt(),
        (Color.green(top) * a + Color.green(under) * (1f - a)).toInt(),
        (Color.blue(top) * a + Color.blue(under) * (1f - a)).toInt()
    )

    /** Smallest total opacity of [fill] that keeps [text] at 4.5:1 over the worst backdrop. */
    fun minOpacity(fill: Int, text: Int): Float {
        val worst = if (luminance(text) > 0.5) Color.WHITE else Color.BLACK
        var a = 0f
        while (a < 1f) {
            if (contrast(text, mix(fill, a, worst)) >= 4.5) return a
            a += 0.02f
        }
        return 1f
    }

    private val needCache = floatArrayOf(-1f, -1f)
    private val needFill = intArrayOf(0, 0)

    internal fun needFor(dark: Boolean, fill: Int, text: Int): Float {
        val i = if (dark) 1 else 0
        if (needCache[i] < 0f || needFill[i] != fill) {
            needCache[i] = minOpacity(fill, text)
            needFill[i] = fill
        }
        return needCache[i]
    }

    fun fillColor(dark: Boolean): Int =
        if (dark && Theme.amoled()) Color.BLACK else if (dark) Color.rgb(28, 28, 30) else Color.rgb(250, 250, 252)

    private class GlassDrawable(c: Context, radiusDp: Float, overlay: Boolean) : Drawable() {
        private val dark: Boolean = try { Prefs.isDark(c) } catch (e: Throwable) { false }
        private val d: Float = c.resources.displayMetrics.density
        private val radius: Float = Theme.corner(radiusDp) * d
        private val rect = RectF()
        private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
        private val scrim = Paint(Paint.ANTI_ALIAS_FLAG)
        private val rim = Paint(Paint.ANTI_ALIAS_FLAG)
        private val hi = Paint(Paint.ANTI_ALIAS_FLAG)
        private val fillA: Int
        private val scrimA: Int
        private val rimA: Int
        private val hiA: Int
        private var gAlpha = 255

        init {
            var a = try { Prefs.glass } catch (e: Throwable) { 0.30f }
            a = a.coerceIn(0.05f, 1f)
            if (overlay && !Glass.blurSupported(c)) a = Math.max(a, if (Perf.lite) 0.9f else 0.82f)
            val base = Glass.fillColor(dark)
            val text = if (dark) Color.WHITE else Color.rgb(17, 17, 17)
            val need = Glass.needFor(dark, base, text)
            // scrim makes up whatever the user's fill lacks for readable text
            val sa = if (a >= need) 0f else 1f - (1f - need) / (1f - a)
            fillA = (a * 255f).toInt().coerceIn(0, 255)
            scrimA = (sa * 255f).toInt().coerceIn(0, 255)
            fill.color = base
            scrim.color = base
            rim.style = Paint.Style.STROKE
            rim.strokeWidth = Math.max(1f, d)
            rim.color = if (dark) Color.WHITE else Color.BLACK
            val rs = try { Prefs.rimStyle } catch (e: Throwable) { 0 }
            if (rs == 2) rim.strokeWidth = Math.max(1f, 1.5f * d)
            rimA = when (rs) {
                1 -> 0
                2 -> if (dark) 80 else 50
                else -> if (dark) 38 else 22
            }
            hi.style = Paint.Style.STROKE
            hi.strokeWidth = Math.max(1f, d)
            hi.color = Color.WHITE
            hiA = if (dark) 46 else 150
        }

        override fun onBoundsChange(b: Rect) {
            super.onBoundsChange(b)
            val inset = 0.5f * d
            rect.set(b.left + inset, b.top + inset, b.right - inset, b.bottom - inset)
        }

        override fun draw(canvas: Canvas) {
            if (rect.width() <= 0f || rect.height() <= 0f) return
            val rr = Math.min(radius, Math.min(rect.width(), rect.height()) / 2f)
            if (scrimA > 0) {
                scrim.alpha = scrimA * gAlpha / 255
                canvas.drawRoundRect(rect, rr, rr, scrim)
            }
            fill.alpha = fillA * gAlpha / 255
            canvas.drawRoundRect(rect, rr, rr, fill)
            rim.alpha = rimA * gAlpha / 255
            canvas.drawRoundRect(rect, rr, rr, rim)
            val inset = Math.max(rr, 6f * d)
            if (rect.width() > inset * 2f) {
                hi.alpha = hiA * gAlpha / 255
                val y = rect.top + 1.5f * d
                canvas.drawLine(rect.left + inset, y, rect.right - inset, y, hi)
            }
        }

        override fun setAlpha(alpha: Int) {
            gAlpha = alpha.coerceIn(0, 255)
            invalidateSelf()
        }

        override fun setColorFilter(colorFilter: ColorFilter?) {
            fill.colorFilter = colorFilter
            scrim.colorFilter = colorFilter
            invalidateSelf()
        }

        @Suppress("OVERRIDE_DEPRECATION")
        override fun getOpacity(): Int = PixelFormat.TRANSLUCENT
    }
}

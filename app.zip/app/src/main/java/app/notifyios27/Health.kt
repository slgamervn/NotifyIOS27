package app.notifyios27

import android.app.NotificationManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.PowerManager
import android.provider.Settings
import android.service.notification.NotificationListenerService
import android.os.Handler
import android.os.Looper
import android.widget.Toast
import java.util.Calendar
import java.util.Locale

object Health {
    data class Status(
        val listenerAllowed: Boolean,
        val listenerConnected: Boolean,
        val overlayGranted: Boolean,
        val batteryUnrestricted: Boolean,
        val lastPostedAt: Long,
        val countToday: Int
    )

    @Volatile
    private var lastPosted = 0L

    private fun sp(c: Context) =
        c.applicationContext.getSharedPreferences("n27_health", Context.MODE_PRIVATE)

    fun markPosted(c: Context) {
        val now = System.currentTimeMillis()
        lastPosted = now
        try {
            sp(c).edit().putLong("lastPostedAt", now).apply()
        } catch (e: Exception) {
        }
    }

    fun status(c: Context): Status {
        val app = c.applicationContext
        var allowed = false
        try {
            val flat = Settings.Secure.getString(app.contentResolver, "enabled_notification_listeners")
            if (!flat.isNullOrEmpty()) {
                for (s in flat.split(":")) {
                    val cn = ComponentName.unflattenFromString(s)
                    if (cn != null && cn.packageName == app.packageName) allowed = true
                }
            }
        } catch (e: Exception) {
        }
        val connected = N27ListenerService.instance != null
        val overlay = try { Settings.canDrawOverlays(app) } catch (e: Exception) { false }
        val battery = try {
            val pm = app.getSystemService(Context.POWER_SERVICE) as PowerManager
            pm.isIgnoringBatteryOptimizations(app.packageName)
        } catch (e: Exception) {
            false
        }
        var last = lastPosted
        if (last == 0L) {
            last = try { sp(app).getLong("lastPostedAt", 0L) } catch (e: Exception) { 0L }
        }
        val cal = Calendar.getInstance()
        cal.set(Calendar.HOUR_OF_DAY, 0)
        cal.set(Calendar.MINUTE, 0)
        cal.set(Calendar.SECOND, 0)
        cal.set(Calendar.MILLISECOND, 0)
        val today = try { History.countSince(cal.timeInMillis) } catch (e: Exception) { 0 }
        return Status(allowed, connected, overlay, battery, last, today)
    }

    fun restartListener(c: Context) {
        val app = c.applicationContext
        val cn = ComponentName(app, N27ListenerService::class.java)
        try {
            val pm = app.packageManager
            pm.setComponentEnabledSetting(
                cn, PackageManager.COMPONENT_ENABLED_STATE_DISABLED, PackageManager.DONT_KILL_APP
            )
            pm.setComponentEnabledSetting(
                cn, PackageManager.COMPONENT_ENABLED_STATE_ENABLED, PackageManager.DONT_KILL_APP
            )
        } catch (e: Exception) {
        }
        try {
            NotificationListenerService.requestRebind(cn)
        } catch (e: Exception) {
        }
    }

    private fun group(): String {
        val m = (Build.MANUFACTURER ?: "").lowercase(Locale.ROOT)
        val b = (Build.BRAND ?: "").lowercase(Locale.ROOT)
        val s = "$m $b"
        return when {
            s.contains("xiaomi") || s.contains("redmi") || s.contains("poco") -> "xiaomi"
            s.contains("oppo") || s.contains("realme") || s.contains("oneplus") -> "oppo"
            s.contains("samsung") -> "samsung"
            s.contains("vivo") || s.contains("iqoo") -> "vivo"
            s.contains("huawei") || s.contains("honor") -> "huawei"
            else -> ""
        }
    }

    fun oemName(): String {
        val m = (Build.MANUFACTURER ?: "").lowercase(Locale.ROOT)
        val b = (Build.BRAND ?: "").lowercase(Locale.ROOT)
        val s = "$m $b"
        return when {
            s.contains("xiaomi") || s.contains("redmi") || s.contains("poco") -> "Xiaomi"
            s.contains("realme") -> "Realme"
            s.contains("oneplus") -> "OnePlus"
            s.contains("oppo") -> "Oppo"
            s.contains("samsung") -> "Samsung"
            s.contains("vivo") || s.contains("iqoo") -> "Vivo"
            s.contains("honor") -> "Honor"
            s.contains("huawei") -> "Huawei"
            else -> {
                val raw = Build.MANUFACTURER ?: ""
                if (raw.isEmpty()) "" else raw.substring(0, 1).uppercase(Locale.ROOT) + raw.substring(1)
            }
        }
    }

    private val CANDIDATES: Map<String, List<Pair<String, String>>> = mapOf(
        "xiaomi" to listOf(
            "com.miui.securitycenter" to "com.miui.permcenter.autostart.AutoStartManagementActivity",
            "com.miui.powerkeeper" to "com.miui.powerkeeper.ui.HiddenAppsConfigActivity"
        ),
        "oppo" to listOf(
            "com.coloros.safecenter" to "com.coloros.safecenter.permission.startup.StartupAppListActivity",
            "com.coloros.safecenter" to "com.coloros.safecenter.startupapp.StartupAppListActivity",
            "com.oppo.safe" to "com.oppo.safe.permission.startup.StartupAppListActivity",
            "com.oneplus.security" to "com.oneplus.security.chainlaunch.view.ChainLaunchAppListActivity"
        ),
        "samsung" to listOf(
            "com.samsung.android.lool" to "com.samsung.android.sm.ui.battery.BatteryActivity",
            "com.samsung.android.sm_cn" to "com.samsung.android.sm.ui.ram.AutoRunActivity"
        ),
        "vivo" to listOf(
            "com.vivo.permissionmanager" to "com.vivo.permissionmanager.activity.BgStartUpManagerActivity",
            "com.iqoo.secure" to "com.iqoo.secure.ui.phoneoptimize.AddWhiteListActivity",
            "com.iqoo.secure" to "com.iqoo.secure.ui.phoneoptimize.BgStartUpManager"
        ),
        "huawei" to listOf(
            "com.huawei.systemmanager" to "com.huawei.systemmanager.startupmgr.ui.StartupNormalAppListActivity",
            "com.huawei.systemmanager" to "com.huawei.systemmanager.optimize.process.ProtectActivity",
            "com.hihonor.systemmanager" to "com.hihonor.systemmanager.startupmgr.ui.StartupNormalAppListActivity"
        )
    )

    fun oemHelpIntent(c: Context): Intent? {
        val list = CANDIDATES[group()] ?: return null
        val pm = c.applicationContext.packageManager
        for ((pkg, cls) in list) {
            try {
                val i = Intent()
                i.component = ComponentName(pkg, cls)
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                if (pm.resolveActivity(i, 0) != null) return i
            } catch (e: Exception) {
            }
        }
        return null
    }
}

/** The app posts no system notifications of its own; reminders go through the banner, with a Toast as last resort. */
object OwnNotif {
    fun enabled(c: Context): Boolean {
        return try {
            val nm = c.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            if (!nm.areNotificationsEnabled()) return false
            if (Build.VERSION.SDK_INT >= 26) {
                for (ch in nm.notificationChannels) {
                    if (ch.importance == NotificationManager.IMPORTANCE_NONE) return false
                }
            }
            true
        } catch (e: Throwable) {
            true
        }
    }

    /** Shows a reminder so it is never lost silently. */
    fun deliver(c: Context, item: NotifItem, sound: Boolean = true) {
        val app = c.applicationContext ?: c
        try { BannerController.show(app, item, sound) } catch (e: Throwable) { }
        val canBanner = try { Settings.canDrawOverlays(app) } catch (e: Throwable) { false }
        if (!canBanner) {
            val msg = (item.title + (if (item.text.isNotBlank()) ": " + item.text else "")).trim()
            if (msg.isNotEmpty()) {
                try {
                    Handler(Looper.getMainLooper()).post {
                        try { Toast.makeText(app, msg, Toast.LENGTH_LONG).show() } catch (e: Throwable) { }
                    }
                } catch (e: Throwable) {
                }
            }
        }
    }
}


object AppSwitch {
    /** Removes anything currently on screen when the app is switched off. */
    fun stopAll(c: Context) {
        try { BannerController.dismissAll() } catch (e: Throwable) { }
        try { Island.dismissAll(c) } catch (e: Throwable) { }
        try { VolumeHud.removeNow() } catch (e: Throwable) { }
        try { ControlCenter.close() } catch (e: Throwable) { }
        try { ControlCenter.sync() } catch (e: Throwable) { }
    }
}

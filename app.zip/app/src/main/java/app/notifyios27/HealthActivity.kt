package app.notifyios27

import android.app.Activity
import android.graphics.Typeface
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class HealthActivity : Activity() {
    private lateinit var rows: LinearLayout
    private lateinit var oemView: TextView
    private val handler = Handler(Looper.getMainLooper())

    private fun dp(v: Int): Int = UiKit.dp(this, v)

    private fun lp(w: Int, h: Int, top: Int = 0, bottom: Int = 0): LinearLayout.LayoutParams {
        val p = LinearLayout.LayoutParams(w, h)
        p.topMargin = top
        p.bottomMargin = bottom
        return p
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val dark = Prefs.isDark(this)
        val match = ViewGroup.LayoutParams.MATCH_PARENT
        val wrap = ViewGroup.LayoutParams.WRAP_CONTENT

        val root = FrameLayout(this)
        root.background = UiKit.wallpaper(this)
        val scroll = ScrollView(this)
        scroll.isVerticalScrollBarEnabled = false
        scroll.clipToPadding = false
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(16), dp(16), dp(16), dp(24))
        scroll.addView(col, ViewGroup.LayoutParams(match, wrap))
        root.addView(scroll, FrameLayout.LayoutParams(match, match))

        val title = TextView(this)
        title.text = "Tình trạng dịch vụ"
        title.textSize = 28f
        title.typeface = Typeface.DEFAULT_BOLD
        title.setTextColor(UiKit.primary(dark))
        col.addView(title, lp(match, wrap, bottom = dp(14)))

        rows = LinearLayout(this)
        rows.orientation = LinearLayout.VERTICAL
        rows.background = UiKit.glass(this, 22f)
        rows.setPadding(dp(16), dp(6), dp(16), dp(6))
        col.addView(rows, lp(match, wrap))

        oemView = TextView(this)
        oemView.textSize = 14f
        oemView.setTextColor(UiKit.secondary(dark))
        oemView.setPadding(dp(4), dp(12), dp(4), dp(4))
        col.addView(oemView, lp(match, wrap))

        col.addView(button("Khởi động lại dịch vụ", true) {
            try {
                Health.restartListener(this)
                Toast.makeText(this, "Đang khởi động lại dịch vụ…", Toast.LENGTH_SHORT).show()
            } catch (e: Throwable) {
                Toast.makeText(this, "Không thể khởi động lại dịch vụ", Toast.LENGTH_SHORT).show()
            }
            refresh()
            handler.postDelayed({ refresh() }, 1500L)
        }, lp(match, wrap, top = dp(10)))

        col.addView(button("Cài đặt chạy nền của hãng máy", false) {
            val i = try { Health.oemHelpIntent(this) } catch (e: Throwable) { null }
            if (i == null) {
                Toast.makeText(this, "Máy của bạn không có cài đặt chạy nền riêng của hãng", Toast.LENGTH_LONG).show()
            } else {
                UiKit.safeStart(this, i)
            }
        }, lp(match, wrap, top = dp(10)))

        col.addView(button("Gửi banner thử", false) {
            try {
                val item = NotifItem(
                    key = "n27-health-test",
                    pkg = packageName,
                    appName = "notifyIOS27",
                    title = "Thông báo thử",
                    text = "Dịch vụ đang hoạt động bình thường",
                    time = System.currentTimeMillis()
                )
                BannerController.show(this, item)
            } catch (e: Throwable) {
                Toast.makeText(this, "Không thể hiển thị banner thử", Toast.LENGTH_SHORT).show()
            }
        }, lp(match, wrap, top = dp(10)))

        setContentView(root)
        UiKit.edgeToEdge(this, root, dark) { l, t, r, b -> scroll.setPadding(l, t, r, b) }
    }

    private fun button(text: String, filled: Boolean, onClick: () -> Unit): View {
        val b = UiKit.pillButton(this, text, filled)
        b.setOnClickListener { onClick() }
        return b
    }

    private fun row(ok: Boolean, label: String, value: String?): View {
        val dark = Prefs.isDark(this)
        val r = LinearLayout(this)
        r.orientation = LinearLayout.HORIZONTAL
        r.gravity = Gravity.CENTER_VERTICAL
        r.setPadding(0, dp(11), 0, dp(11))
        val e = TextView(this)
        e.text = if (ok) "✅" else "⚠️"
        e.textSize = 18f
        r.addView(e, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        val l = TextView(this)
        l.text = label
        l.textSize = 15f
        l.setTextColor(UiKit.primary(dark))
        l.setPadding(dp(10), 0, dp(8), 0)
        r.addView(l, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        if (value != null) {
            val v = TextView(this)
            v.text = value
            v.textSize = 14f
            v.gravity = Gravity.END
            v.setTextColor(UiKit.secondary(dark))
            r.addView(v, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        }
        return r
    }

    private fun refresh() {
        val s: Health.Status = try { Health.status(this) } catch (e: Throwable) { return }
        rows.removeAllViews()
        rows.addView(row(s.listenerAllowed, "Quyền truy cập thông báo", if (s.listenerAllowed) "Đã cấp" else "Chưa cấp"))
        rows.addView(row(s.listenerConnected, "Dịch vụ lắng nghe", if (s.listenerConnected) "Đang kết nối" else "Chưa kết nối"))
        rows.addView(row(s.overlayGranted, "Hiển thị trên ứng dụng khác", if (s.overlayGranted) "Đã cấp" else "Chưa cấp"))
        rows.addView(row(s.batteryUnrestricted, "Pin không bị hạn chế", if (s.batteryUnrestricted) "Đã bật" else "Đang hạn chế"))
        val last = if (s.lastPostedAt > 0L) {
            SimpleDateFormat("HH:mm dd/MM", Locale.ROOT).format(Date(s.lastPostedAt)) +
                " (" + UiKit.relativeTime(s.lastPostedAt) + ")"
        } else {
            "Chưa có"
        }
        rows.addView(row(s.lastPostedAt > 0L, "Thông báo gần nhất", last))
        rows.addView(row(s.countToday > 0, "Số thông báo hôm nay", s.countToday.toString()))
        val name = try { Health.oemName() } catch (e: Throwable) { "" }
        oemView.text = "Hãng máy: " + (if (name.isBlank()) "Không xác định" else name)
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        super.onDestroy()
    }
}

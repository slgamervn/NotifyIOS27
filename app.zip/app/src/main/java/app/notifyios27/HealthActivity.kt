package app.notifyios27

import android.app.Activity
import android.content.ComponentName
import android.content.Intent
import android.provider.Settings
import android.service.notification.NotificationListenerService
import android.graphics.Typeface
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class HealthActivity : Activity() {
    private lateinit var rows: LinearLayout
    private lateinit var oemView: TextView
    private lateinit var restrictedHolder: LinearLayout
    private val handler = Handler(Looper.getMainLooper())

    private fun dp(v: Int): Int = UiKit.dp(this, v)

    private fun lp(w: Int, h: Int, top: Int = 0, bottom: Int = 0): LinearLayout.LayoutParams {
        val p = LinearLayout.LayoutParams(w, h)
        p.topMargin = top
        p.bottomMargin = bottom
        return p
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val dark = Prefs.isDark(this)
        val match = ViewGroup.LayoutParams.MATCH_PARENT
        val wrap = ViewGroup.LayoutParams.WRAP_CONTENT

        val root = FrameLayout(this)
        root.background = UiKit.wallpaper(this)
        val scroll = ScrollView(this)
        scroll.isVerticalScrollBarEnabled = false
        scroll.clipToPadding = false
        val col = N27MaxWidthColumn(this, 640)
        col.setPadding(dp(16), dp(16), dp(16), dp(24))
        scroll.addView(col, FrameLayout.LayoutParams(match, wrap, Gravity.CENTER_HORIZONTAL))
        root.addView(scroll, FrameLayout.LayoutParams(match, match))

        val title = TextView(this)
        title.text = "Tình trạng dịch vụ"
        title.textSize = 28f
        title.typeface = Typeface.DEFAULT_BOLD
        title.setTextColor(UiKit.primary(dark))
        col.addView(title, lp(match, wrap, bottom = dp(14)))

        rows = LinearLayout(this)
        rows.orientation = LinearLayout.VERTICAL
        rows.background = UiKit.glass(this, 22f)
        rows.setPadding(dp(16), dp(6), dp(16), dp(6))
        col.addView(rows, lp(match, wrap))

        oemView = TextView(this)
        oemView.textSize = 14f
        oemView.setTextColor(UiKit.secondary(dark))
        oemView.setPadding(dp(4), dp(12), dp(4), dp(4))
        col.addView(oemView, lp(match, wrap))

        restrictedHolder = LinearLayout(this)
        restrictedHolder.orientation = LinearLayout.VERTICAL
        col.addView(restrictedHolder, lp(match, wrap, top = dp(12)))

        col.addView(button("Khởi động lại dịch vụ", true) {
            try {
                Health.restartListener(this)
                Toast.makeText(this, "Đang khởi động lại dịch vụ…", Toast.LENGTH_SHORT).show()
            } catch (e: Throwable) {
                Toast.makeText(this, "Không thể khởi động lại dịch vụ", Toast.LENGTH_SHORT).show()
            }
            refresh()
            handler.postDelayed({ refresh() }, 1500L)
        }, lp(match, wrap, top = dp(10)))

        col.addView(button("Cài đặt chạy nền của hãng máy", false) {
            val i = try { Health.oemHelpIntent(this) } catch (e: Throwable) { null }
            if (i == null) {
                Toast.makeText(this, "Máy của bạn không có cài đặt chạy nền riêng của hãng", Toast.LENGTH_LONG).show()
            } else {
                UiKit.safeStart(this, i)
            }
        }, lp(match, wrap, top = dp(10)))

        col.addView(button("Gửi banner thử", false) {
            try {
                val item = NotifItem(
                    key = "n27-health-test",
                    pkg = packageName,
                    appName = "notifyIOS27",
                    title = "Thông báo thử",
                    text = "Dịch vụ đang hoạt động bình thường",
                    time = System.currentTimeMillis()
                )
                BannerController.show(this, item)
            } catch (e: Throwable) {
                Toast.makeText(this, "Không thể hiển thị banner thử", Toast.LENGTH_SHORT).show()
            }
        }, lp(match, wrap, top = dp(10)))

        setContentView(root)
        UiKit.edgeToEdge(this, root, dark) { l, t, r, b -> scroll.setPadding(l, t, r, b) }
    }

    override fun onConfigurationChanged(newConfig: android.content.res.Configuration) {
        super.onConfigurationChanged(newConfig)
        try { window.decorView.requestApplyInsets() } catch (e: Throwable) { }
    }

    private fun button(text: String, filled: Boolean, onClick: () -> Unit): View {
        val b = UiKit.pillButton(this, text, filled)
        b.setOnClickListener { onClick() }
        return b
    }

    private fun row(ok: Boolean, label: String, value: String?, btnText: String? = null, onBtn: (() -> Unit)? = null): View {
        val dark = Prefs.isDark(this)
        val wrapC = ViewGroup.LayoutParams.WRAP_CONTENT
        val r = LinearLayout(this)
        r.orientation = LinearLayout.HORIZONTAL
        r.gravity = Gravity.CENTER_VERTICAL
        r.setPadding(0, dp(11), 0, dp(11))
        val e = TextView(this)
        e.text = if (ok) "✅" else "⚠️"
        e.textSize = 18f
        r.addView(e, LinearLayout.LayoutParams(wrapC, wrapC))
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(10), 0, dp(8), 0)
        val l = TextView(this)
        l.text = label
        l.textSize = 15f
        l.setTextColor(UiKit.primary(dark))
        col.addView(l)
        if (value != null) {
            val v = TextView(this)
            v.text = value
            v.textSize = 13f
            v.setTextColor(UiKit.secondary(dark))
            col.addView(v)
        }
        r.addView(col, LinearLayout.LayoutParams(0, wrapC, 1f))
        if (btnText != null && onBtn != null) {
            val b = UiKit.pillButton(this, btnText, !ok)
            b.setOnClickListener { onBtn() }
            r.addView(b, LinearLayout.LayoutParams(wrapC, wrapC))
        }
        return r
    }

    private fun timeText(t: Long): String =
        SimpleDateFormat("HH:mm dd/MM", Locale.ROOT).format(Date(t))

    private fun refresh() {
        val s: Health.Status = try { Health.status(this) } catch (e: Throwable) { return }
        rows.removeAllViews()
        rows.addView(row(
            s.listenerAllowed, "Quyền truy cập thông báo", if (s.listenerAllowed) "Đã cấp" else "Chưa cấp",
            if (s.listenerAllowed) null else "Cấp quyền"
        ) { UiKit.openNotifAccess(this) })

        val conn = N27ListenerService.connected
        val lastConn = N27ListenerService.lastConnectAt
        val connValue = (if (conn) "Đang kết nối" else "Chưa kết nối") +
            (if (lastConn > 0L) " · " + timeText(lastConn) else "")
        val canRebind = s.listenerAllowed && !conn
        rows.addView(row(conn, "Bộ nghe thông báo", connValue, if (canRebind) "Kết nối lại" else null) {
            try {
                NotificationListenerService.requestRebind(ComponentName(this, N27ListenerService::class.java))
                Toast.makeText(this, "Đang kết nối lại…", Toast.LENGTH_SHORT).show()
            } catch (e: Throwable) {
                Toast.makeText(this, "Không thể kết nối lại", Toast.LENGTH_SHORT).show()
            }
            handler.postDelayed({ refresh() }, 1500L)
        })

        rows.addView(row(
            s.overlayGranted, "Hiển thị trên ứng dụng khác", if (s.overlayGranted) "Đã cấp" else "Chưa cấp",
            if (s.overlayGranted) null else "Cấp quyền"
        ) { UiKit.openOverlay(this) })

        val own = OwnNotif.enabled(this)
        rows.addView(row(own, "Thông báo của notifyIOS27", if (own) "Đang bật" else "Đang tắt", "Mở cài đặt") {
            val i = Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS)
            i.putExtra(Settings.EXTRA_APP_PACKAGE, packageName)
            UiKit.safeStart(this, i)
        })

        val dnd = Dnd.active(this)
        rows.addView(row(!dnd, "Không làm phiền", if (dnd) "Đang bật" else "Đang tắt", "Mở cài đặt") {
            UiKit.safeStart(this, Intent(Settings.ACTION_SOUND_SETTINGS))
        })

        rows.addView(row(
            s.batteryUnrestricted, "Tối ưu pin", if (s.batteryUnrestricted) "Không bị hạn chế" else "Đang hạn chế",
            if (s.batteryUnrestricted) null else "Bỏ giới hạn"
        ) { UiKit.openBattery(this) })

        val last = if (s.lastPostedAt > 0L) {
            timeText(s.lastPostedAt) + " (" + UiKit.relativeTime(s.lastPostedAt) + ")"
        } else {
            "Chưa có"
        }
        rows.addView(row(s.lastPostedAt > 0L, "Thông báo gần nhất", last))
        rows.addView(row(s.countToday > 0, "Số thông báo hôm nay", s.countToday.toString()))
        val name = try { Health.oemName() } catch (e: Throwable) { "" }
        oemView.text = "Hãng máy: " + (if (name.isBlank()) "Không xác định" else name)

        restrictedHolder.removeAllViews()
        if (!s.listenerAllowed) {
            restrictedHolder.addView(
                UiKit.restrictedCard(this, Prefs.isDark(this)),
                LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            )
        }
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        super.onDestroy()
    }
}

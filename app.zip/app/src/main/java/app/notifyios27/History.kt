package app.notifyios27

import android.content.ContentValues
import android.content.Context
import android.database.DatabaseUtils
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object History {
    private const val TABLE = "history"
    private val lock = Any()
    private var helper: SQLiteOpenHelper? = null

    private class Helper(c: Context) : SQLiteOpenHelper(c, "n27_history", null, 1) {
        override fun onCreate(db: SQLiteDatabase) {
            db.execSQL(
                "CREATE TABLE history (id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                    "pkg TEXT NOT NULL, appName TEXT NOT NULL, title TEXT NOT NULL, " +
                    "text TEXT NOT NULL, time INTEGER NOT NULL, otp TEXT)"
            )
            db.execSQL("CREATE INDEX idx_history_time ON history(time)")
        }

        override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        }
    }

    fun init(c: Context) {
        synchronized(lock) {
            if (helper == null) helper = Helper(c.applicationContext)
        }
    }

    internal fun <T> withDb(default: T, block: (SQLiteDatabase) -> T): T {
        return try {
            synchronized(lock) {
                val h = helper
                if (h == null) default else block(h.writableDatabase)
            }
        } catch (e: Exception) {
            default
        }
    }

    internal fun countSince(t: Long): Int = withDb(0) { db ->
        DatabaseUtils.queryNumEntries(db, TABLE, "time >= ?", arrayOf(t.toString())).toInt()
    }

    fun add(item: NotifItem) {
        withDb(Unit) { db ->
            val v = ContentValues()
            v.put("pkg", item.pkg)
            v.put("appName", item.appName)
            v.put("title", item.title)
            v.put("text", item.text)
            v.put("time", item.time)
            v.put("otp", item.otp)
            db.insert(TABLE, null, v)
            Unit
        }
    }

    fun query(q: String?, pkg: String?, fromTime: Long, limit: Int, offset: Int): List<HistoryRow> {
        return withDb(emptyList<HistoryRow>()) { db ->
            val where = StringBuilder("time >= ?")
            val args = ArrayList<String>()
            args.add(fromTime.toString())
            if (!pkg.isNullOrEmpty()) {
                where.append(" AND pkg = ?")
                args.add(pkg)
            }
            val needle = q?.trim()?.takeIf { it.isNotEmpty() }
            val out = ArrayList<HistoryRow>()
            var toSkip = if (offset > 0) offset else 0
            val cur = db.query(
                TABLE, null, where.toString(), args.toTypedArray(),
                null, null, "time DESC, id DESC"
            )
            try {
                val iId = cur.getColumnIndexOrThrow("id")
                val iPkg = cur.getColumnIndexOrThrow("pkg")
                val iApp = cur.getColumnIndexOrThrow("appName")
                val iTitle = cur.getColumnIndexOrThrow("title")
                val iText = cur.getColumnIndexOrThrow("text")
                val iTime = cur.getColumnIndexOrThrow("time")
                val iOtp = cur.getColumnIndexOrThrow("otp")
                while (cur.moveToNext()) {
                    val title = cur.getString(iTitle) ?: ""
                    val text = cur.getString(iText) ?: ""
                    if (needle != null &&
                        !title.contains(needle, ignoreCase = true) &&
                        !text.contains(needle, ignoreCase = true)
                    ) continue
                    if (toSkip > 0) {
                        toSkip--
                        continue
                    }
                    out.add(
                        HistoryRow(
                            cur.getLong(iId),
                            cur.getString(iPkg) ?: "",
                            cur.getString(iApp) ?: "",
                            title,
                            text,
                            cur.getLong(iTime),
                            if (cur.isNull(iOtp)) null else cur.getString(iOtp)
                        )
                    )
                    if (limit > 0 && out.size >= limit) break
                }
            } finally {
                cur.close()
            }
            out as List<HistoryRow>
        }
    }

    fun delete(id: Long) {
        withDb(Unit) { db ->
            db.delete(TABLE, "id = ?", arrayOf(id.toString()))
            Unit
        }
    }

    fun deleteApp(pkg: String) {
        withDb(Unit) { db ->
            db.delete(TABLE, "pkg = ?", arrayOf(pkg))
            Unit
        }
    }

    fun clear() {
        withDb(Unit) { db ->
            db.delete(TABLE, null, null)
            Unit
        }
    }

    fun purgeOld(days: Int) {
        if (days <= 0) return
        val cutoff = System.currentTimeMillis() - days * 86400000L
        withDb(Unit) { db ->
            db.delete(TABLE, "time < ?", arrayOf(cutoff.toString()))
            Unit
        }
    }

    fun count(): Int = withDb(0) { db ->
        DatabaseUtils.queryNumEntries(db, TABLE).toInt()
    }

    fun exportText(c: Context): String {
        init(c)
        val fmt = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault())
        val sb = StringBuilder()
        for (r in query(null, null, 0L, 0, 0)) {
            sb.append(fmt.format(Date(r.time)))
                .append(" | ").append(r.appName)
                .append(" | ").append(r.title.replace('\n', ' '))
                .append(" | ").append(r.text.replace('\n', ' '))
            if (r.otp != null) sb.append(" | OTP ").append(r.otp)
            sb.append('\n')
        }
        return sb.toString()
    }
}

package app.notifyios27

import android.app.Activity
import android.graphics.Typeface
import android.os.Handler
import android.os.Looper
import android.text.TextUtils
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.TextView
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

/** "Lịch sử": searchable, filterable, paged notification history. */
internal class HistoryTab(private val a: Activity) : N27Tab {
    private val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
    private val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT
    private val PAGE = 50

    private var dark = Prefs.isDark(a)
    private val handler = Handler(Looper.getMainLooper())
    private val root = LinearLayout(a)
    private val chipRow = LinearLayout(a)
    private val list = LinearLayout(a)
    private val search: EditText
    private var query = ""
    private var pkgFilter: String? = null
    private var loaded = 0
    private var lastDay = -1
    private var loadMoreRow: View? = null
    private var empty: TextView? = null
    private val timeFmt = SimpleDateFormat("HH:mm", Locale.US)
    private val dateFmt = SimpleDateFormat("dd/MM", Locale.US)

    private val debounce = Runnable {
        loaded = 0
        reload()
    }

    override val view: View get() = root

    private fun dp(v: Int): Int = UiKit.dp(a, v)

    init {
        root.orientation = LinearLayout.VERTICAL
        search = Cards.searchField(a, "Tìm trong lịch sử", dark) { q ->
            query = q
            handler.removeCallbacks(debounce)
            handler.postDelayed(debounce, 300L)
        }
        search.id = 0x4E270002
        root.addView(search, LinearLayout.LayoutParams(MATCH, WRAP).apply { bottomMargin = dp(10) })
        val hs = HorizontalScrollView(a)
        hs.isHorizontalScrollBarEnabled = false
        chipRow.orientation = LinearLayout.HORIZONTAL
        hs.addView(chipRow, ViewGroup.LayoutParams(WRAP, WRAP))
        root.addView(hs, LinearLayout.LayoutParams(MATCH, WRAP).apply { bottomMargin = dp(10) })
        list.orientation = LinearLayout.VERTICAL
        root.addView(list, LinearLayout.LayoutParams(MATCH, WRAP))
    }

    override fun onShow() {
        dark = Prefs.isDark(a)
        search.background = UiKit.glass(a, 16f)
        search.setTextColor(UiKit.primary(dark))
        search.setHintTextColor(UiKit.secondary(dark))
        buildChips()
        reload()
    }

    override fun onHide() {
        handler.removeCallbacks(debounce)
    }

    override fun onStoreChanged() {}

    override fun onTick() {}

    private fun chip(label: String, selected: Boolean, onClick: () -> Unit): TextView {
        val t = TextView(a)
        t.text = label
        t.textSize = 13.5f
        t.maxLines = 1
        t.ellipsize = TextUtils.TruncateAt.END
        t.gravity = Gravity.CENTER
        t.setPadding(dp(14), dp(7), dp(14), dp(7))
        if (selected) {
            t.setTextColor(android.graphics.Color.WHITE)
            t.typeface = Typeface.DEFAULT_BOLD
            t.background = UiKit.rounded(a, UiKit.accent(a), 18f)
        } else {
            t.setTextColor(UiKit.primary(dark))
            t.background = UiKit.glass(a, 18f)
        }
        t.setOnClickListener { onClick() }
        return t
    }

    private fun buildChips() {
        chipRow.removeAllViews()
        val apps: List<Pair<String, Int>> = try { Stats.perApp(30) } catch (e: Exception) { emptyList<Pair<String, Int>>() }
        chipRow.addView(chip("Tất cả", pkgFilter == null) { selectPkg(null) },
            LinearLayout.LayoutParams(WRAP, WRAP).apply { rightMargin = dp(8) })
        for (p in apps) {
            val pkg = p.first
            chipRow.addView(chip(AppIcons.label(a, pkg), pkgFilter == pkg) { selectPkg(pkg) },
                LinearLayout.LayoutParams(WRAP, WRAP).apply { rightMargin = dp(8) })
        }
    }

    private fun selectPkg(pkg: String?) {
        pkgFilter = pkg
        loaded = 0
        buildChips()
        reload()
    }

    private fun fetch(): List<HistoryRow> {
        return try {
            History.query(query.trim().takeIf { it.isNotEmpty() }, pkgFilter, 0L, PAGE, loaded)
        } catch (e: Exception) {
            emptyList<HistoryRow>()
        }
    }

    /** Loads the first page again (resets the list). */
    private fun reload() {
        list.removeAllViews()
        loadMoreRow = null
        empty = null
        lastDay = -1
        loaded = 0
        val rows = fetch()
        if (rows.isEmpty()) {
            val t = TextView(a)
            t.text = "Không có kết quả"
            t.textSize = 17f
            t.gravity = Gravity.CENTER
            t.setTextColor(UiKit.secondary(dark))
            t.setPadding(0, dp(60), 0, 0)
            list.addView(t, LinearLayout.LayoutParams(MATCH, WRAP))
            empty = t
            return
        }
        append(rows)
    }

    private fun loadMore() {
        val rows = fetch()
        append(rows)
    }

    private fun dayKey(t: Long): Int {
        val c = Calendar.getInstance()
        c.timeInMillis = t
        return c.get(Calendar.YEAR) * 1000 + c.get(Calendar.DAY_OF_YEAR)
    }

    private fun dayLabel(t: Long): String {
        val today = dayKey(System.currentTimeMillis())
        val k = dayKey(t)
        val y = Calendar.getInstance()
        y.add(Calendar.DAY_OF_YEAR, -1)
        return when (k) {
            today -> "Hôm nay"
            y.get(Calendar.YEAR) * 1000 + y.get(Calendar.DAY_OF_YEAR) -> "Hôm qua"
            else -> dateFmt.format(Date(t))
        }
    }

    private fun append(rows: List<HistoryRow>) {
        loadMoreRow?.let { list.removeView(it) }
        loadMoreRow = null
        for (r in rows) {
            val k = dayKey(r.time)
            if (k != lastDay) {
                lastDay = k
                list.addView(Cards.sectionHeader(a, dayLabel(r.time), dark))
            }
            list.addView(makeRow(r), LinearLayout.LayoutParams(MATCH, WRAP).apply { bottomMargin = dp(8) })
        }
        loaded += rows.size
        if (rows.size >= PAGE) {
            val more = TextView(a)
            more.text = "Tải thêm"
            more.textSize = 14.5f
            more.typeface = Typeface.DEFAULT_BOLD
            more.setTextColor(UiKit.accent(a))
            more.gravity = Gravity.CENTER
            more.setPadding(dp(18), dp(12), dp(18), dp(12))
            more.background = UiKit.glass(a, 18f)
            more.setOnClickListener { loadMore() }
            list.addView(more, LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(4) })
            loadMoreRow = more
        }
    }

    private fun makeRow(r: HistoryRow): View {
        val row = LinearLayout(a)
        row.orientation = LinearLayout.HORIZONTAL
        row.setPadding(dp(14), dp(10), dp(14), dp(10))
        row.background = UiKit.glass(a, 20f)
        row.addView(UiKit.iconView(a, r.pkg, 36), LinearLayout.LayoutParams(dp(36), dp(36)))
        val col = LinearLayout(a)
        col.orientation = LinearLayout.VERTICAL
        val top = LinearLayout(a)
        top.orientation = LinearLayout.HORIZONTAL
        val name = TextView(a)
        name.text = if (r.appName.isBlank()) AppIcons.label(a, r.pkg) else r.appName
        name.textSize = 12.5f
        name.setTextColor(UiKit.secondary(dark))
        name.maxLines = 1
        name.ellipsize = TextUtils.TruncateAt.END
        top.addView(name, LinearLayout.LayoutParams(0, WRAP, 1f))
        val time = TextView(a)
        time.text = timeFmt.format(Date(r.time))
        time.textSize = 12.5f
        time.setTextColor(UiKit.secondary(dark))
        top.addView(time, LinearLayout.LayoutParams(WRAP, WRAP).apply { leftMargin = dp(6) })
        col.addView(top, LinearLayout.LayoutParams(MATCH, WRAP))
        if (r.title.isNotBlank()) {
            val t = TextView(a)
            t.text = r.title
            t.textSize = 14.5f
            t.typeface = Typeface.DEFAULT_BOLD
            t.setTextColor(UiKit.primary(dark))
            t.maxLines = 1
            t.ellipsize = TextUtils.TruncateAt.END
            col.addView(t, LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(2) })
        }
        if (r.text.isNotBlank()) {
            val t = TextView(a)
            t.text = r.text
            t.textSize = 13.5f
            t.setTextColor(UiKit.primary(dark))
            t.maxLines = 2
            t.ellipsize = TextUtils.TruncateAt.END
            col.addView(t, LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(1) })
        }
        row.addView(col, LinearLayout.LayoutParams(0, WRAP, 1f).apply { leftMargin = dp(12) })
        row.setOnClickListener { showDetail(r) }
        return row
    }

    private fun showDetail(r: HistoryRow) {
        val name = if (r.appName.isBlank()) AppIcons.label(a, r.pkg) else r.appName
        val full = listOf(r.title, r.text).filter { it.isNotBlank() }.joinToString("\n")
        val msg = full + "\n\n" + SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.US).format(Date(r.time))
        try {
            Cards.dialog(a).setTitle(name)
                .setMessage(msg)
                .setPositiveButton("Sao chép") { _, _ -> ItemActions.copyText(a, full) }
                .setNegativeButton("Xóa") { _, _ ->
                    try { History.delete(r.id) } catch (e: Exception) { }
                    reload()
                }
                .setNeutralButton("Đóng", null)
                .show()
        } catch (e: Exception) {
        }
    }
}

package app.notifyios27

import android.content.Context
import android.graphics.Canvas
import android.graphics.ColorFilter
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.RectF
import android.graphics.drawable.Drawable
import android.widget.TextView

/** Icon vẽ bằng Canvas, thay cho emoji và ký tự symbol. Không cần tài nguyên hay thư viện. */
object N27Icons {
    const val CLOSE = 0
    const val PLUS = 1
    const val LOCK = 2
    const val GEAR = 3
    const val POWER = 4
    const val BELL = 5
    const val CLOCK = 6
    const val CHART = 7
    const val PIN = 8
    const val CHECK = 9
    const val WARN = 10
    const val SHIELD = 11
    const val DOWNLOAD = 12
    const val WINDOW = 13
    const val BATTERY = 14

    fun drawable(c: Context, kind: Int, color: Int, sizeDp: Int = 20): Drawable =
        N27Icon(kind, color, UiKit.dp(c, sizeDp))

    /** Đặt icon vào TextView (xóa chữ). Dùng cho các nút tròn. */
    fun set(tv: TextView, kind: Int, color: Int, sizeDp: Int = 20) {
        tv.text = ""
        tv.setCompoundDrawablePadding(0)
        tv.setCompoundDrawablesWithIntrinsicBounds(drawable(tv.context, kind, color, sizeDp), null, null, null)
    }

    /** Icon nằm phía trên chữ (dùng cho thanh tab dọc). */
    fun setTop(tv: TextView, kind: Int, color: Int, sizeDp: Int = 22) {
        tv.setCompoundDrawablePadding(UiKit.dp(tv.context, 2))
        tv.setCompoundDrawablesWithIntrinsicBounds(null, drawable(tv.context, kind, color, sizeDp), null, null)
    }

    fun clear(tv: TextView) {
        tv.setCompoundDrawables(null, null, null, null)
    }
}

private class N27Icon(private val kind: Int, private val color: Int, private val sizePx: Int) : Drawable() {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val path = Path()
    private val rect = RectF()

    override fun getIntrinsicWidth(): Int = sizePx
    override fun getIntrinsicHeight(): Int = sizePx

    private fun stroke() {
        p.style = Paint.Style.STROKE
        p.strokeWidth = 2f
        p.strokeCap = Paint.Cap.ROUND
        p.strokeJoin = Paint.Join.ROUND
        p.color = color
    }

    private fun fill() {
        p.style = Paint.Style.FILL
        p.color = color
    }

    override fun draw(c: Canvas) {
        val b = bounds
        if (b.width() <= 0) return
        val s = b.width() / 24f
        c.save()
        c.translate(b.left.toFloat(), b.top.toFloat())
        c.scale(s, s)
        stroke()
        when (kind) {
            N27Icons.CLOSE -> {
                c.drawLine(6f, 6f, 18f, 18f, p)
                c.drawLine(18f, 6f, 6f, 18f, p)
            }
            N27Icons.PLUS -> {
                c.drawLine(12f, 5f, 12f, 19f, p)
                c.drawLine(5f, 12f, 19f, 12f, p)
            }
            N27Icons.LOCK -> {
                rect.set(5f, 11f, 19f, 21f)
                c.drawRoundRect(rect, 2.5f, 2.5f, p)
                rect.set(8f, 3.5f, 16f, 12.5f)
                c.drawArc(rect, 180f, 180f, false, p)
                c.drawLine(8f, 8f, 8f, 11f, p)
                c.drawLine(16f, 8f, 16f, 11f, p)
            }
            N27Icons.GEAR -> {
                c.drawCircle(12f, 12f, 3f, p)
                c.drawCircle(12f, 12f, 6.5f, p)
                for (i in 0 until 8) {
                    val a = Math.toRadians(i * 45.0)
                    val cs = Math.cos(a).toFloat()
                    val sn = Math.sin(a).toFloat()
                    c.drawLine(12f + cs * 6.5f, 12f + sn * 6.5f, 12f + cs * 9.5f, 12f + sn * 9.5f, p)
                }
            }
            N27Icons.POWER -> {
                rect.set(4f, 4f, 20f, 20f)
                c.drawArc(rect, 300f, 300f, false, p)
                c.drawLine(12f, 3f, 12f, 12f, p)
            }
            N27Icons.BELL -> {
                path.reset()
                path.moveTo(6f, 17f)
                path.lineTo(6f, 10f)
                rect.set(6f, 4f, 18f, 16f)
                path.arcTo(rect, 180f, 180f)
                path.lineTo(18f, 17f)
                path.close()
                c.drawPath(path, p)
                c.drawLine(4f, 17f, 20f, 17f, p)
                rect.set(9.5f, 17.5f, 14.5f, 22f)
                c.drawArc(rect, 0f, 180f, false, p)
            }
            N27Icons.CLOCK -> {
                c.drawCircle(12f, 12f, 9f, p)
                c.drawLine(12f, 7f, 12f, 12f, p)
                c.drawLine(12f, 12f, 16f, 14f, p)
            }
            N27Icons.CHART -> {
                p.strokeWidth = 3.2f
                c.drawLine(6f, 19f, 6f, 13f, p)
                c.drawLine(12f, 19f, 12f, 5f, p)
                c.drawLine(18f, 19f, 18f, 9f, p)
            }
            N27Icons.PIN -> {
                fill()
                c.drawCircle(12f, 8.5f, 4.5f, p)
                stroke()
                c.drawLine(12f, 13f, 12f, 21f, p)
            }
            N27Icons.CHECK -> {
                p.strokeWidth = 2.4f
                path.reset()
                path.moveTo(5f, 12.5f)
                path.lineTo(10f, 17.5f)
                path.lineTo(19f, 7f)
                c.drawPath(path, p)
            }
            N27Icons.WARN -> {
                path.reset()
                path.moveTo(12f, 4f)
                path.lineTo(21f, 19.5f)
                path.lineTo(3f, 19.5f)
                path.close()
                c.drawPath(path, p)
                c.drawLine(12f, 10f, 12f, 14f, p)
                fill()
                c.drawCircle(12f, 16.8f, 1.1f, p)
            }
            N27Icons.SHIELD -> {
                path.reset()
                path.moveTo(12f, 3f)
                path.lineTo(19f, 6f)
                path.lineTo(19f, 12f)
                path.quadTo(19f, 18f, 12f, 21f)
                path.quadTo(5f, 18f, 5f, 12f)
                path.lineTo(5f, 6f)
                path.close()
                c.drawPath(path, p)
            }
            N27Icons.DOWNLOAD -> {
                c.drawLine(12f, 4f, 12f, 15f, p)
                path.reset()
                path.moveTo(7f, 10.5f)
                path.lineTo(12f, 15.5f)
                path.lineTo(17f, 10.5f)
                c.drawPath(path, p)
                c.drawLine(5f, 20f, 19f, 20f, p)
            }
            N27Icons.WINDOW -> {
                rect.set(3f, 5f, 21f, 19f)
                c.drawRoundRect(rect, 2.5f, 2.5f, p)
                c.drawLine(3f, 9.5f, 21f, 9.5f, p)
            }
            N27Icons.BATTERY -> {
                rect.set(3f, 8f, 19f, 16f)
                c.drawRoundRect(rect, 2f, 2f, p)
                fill()
                rect.set(5f, 10f, 12f, 14f)
                c.drawRect(rect, p)
                rect.set(19.5f, 10.5f, 21.5f, 13.5f)
                c.drawRect(rect, p)
            }
        }
        c.restore()
    }

    override fun setAlpha(alpha: Int) {}
    override fun setColorFilter(cf: ColorFilter?) {}
    @Suppress("OVERRIDE_DEPRECATION")
    override fun getOpacity(): Int = PixelFormat.TRANSLUCENT
}

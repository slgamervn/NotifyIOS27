package app.notifyios27

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.graphics.drawable.Icon
import android.os.Build
import android.service.quicksettings.Tile
import android.service.quicksettings.TileService

class IslandReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context?, intent: Intent?) {
        try {
            if (context == null) return
            if (intent?.action == "app.notifyios27.ISLAND_TIMER_FIRE") Island.onTimerFire(context)
        } catch (e: Throwable) {
        }
    }
}

class IslandTileService : TileService() {
    override fun onStartListening() {
        super.onStartListening()
        refresh()
    }

    override fun onClick() {
        super.onClick()
        try {
            Prefs.islandEnabled = !Prefs.islandEnabled
            if (!Prefs.islandEnabled) Island.dismissAll(this)
        } catch (e: Throwable) {
        }
        refresh()
    }

    private fun refresh() {
        val t = qsTile ?: return
        try {
            val on = Prefs.islandEnabled
            t.state = if (on) Tile.STATE_ACTIVE else Tile.STATE_INACTIVE
            t.label = "Dynamic Island"
            if (Build.VERSION.SDK_INT >= 29) t.subtitle = if (on) "Bật" else "Tắt"
            t.icon = Icon.createWithResource(this, R.drawable.n27i_tile_island)
            t.updateTile()
        } catch (e: Throwable) {
        }
    }
}

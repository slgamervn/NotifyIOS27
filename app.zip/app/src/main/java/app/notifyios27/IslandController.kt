package app.notifyios27

import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.ValueAnimator
import android.app.KeyguardManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.res.Configuration
import android.graphics.PixelFormat
import android.graphics.Rect
import android.media.AudioAttributes
import android.media.Ringtone
import android.media.RingtoneManager
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.os.SystemClock
import android.os.VibrationEffect
import android.os.Vibrator
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.view.animation.DecelerateInterpolator
import android.view.animation.OvershootInterpolator
import android.widget.FrameLayout
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicBoolean

object Island {
    const val SRC_MEDIA = 1
    const val SRC_CALL = 2
    const val SRC_TIMER = 4
    const val SRC_PROGRESS = 8
    const val SRC_NAV = 16
    const val SRC_CHARGE = 32
    const val SRC_RINGER = 64
    const val SRC_HEADSET = 128
    const val SRC_OTHER = 256

    private const val M_COMPACT = 0
    private const val M_EXPANDED = 1
    private const val M_NOTIF = 2
    private const val M_NOTIF_BIG = 3
    private const val M_TOOLS = 4

    private class Post(val item: NotifItem, val kind: Int)
    private class QItem(val item: NotifItem, val sound: Boolean, val blocked: Boolean = false)

    private val main = Handler(Looper.getMainLooper())
    private val started = AtomicBoolean(false)

    @Volatile
    private var app: Context? = null

    @Volatile
    private var startAt = 0L
    private val pending = ConcurrentHashMap<String, Post>()
    private val drainQueued = AtomicBoolean(false)

    // ---- main-thread state ----
    private val acts = LinkedHashMap<String, LiveActivity>()
    private val hidden = HashSet<String>()
    private val nq = ArrayList<QItem>()
    private var notif: NotifItem? = null
    private var mode = M_COMPACT
    private var expandedKey: String? = null
    private var swapped = false
    private var lastPairKeys = ""
    private var touching = false
    private var bigHasReply = false
    private var ringtone: Ringtone? = null
    private var curBlocked = false

    // ---- window ----
    private var view: IslandView? = null
    private var wm: WindowManager? = null
    private var lp: WindowManager.LayoutParams? = null
    private var content: IslandContent? = null
    private var fadingOld: View? = null
    private var exiting = false
    private var primaryKey: String? = null
    private var secondKey: String? = null
    private var anim: ValueAnimator? = null
    private var animCancelled = false

    // ---- geometry (px) ----
    private var cutoutRead = false
    private var haveCut = false
    private var cutW = 0
    private var cutCx = 0f
    private var cutCy = 0f
    private var screenW = 0
    private var topYpx = 0
    private var circleGap = 0
    private var curW = 0f
    private var curH = 0f
    private var curC = 0f
    private var curR = 0f
    private var fW = 0f
    private var fH = 0f
    private var fC = 0f
    private var fR = 0f
    private var tW = 0f
    private var tH = 0f
    private var tC = 0f
    private var tR = 0f
    private var tLeftI = 0
    private var tRightI = 0
    private var tHeightI = 0
    private var winL = 0
    private var winW = 0
    private var winH = 0

    // ================= public API =================

    fun start(c: Context) {
        val ctx = c.applicationContext ?: c
        app = ctx
        if (!started.compareAndSet(false, true)) return
        startAt = SystemClock.elapsedRealtime()
        try {
            val f = IntentFilter()
            f.addAction(Intent.ACTION_SCREEN_ON)
            f.addAction(Intent.ACTION_SCREEN_OFF)
            f.addAction(Intent.ACTION_USER_PRESENT)
            f.addAction(Intent.ACTION_CONFIGURATION_CHANGED)
            if (Build.VERSION.SDK_INT >= 33) {
                ctx.registerReceiver(screenReceiver, f, Context.RECEIVER_NOT_EXPORTED)
            } else {
                ctx.registerReceiver(screenReceiver, f)
            }
        } catch (e: Throwable) {
        }
        try { IslandSystem.start(ctx) } catch (e: Throwable) { }
        main.post {
            try { IslandTools.rearm(ctx) } catch (e: Throwable) { }
            refresh()
        }
    }

    fun onPosted(c: Context, item: NotifItem): Boolean {
        return try {
            val kind = IslandSources.classify(item)
            if (kind < 0) return false
            if (!Prefs.islandEnabled) return false
            if ((Prefs.islandSources and IslandSources.srcBit(kind)) == 0) return false
            val ctx = c.applicationContext ?: c
            if (!Prefs.isAppEnabled(item.pkg)) return false
            if (!Rules.appRule(ctx, item.pkg).island) return false
            if (!canOverlay(ctx)) return false
            app = ctx
            pending[item.key] = Post(item, kind)
            if (drainQueued.compareAndSet(false, true)) main.post(drainRun)
            true
        } catch (e: Throwable) {
            false
        }
    }

    fun onRemoved(c: Context, key: String) {
        pending.remove(key)
        runMain {
            pending.remove(key)
            hidden.remove(key)
            IslandSources.detachMedia(key)
            if (acts.remove(key) != null) {
                scheduleExpiry()
                refresh()
            }
        }
    }

    fun showNotification(c: Context, item: NotifItem, sound: Boolean, dnd: Boolean = false): Boolean {
        return try {
            if (!Prefs.islandEnabled) return false
            val ctx = c.applicationContext ?: c
            if (!envOk(ctx)) return false
            if (item.silent) return true
            app = ctx
            runMain {
                nq.add(QItem(item, sound, dnd))
                if (notif == null) nextNotif()
            }
            true
        } catch (e: Throwable) {
            false
        }
    }

    fun dismissAll(c: Context) {
        runMain {
            main.removeCallbacks(notifTimeoutRun)
            main.removeCallbacks(autoCollapseRun)
            nq.clear()
            if (notif != null) {
                notif = null
                bigHasReply = false
                setFocusable(false)
            }
            mode = M_COMPACT
            expandedKey = null
            primaryKey = null
            refresh()
        }
    }

    fun demo(c: Context, kind: Int) {
        val ctx = c.applicationContext ?: c
        app = ctx
        if (!canOverlay(ctx)) return
        val now = System.currentTimeMillis()
        val until = now + 30000L
        val pkg = ctx.packageName
        val la: LiveActivity = when (kind) {
            0 -> LiveActivity(
                key = "n27i-demo-media", pkg = pkg, kind = IslandKind.MEDIA,
                title = "Bài hát thử", subtitle = "Nghệ sĩ thử",
                priority = IslandKind.priority(IslandKind.MEDIA), ephemeralUntil = until, appName = "notifyIOS27"
            )
            1 -> LiveActivity(
                key = "n27i-demo-call", pkg = pkg, kind = IslandKind.CALL,
                title = "Nguyễn Văn A", subtitle = "Cuộc gọi đến · Di động", chronoBase = now,
                localActions = listOf<Pair<String, () -> Unit>>(
                    Pair("Từ chối", { removeLocal("n27i-demo-call") }),
                    Pair("Trả lời", { removeLocal("n27i-demo-call") })
                ),
                priority = IslandKind.priority(IslandKind.CALL), ephemeralUntil = until, appName = "notifyIOS27"
            )
            2 -> LiveActivity(
                key = "n27i-demo-timer", pkg = pkg, kind = IslandKind.TIMER,
                title = "Hẹn giờ", subtitle = "", chronoBase = now + 300000L, chronoDown = true,
                localActions = listOf<Pair<String, () -> Unit>>(
                    Pair("Hủy", { removeLocal("n27i-demo-timer") })
                ),
                priority = IslandKind.priority(IslandKind.TIMER), ephemeralUntil = until, appName = "notifyIOS27"
            )
            3 -> LiveActivity(
                key = "n27i-demo-progress", pkg = pkg, kind = IslandKind.PROGRESS,
                title = "Đang tải xuống", subtitle = "tep_thu.zip", progress = 62, progressMax = 100,
                priority = IslandKind.priority(IslandKind.PROGRESS), ephemeralUntil = until, appName = "notifyIOS27"
            )
            4 -> IslandSources.makeCharge(ctx, false)
            5 -> IslandSources.makeRinger(ctx)
            else -> LiveActivity(
                key = "n27i-demo-nav", pkg = pkg, kind = IslandKind.NAV,
                title = "Rẽ phải sau 200 m", subtitle = "Đường Nguyễn Huệ",
                priority = IslandKind.priority(IslandKind.NAV), ephemeralUntil = until, appName = "notifyIOS27"
            )
        }
        putLocal(la)
    }

    fun openTools(c: Context) {
        val ctx = c.applicationContext ?: c
        app = ctx
        runMain {
            if (!envOk(ctx)) return@runMain
            if (!ensureAttached(ctx)) return@runMain
            val dim = Dim(ctx)
            val nc = IslandTools.buildPanel(ctx, dim, expWidth(dim)) ?: return@runMain
            main.removeCallbacks(notifTimeoutRun)
            mode = M_TOOLS
            expandedKey = null
            primaryKey = null
            secondKey = null
            transition(ctx, nc, null, true, true)
            haptic(ctx)
            armTimers()
        }
    }

    /** Re-applies position and size after the settings page changed them. */
    fun relayout() {
        runMain {
            if (mode == M_COMPACT) {
                primaryKey = null
                refresh()
            }
        }
    }

    fun onTimerFire(c: Context) {
        val ctx = c.applicationContext ?: c
        app = ctx
        try { IslandTools.onTimerFire(ctx) } catch (e: Throwable) { }
    }

    // ================= internal API (used by IslandView / IslandTools / IslandSystem) =================

    internal fun recentlyStarted(): Boolean = SystemClock.elapsedRealtime() - startAt < 1500L

    internal fun putLocal(la: LiveActivity) {
        runMain {
            val ctx = app ?: return@runMain
            val isNew = !acts.containsKey(la.key)
            acts[la.key] = la
            hidden.remove(la.key)
            scheduleExpiry()
            refresh()
            if (isNew && envOk(ctx)) haptic(ctx)
        }
    }

    internal fun removeLocal(key: String) {
        runMain {
            hidden.remove(key)
            if (acts.remove(key) != null) {
                scheduleExpiry()
                refresh()
            }
        }
    }

    internal fun expandKey(key: String) {
        runMain { expand(key) }
    }

    internal fun closePanel() {
        runMain {
            if (mode == M_TOOLS || mode == M_EXPANDED) collapse()
        }
    }

    internal fun dismissNotif() {
        runMain {
            if (notif == null) return@runMain
            main.removeCallbacks(notifTimeoutRun)
            setFocusable(false)
            notif = null
            bigHasReply = false
            nextNotif()
        }
    }

    internal fun runAction(a: LiveActivity, act: NotifAction, reply: String?) {
        try {
            val ctx = app ?: return
            ItemActions.runAction(ctx, a.toItem(), act, reply)
        } catch (e: Throwable) {
        }
    }

    internal fun openSource(a: LiveActivity) {
        runAction(a, NotifAction("open", a.intent), null)
    }

    internal fun mediaCommand(a: LiveActivity, cmd: Int) {
        val mc = IslandSources.controller(a.key)
        if (mc != null) {
            try {
                val tc = mc.transportControls
                when (cmd) {
                    0 -> tc.skipToPrevious()
                    1 -> if (a.playing) tc.pause() else tc.play()
                    else -> tc.skipToNext()
                }
                return
            } catch (e: Throwable) {
            }
        }
        val list = a.actions
        val idx = when (cmd) {
            0 -> if (list.size >= 3) 0 else -1
            1 -> if (list.size >= 3) 1 else 0
            else -> if (list.size >= 3) 2 else 1
        }
        if (idx in list.indices) runAction(a, list[idx], null)
    }

    internal fun seekTo(key: String, f: Float) {
        try {
            val pd = IslandSources.position(key) ?: return
            if (pd[2] != 1L || pd[1] <= 0L) return
            IslandSources.controller(key)?.transportControls?.seekTo((pd[1] * f).toLong())
        } catch (e: Throwable) {
        }
    }

    @Suppress("DEPRECATION")
    internal fun haptic(c: Context) {
        if (!Prefs.haptic) return
        if (notif != null && !Dnd.effectiveHaptic(c, true, curBlocked)) return
        try {
            val vib = c.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
            if (vib != null && vib.hasVibrator()) {
                val effect = if (Build.VERSION.SDK_INT >= 29) {
                    VibrationEffect.createPredefined(VibrationEffect.EFFECT_CLICK)
                } else {
                    VibrationEffect.createOneShot(15L, VibrationEffect.DEFAULT_AMPLITUDE)
                }
                vib.vibrate(effect)
            }
        } catch (e: Throwable) {
        }
    }

    // ================= plumbing =================

    private fun runMain(block: () -> Unit) {
        if (Looper.myLooper() == Looper.getMainLooper()) {
            try { block() } catch (e: Throwable) { }
        } else {
            main.post {
                try { block() } catch (e: Throwable) { }
            }
        }
    }

    private val drainRun = object : Runnable {
        override fun run() {
            drainQueued.set(false)
            try {
                val ctx = app ?: return
                var changed = false
                for (k in ArrayList(pending.keys)) {
                    val p = pending.remove(k) ?: continue
                    upsertPost(ctx, p)
                    changed = true
                }
                if (changed) {
                    scheduleExpiry()
                    refresh()
                }
            } catch (e: Throwable) {
            }
        }
    }

    private fun upsertPost(ctx: Context, p: Post) {
        val old = acts[p.item.key]
        var la = IslandSources.fromItem(p.item, p.kind, old)
        val token = p.item.mediaToken
        if (p.kind == IslandKind.MEDIA && token != null) {
            IslandSources.ensureController(ctx, la.key, token) { k -> onMediaChanged(k) }
        }
        if (p.kind == IslandKind.MEDIA) la = IslandSources.applyMedia(la)
        acts[la.key] = la
        if (old == null && envOk(ctx)) haptic(ctx)
    }

    private fun onMediaChanged(key: String) {
        val la = acts[key] ?: return
        acts[key] = IslandSources.applyMedia(la)
        scheduleExpiry()
        refresh()
    }

    private val screenReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            try {
                when (intent?.action) {
                    Intent.ACTION_SCREEN_OFF -> removeNow()
                    Intent.ACTION_CONFIGURATION_CHANGED -> {
                        cutoutRead = false
                        haveCut = false
                        removeNow()
                        refresh()
                    }
                    else -> refresh()
                }
            } catch (e: Throwable) {
            }
        }
    }

    private fun canOverlay(c: Context): Boolean =
        try { Settings.canDrawOverlays(c) } catch (e: Throwable) { false }

    private fun envOk(c: Context): Boolean {
        return try {
            if (!Prefs.islandEnabled || !canOverlay(c)) return false
            val pm = c.getSystemService(Context.POWER_SERVICE) as PowerManager
            if (!pm.isInteractive) return false
            val km = c.getSystemService(Context.KEYGUARD_SERVICE) as KeyguardManager
            if (km.isKeyguardLocked) return false
            val land = c.resources.configuration.orientation == Configuration.ORIENTATION_LANDSCAPE
            !(land && Prefs.islandHideLandscape)
        } catch (e: Throwable) {
            false
        }
    }

    // ================= state =================

    private fun refresh() {
        val ctx = app ?: return
        if (!envOk(ctx)) {
            removeNow()
            return
        }
        when (mode) {
            M_EXPANDED -> {
                val a = acts[expandedKey ?: ""]
                if (a == null || hidden.contains(a.key)) {
                    collapse()
                } else {
                    val cc = content
                    if (cc is ExpandedContent && cc.sameShape(a)) cc.update(a)
                    else if (cc is ExpandedContent) expand(a.key)
                }
            }
            M_NOTIF, M_NOTIF_BIG, M_TOOLS -> {
            }
            else -> compactRefresh()
        }
    }

    private fun isHiddenNow(a: LiveActivity, now: Long): Boolean {
        if (hidden.contains(a.key)) return true
        if (a.ephemeralUntil > 0L && now > a.ephemeralUntil && a.key != expandedKey) return true
        if (a.kind == IslandKind.MEDIA && !a.playing && a.pausedAt > 0L) {
            val keep = Prefs.islandMediaKeepSec
            if (keep > 0 && now - a.pausedAt > keep * 1000L) return true
        }
        return false
    }

    private fun visible(now: Long): List<LiveActivity> {
        val out = ArrayList<LiveActivity>()
        for (a in acts.values) if (!isHiddenNow(a, now)) out.add(a)
        out.sortByDescending { it.priority }
        return out
    }

    private fun compactRefresh() {
        val ctx = app ?: return
        val vis = visible(System.currentTimeMillis())
        if (vis.isEmpty()) {
            if (Prefs.islandAlwaysOn) showIdle(ctx) else if (view != null) exitAnimated()
            return
        }
        val first = vis[0]
        val second = if (vis.size > 1) vis[1] else null
        val pk = first.key + "|" + (second?.key ?: "")
        if (pk != lastPairKeys) {
            swapped = false
            lastPairKeys = pk
        }
        val primary = if (swapped && second != null) second else first
        val other = if (swapped && second != null) first else second
        val cc = content
        if (cc is CompactContent && !cc.idle && !exiting && primaryKey == primary.key &&
            secondKey == other?.key && cc.kind == primary.kind
        ) {
            cc.update(primary)
            return
        }
        if (!ensureAttached(ctx)) return
        val wasCompact = content == null || content is CompactContent
        primaryKey = primary.key
        secondKey = other?.key
        val dim = Dim(ctx)
        screenW = dim.screenW
        val nc = CompactContent(ctx, dim, primary, gapPx(dim), false)
        transition(ctx, nc, other, false, !wasCompact)
    }

    private fun showIdle(ctx: Context) {
        val cc = content
        if (cc is CompactContent && cc.idle && !exiting && primaryKey == "idle") return
        if (!ensureAttached(ctx)) return
        val wasCompact = content == null || content is CompactContent
        primaryKey = "idle"
        secondKey = null
        val dim = Dim(ctx)
        screenW = dim.screenW
        val dummy = LiveActivity(key = "idle", pkg = ctx.packageName, kind = IslandKind.OTHER, title = "", subtitle = "")
        transition(ctx, CompactContent(ctx, dim, dummy, gapPx(dim), true), null, false, !wasCompact)
    }

    private fun isLand(dim: Dim): Boolean = dim.screenW > dim.screenH

    // Landscape, or "below camera": pill under the status bar, centred, no camera gap.
    private fun below(dim: Dim): Boolean = isLand(dim) || Prefs.islandBelowCamera

    private fun expWidth(dim: Dim): Int {
        val w = ((dim.screenW - dim.px(24f)) * minOf(1f, dim.s)).toInt()
        return if (isLand(dim)) minOf(w, dim.px(420f)) else w
    }

    private fun expand(key: String) {
        val ctx = app ?: return
        val a = acts[key] ?: return
        if (!envOk(ctx) || !ensureAttached(ctx)) return
        main.removeCallbacks(notifTimeoutRun)
        mode = M_EXPANDED
        expandedKey = key
        primaryKey = null
        secondKey = null
        val dim = Dim(ctx)
        transition(ctx, ExpandedContent(ctx, dim, a, expWidth(dim)), null, true, true)
        haptic(ctx)
        armTimers()
    }

    private fun collapse() {
        main.removeCallbacks(autoCollapseRun)
        setFocusable(false)
        val k = expandedKey
        expandedKey = null
        if (k != null) {
            val a = acts[k]
            if (a != null && a.ephemeralUntil > 0L) acts.remove(k)
        }
        mode = M_COMPACT
        primaryKey = null
        scheduleExpiry()
        refresh()
    }

    private fun nextNotif() {
        val ctx = app ?: return
        if (nq.isEmpty()) {
            notif = null
            mode = M_COMPACT
            expandedKey = null
            primaryKey = null
            secondKey = null
            setFocusable(false)
            refresh()
            return
        }
        val q = nq.removeAt(0)
        if (!envOk(ctx) || !ensureAttached(ctx)) {
            nq.clear()
            notif = null
            return
        }
        notif = q.item
        curBlocked = q.blocked
        mode = M_NOTIF
        expandedKey = null
        bigHasReply = false
        primaryKey = null
        secondKey = null
        val dim = Dim(ctx)
        transition(ctx, NotifContent(ctx, dim, q.item, false, expWidth(dim)), null, true, true)
        if (q.sound) feedback(ctx, Dnd.effectiveSound(ctx, true, q.blocked))
        armTimers()
    }

    private fun bigNotif() {
        val ctx = app ?: return
        val n = notif ?: return
        if (mode != M_NOTIF) return
        val dim = Dim(ctx)
        val nc = NotifContent(ctx, dim, n, true, expWidth(dim))
        mode = M_NOTIF_BIG
        bigHasReply = nc.hasReply
        setFocusable(nc.hasReply)
        transition(ctx, nc, null, true, true)
        armTimers()
    }

    private val notifTimeoutRun = Runnable { dismissNotif() }
    private val autoCollapseRun = Runnable { runMain { collapse() } }

    private fun armTimers() {
        main.removeCallbacks(notifTimeoutRun)
        main.removeCallbacks(autoCollapseRun)
        if (touching) return
        when (mode) {
            M_NOTIF -> main.postDelayed(notifTimeoutRun, Prefs.bannerSeconds * 1000L)
            M_NOTIF_BIG -> if (!bigHasReply) main.postDelayed(notifTimeoutRun, 8000L)
            M_EXPANDED -> {
                val a = acts[expandedKey ?: ""]
                if (a != null && !a.sticky && a.kind != IslandKind.CALL) main.postDelayed(autoCollapseRun, 8000L)
            }
            M_TOOLS -> main.postDelayed(autoCollapseRun, 8000L)
        }
    }

    private val expiryRun = Runnable {
        try {
            val now = System.currentTimeMillis()
            val iter = acts.entries.iterator()
            while (iter.hasNext()) {
                val a = iter.next().value
                if (a.ephemeralUntil > 0L && now > a.ephemeralUntil && a.key != expandedKey) iter.remove()
            }
            refresh()
            scheduleExpiry()
        } catch (e: Throwable) {
        }
    }

    private fun scheduleExpiry() {
        main.removeCallbacks(expiryRun)
        val now = System.currentTimeMillis()
        var next = Long.MAX_VALUE
        val keep = Prefs.islandMediaKeepSec
        for (a in acts.values) {
            if (a.ephemeralUntil > 0L && a.key != expandedKey) next = minOf(next, a.ephemeralUntil)
            if (a.kind == IslandKind.MEDIA && !a.playing && a.pausedAt > 0L && keep > 0) {
                val d = a.pausedAt + keep * 1000L
                if (d > now) next = minOf(next, d)
            }
        }
        if (next != Long.MAX_VALUE) main.postDelayed(expiryRun, maxOf(50L, next - now + 30L))
    }

    private val tickRun = object : Runnable {
        override fun run() {
            try { content?.tick() } catch (e: Throwable) { }
            if (view != null) main.postDelayed(this, 1000L)
        }
    }

    // ================= touch =================

    private val touchListener = object : PillListener {
        override fun onTap() {
            val ctx = app ?: return
            when (mode) {
                M_COMPACT -> {
                    val a = acts[primaryKey ?: ""] ?: return
                    if (a.kind == IslandKind.CHARGE || a.kind == IslandKind.RINGER || a.kind == IslandKind.HEADSET) {
                        expand(a.key)
                    } else {
                        openSource(a)
                    }
                }
                M_EXPANDED -> {
                    val a = acts[expandedKey ?: ""]
                    if (a != null) openSource(a)
                    collapse()
                }
                M_NOTIF, M_NOTIF_BIG -> {
                    val n = notif
                    if (n != null) {
                        try { NotifStore.open(ctx, n) } catch (e: Throwable) { }
                        dismissNotif()
                    }
                }
            }
        }

        override fun onLong() {
            val ctx = app ?: return
            when (mode) {
                M_COMPACT -> {
                    val k = primaryKey ?: return
                    if (k == "idle") openTools(ctx) else expand(k)
                }
                M_NOTIF -> bigNotif()
            }
        }

        override fun onSwipeUp() {
            when (mode) {
                M_EXPANDED, M_TOOLS -> collapse()
                M_NOTIF, M_NOTIF_BIG -> dismissNotif()
            }
        }

        override fun onSwipeDown() {
            if (mode == M_NOTIF) bigNotif()
        }

        override fun onSwipeH() {
            if (mode != M_COMPACT) return
            val k = primaryKey ?: return
            if (k == "idle") return
            hidden.add(k)
            swapped = false
            primaryKey = null
            refresh()
        }

        override fun onTouch(down: Boolean) {
            touching = down
            if (down) {
                main.removeCallbacks(notifTimeoutRun)
                main.removeCallbacks(autoCollapseRun)
            } else {
                armTimers()
            }
        }
    }

    private fun onOutside() {
        when (mode) {
            M_EXPANDED, M_TOOLS -> collapse()
            M_NOTIF_BIG -> if (!bigHasReply) dismissNotif()
        }
    }

    // ================= window =================

    private fun gapPx(dim: Dim): Int =
        if (below(dim)) 0 else if (haveCut) cutW + dim.px(12f) else dim.px(28f)

    private fun centerX(dim: Dim): Float = if (haveCut && !below(dim)) cutCx else dim.screenW / 2f

    private fun topY(dim: Dim): Int {
        if (isLand(dim)) return UiKit.safeInsets(dim.c)[1] + dim.px(6f)
        if (Prefs.islandBelowCamera) {
            return UiKit.safeInsets(dim.c)[1] + dim.px(6f + Prefs.islandOffsetY.toFloat())
        }
        val cy = if (haveCut) cutCy else dim.px(20f).toFloat()
        return maxOf(0, (cy - dim.dp(36f) / 2f + dim.px(Prefs.islandOffsetY.toFloat())).toInt())
    }

    private fun clampCenter(tw: Float, expandedShape: Boolean, dim: Dim): Float {
        val c = centerX(dim)
        val m = if (expandedShape) dim.px(12f) else dim.px(4f)
        val lo = tw / 2f + m
        val hi = dim.screenW - tw / 2f - m
        return if (lo <= hi) c.coerceIn(lo, hi) else dim.screenW / 2f
    }

    private fun ensureAttached(ctx: Context): Boolean {
        if (view != null) return true
        try {
            val w = ctx.getSystemService(Context.WINDOW_SERVICE) as WindowManager
            val v = IslandView(ctx)
            v.pill.listener = touchListener
            v.onOutside = { onOutside() }
            v.circle.setOnClickListener {
                swapped = !swapped
                primaryKey = null
                refresh()
            }
            val flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or
                WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH
            val p = WindowManager.LayoutParams(
                1, 1, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY, flags, PixelFormat.TRANSLUCENT
            )
            p.gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
            if (Build.VERSION.SDK_INT >= 28) {
                p.layoutInDisplayCutoutMode = if (Build.VERSION.SDK_INT >= 30) {
                    WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS
                } else {
                    WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
                }
            }
            if (Build.VERSION.SDK_INT >= 30) {
                p.fitInsetsTypes = 0
            }
            w.addView(v, p)
            wm = w
            lp = p
            view = v
            winL = 0
            winW = 1
            winH = 1
            curW = 0f
            curH = 0f
            main.removeCallbacks(tickRun)
            main.postDelayed(tickRun, 1000L)
            v.post { readCutout() }
            return true
        } catch (e: Throwable) {
            view = null
            lp = null
            return false
        }
    }

    // Fallback: the window-metrics cutout is available even when the overlay view reports none.
    private fun metricsCutout(): android.view.DisplayCutout? {
        return try {
            if (Build.VERSION.SDK_INT >= 30) {
                wm?.currentWindowMetrics?.windowInsets?.displayCutout
            } else {
                null
            }
        } catch (e: Throwable) {
            null
        }
    }

    private fun readCutout() {
        if (cutoutRead) return
        val v = view ?: return
        var changed = false
        try {
            if (Build.VERSION.SDK_INT >= 28) {
                val ins = v.rootWindowInsets
                if (ins != null) {
                    cutoutRead = true
                    val cut = ins.displayCutout ?: metricsCutout()
                    if (cut != null) {
                        var r: Rect? = null
                        if (Build.VERSION.SDK_INT >= 29) r = cut.boundingRectTop
                        if (r == null || r.isEmpty) {
                            r = cut.boundingRects.firstOrNull { it.top <= 0 && !it.isEmpty }
                        }
                        if (r != null && !r.isEmpty) {
                            haveCut = true
                            cutW = r.width()
                            cutCx = r.exactCenterX()
                            cutCy = r.exactCenterY()
                            changed = true
                        }
                    }
                }
            } else {
                cutoutRead = true
            }
        } catch (e: Throwable) {
            cutoutRead = true
        }
        if (changed && mode == M_COMPACT) {
            primaryKey = null
            refresh()
        }
    }

    private fun setWindow(l: Int, w: Int, h: Int) {
        val v = view ?: return
        val p = lp ?: return
        winL = l
        winW = w
        winH = h
        p.width = w
        p.height = h
        p.x = l + w / 2 - screenW / 2
        p.y = topYpx
        try { wm?.updateViewLayout(v, p) } catch (e: Throwable) { }
        applyGeom()
    }

    private fun setPillGeom(w: Float, h: Float, cen: Float, r: Float) {
        curW = w
        curH = h
        curC = cen
        curR = r
        applyGeom()
    }

    private fun applyGeom() {
        val v = view ?: return
        val p = v.pill.layoutParams as FrameLayout.LayoutParams
        p.width = maxOf(1, curW.toInt())
        p.height = maxOf(1, curH.toInt())
        p.leftMargin = (curC - curW / 2f - winL).toInt()
        v.pill.radius = minOf(curR, curH / 2f)
        v.pill.requestLayout()
        if (v.circle.visibility == View.VISIBLE) {
            val c = v.circle.layoutParams as FrameLayout.LayoutParams
            c.leftMargin = (curC + curW / 2f + circleGap - winL).toInt()
            v.circle.requestLayout()
        }
    }

    private fun applyFrame(f: Float) {
        setPillGeom(
            maxOf(1f, fW + (tW - fW) * f), maxOf(1f, fH + (tH - fH) * f),
            fC + (tC - fC) * f, maxOf(0f, fR + (tR - fR) * f)
        )
    }

    private val frameListener = ValueAnimator.AnimatorUpdateListener { a -> applyFrame(a.animatedFraction) }

    private val animListener = object : AnimatorListenerAdapter() {
        override fun onAnimationCancel(animation: Animator) {
            animCancelled = true
        }

        override fun onAnimationEnd(animation: Animator) {
            if (animCancelled) {
                animCancelled = false
                return
            }
            anim = null
            setPillGeom(tW, tH, tC, tR)
            setWindow(tLeftI, tRightI - tLeftI, tHeightI)
        }
    }

    private fun transition(ctx: Context, nc: IslandContent, pair: LiveActivity?, expandedShape: Boolean, morph: Boolean) {
        val v = view ?: return
        cancelExit()
        val dim = nc.dim
        screenW = dim.screenW
        topYpx = topY(dim)
        circleGap = dim.dp(8f)
        val first = content == null
        val pill = v.pill
        val stale = fadingOld
        if (stale != null) {
            stale.animate().cancel()
            try { pill.removeView(stale) } catch (e: Throwable) { }
            fadingOld = null
        }
        val old = content
        try { old?.release() } catch (e: Throwable) { }

        val tw = nc.w.toFloat()
        val th = nc.h.toFloat()
        val tr = if (expandedShape) minOf(dim.dp(32f).toFloat(), th / 2f) else th / 2f
        val tc = clampCenter(tw, expandedShape, dim)
        val circleSize = dim.dp(36f)
        val extra = if (pair != null) (circleGap + circleSize).toFloat() else 0f
        val tLi = Math.floor((tc - tw / 2f).toDouble()).toInt()
        val tRi = Math.ceil((tc + tw / 2f + extra).toDouble()).toInt()
        val pad = if (!first && morph && !Prefs.reduceMotion) dim.px(14f) else 0
        val wl = (if (first) tLi else minOf(winL, tLi)) - pad
        val wr = (if (first) tRi else maxOf(winL + winW, tRi)) + pad
        val wh = (if (first) th.toInt() else maxOf(winH, th.toInt())) + pad
        tW = tw
        tH = th
        tC = tc
        tR = tr
        tLeftI = tLi
        tRightI = tRi
        tHeightI = th.toInt()
        anim?.cancel()
        anim = null

        // circle of the split island
        val circ = v.circle
        if (pair != null) {
            circ.bind(pair, circleSize)
            val cl = circ.layoutParams as FrameLayout.LayoutParams
            cl.width = circleSize
            cl.height = circleSize
            cl.topMargin = 0
            if (circ.visibility != View.VISIBLE) {
                circ.alpha = 0f
                circ.visibility = View.VISIBLE
                circ.animate().alpha(1f).setDuration(160L).start()
            }
        } else if (circ.visibility == View.VISIBLE) {
            circ.animate().cancel()
            circ.alpha = 1f
            circ.visibility = View.GONE
        }

        if (first) {
            curW = tw
            curH = th
            curC = tc
            curR = tr
        }
        fW = curW
        fH = curH
        fC = curC
        fR = curR

        // window first (final size), then content
        setWindow(wl, wr - wl, wh)

        val nv = nc.root
        pill.addView(nv, FrameLayout.LayoutParams(nc.w, nc.h, Gravity.CENTER))
        content = nc
        if (old != null) {
            val ov = old.root
            fadingOld = ov
            ov.animate().setStartDelay(0L).alpha(0f).setDuration(120L).withEndAction {
                if (fadingOld === ov) fadingOld = null
                try { pill.removeView(ov) } catch (e: Throwable) { }
            }.start()
        }
        if (first) {
            nv.alpha = 1f
            pill.alpha = 0f
            pill.scaleX = 0.6f
            pill.animate().alpha(1f).scaleX(1f).setStartDelay(0L).setDuration(220L).start()
            setPillGeom(tw, th, tc, tr)
            haptic(ctx)
        } else {
            nv.alpha = 0f
            nv.animate().setStartDelay(140L).alpha(1f).setDuration(160L).start()
            val reduce = Prefs.reduceMotion
            val va = ValueAnimator.ofFloat(0f, 1f)
            va.duration = if (morph && !reduce) 380L else 160L
            va.interpolator = if (morph && !reduce) OvershootInterpolator(0.8f) else DecelerateInterpolator()
            va.addUpdateListener(frameListener)
            va.addListener(animListener)
            anim = va
            va.start()
        }
        if (!cutoutRead) v.post { readCutout() }
    }

    private fun exitAnimated() {
        val v = view ?: return
        if (exiting) return
        exiting = true
        anim?.cancel()
        anim = null
        v.circle.visibility = View.GONE
        v.pill.animate().alpha(0f).scaleX(0.6f).setStartDelay(0L).setDuration(180L).withEndAction {
            if (exiting) removeNow()
        }.start()
    }

    private fun cancelExit() {
        if (!exiting) return
        exiting = false
        val v = view ?: return
        v.pill.animate().cancel()
        v.pill.alpha = 1f
        v.pill.scaleX = 1f
    }

    private fun setFocusable(on: Boolean) {
        val p = lp ?: return
        val v = view ?: return
        val has = (p.flags and WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE) == 0
        if (has == on) return
        p.flags = if (on) {
            p.flags and WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE.inv()
        } else {
            p.flags or WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
        }
        p.softInputMode = if (on) {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE
        } else {
            WindowManager.LayoutParams.SOFT_INPUT_ADJUST_UNSPECIFIED
        }
        try { wm?.updateViewLayout(v, p) } catch (e: Throwable) { }
    }

    private fun removeNow() {
        exiting = false
        anim?.cancel()
        anim = null
        animCancelled = false
        main.removeCallbacks(tickRun)
        main.removeCallbacks(notifTimeoutRun)
        main.removeCallbacks(autoCollapseRun)
        try { content?.release() } catch (e: Throwable) { }
        val v = view
        if (v != null) {
            try { v.pill.animate().cancel() } catch (e: Throwable) { }
            try {
                wm?.removeViewImmediate(v)
            } catch (e: Throwable) {
                try { wm?.removeView(v) } catch (e2: Throwable) { }
            }
        }
        view = null
        lp = null
        content = null
        fadingOld = null
        primaryKey = null
        secondKey = null
        mode = M_COMPACT
        expandedKey = null
        notif = null
        nq.clear()
        touching = false
        bigHasReply = false
    }

    // ================= sound =================

    private fun feedback(c: Context, playSound: Boolean = true) {
        try {
            val s = Prefs.soundUri
            if (playSound && s != "none") {
                val uri: Uri? = if (s.isEmpty()) {
                    RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)
                } else {
                    Uri.parse(s)
                }
                if (uri != null) {
                    try { ringtone?.stop() } catch (e: Throwable) { }
                    val r = RingtoneManager.getRingtone(c, uri)
                    if (r != null) {
                        try {
                            r.setAudioAttributes(
                                AudioAttributes.Builder()
                                    .setUsage(AudioAttributes.USAGE_NOTIFICATION)
                                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                                    .build()
                            )
                        } catch (e: Throwable) {
                        }
                        ringtone = r
                        r.play()
                    }
                }
            }
        } catch (e: Throwable) {
        }
        haptic(c)
    }
}

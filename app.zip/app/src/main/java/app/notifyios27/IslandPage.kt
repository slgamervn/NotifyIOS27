package app.notifyios27

import android.app.Activity
import android.graphics.Typeface
import android.provider.Settings
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class IslandPage : SettingsPage {
    override val title: String = "Dynamic Island"

    override fun build(a: Activity, push: (SettingsPage) -> Unit): View {
        val body = LinearLayout(a)
        body.orientation = LinearLayout.VERTICAL
        fill(a, body)
        return body
    }

    private fun gap(a: Activity, body: LinearLayout) {
        body.addView(SettingsKit.spacer(a, 12))
    }

    private fun fill(a: Activity, body: LinearLayout) {
        body.removeAllViews()
        val dark = Prefs.isDark(a)

        val s1 = SettingsKit.section(a, null)
        s1.addView(SettingsKit.switchRow(a, "Bật Dynamic Island", null, Prefs.islandEnabled) {
            Prefs.islandEnabled = it
            Island.relayout()
        })
        s1.addView(SettingsKit.switchRow(a, "Luôn hiện đảo", "Hiện đảo trống khi không có hoạt động nào", Prefs.islandAlwaysOn) {
            Prefs.islandAlwaysOn = it
            Island.relayout()
        })
        s1.addView(SettingsKit.switchRow(a, "Đặt dưới camera", "Đảo nằm dưới thanh trạng thái để vẫn bấm được thanh trên", Prefs.islandBelowCamera) {
            Prefs.islandBelowCamera = it
            Island.relayout()
        })
        s1.addView(SettingsKit.switchRow(a, "Ẩn khi xoay ngang", null, Prefs.islandHideLandscape) {
            Prefs.islandHideLandscape = it
        })
        body.addView(s1)
        gap(a, body)

        val s2 = SettingsKit.section(a, "Căn chỉnh")
        s2.addView(SettingsKit.sliderRow(
            a, "Vị trí dọc", -20f, 60f, Prefs.islandOffsetY.toFloat(), { v -> "${v.toInt()} dp" }
        ) { v ->
            Prefs.islandOffsetY = v.toInt()
            Island.relayout()
        })
        s2.addView(SettingsKit.sliderRow(
            a, "Kích thước", 0.7f, 1.6f, Prefs.islandScale, { v -> "${(v * 100f).toInt()}%" }
        ) { v ->
            Prefs.islandScale = v
            Island.relayout()
        })
        s2.addView(SettingsKit.buttonRow(a, "Đặt lại căn chỉnh", null) {
            Prefs.islandOffsetY = 6
            Prefs.islandScale = 1.0f
            Island.relayout()
            Toast.makeText(a, "Đã đặt lại căn chỉnh", Toast.LENGTH_SHORT).show()
            fill(a, body)
        })
        body.addView(s2)
        gap(a, body)

        val s3 = SettingsKit.section(a, "Nguồn hiển thị")
        val srcs = listOf(
            "Nhạc" to Island.SRC_MEDIA,
            "Cuộc gọi" to Island.SRC_CALL,
            "Hẹn giờ và bấm giờ" to Island.SRC_TIMER,
            "Tiến trình tải" to Island.SRC_PROGRESS,
            "Dẫn đường" to Island.SRC_NAV,
            "Sạc pin" to Island.SRC_CHARGE,
            "Chế độ chuông" to Island.SRC_RINGER,
            "Tai nghe" to Island.SRC_HEADSET,
            "Dịch vụ chạy nền khác" to Island.SRC_OTHER
        )
        for (p in srcs) {
            val bit = p.second
            s3.addView(SettingsKit.switchRow(a, p.first, null, (Prefs.islandSources and bit) != 0) { on ->
                Prefs.islandSources = if (on) (Prefs.islandSources or bit) else (Prefs.islandSources and bit.inv())
            })
        }
        body.addView(s3)
        gap(a, body)

        val s4 = SettingsKit.section(a, "Ẩn player tạm dừng sau")
        val keeps = intArrayOf(10, 30, 120, 0)
        var sel = keeps.indexOf(Prefs.islandMediaKeepSec)
        if (sel < 0) sel = 1
        s4.addView(SettingsKit.segmented(a, listOf("10 giây", "30 giây", "2 phút", "Không bao giờ"), sel) { i ->
            Prefs.islandMediaKeepSec = keeps[i.coerceIn(0, 3)]
        })
        body.addView(s4)
        gap(a, body)

        val sn = SettingsKit.section(a, "Đảo của hệ thống")
        val nat = Native.detect()
        if (nat != Native.NONE) {
            sn.addView(SettingsKit.textRow(a, "Máy có ${Native.name(nat)}",
                if (Native.systemDrawsLive()) "đang dùng của hệ thống" else "đang dùng đảo của app"))
        }
        sn.addView(SettingsKit.segmented(a, listOf("Tự động", "Đảo của app", "Của hệ thống"), Prefs.islandMode) {
            Prefs.islandMode = it
            Island.relayout()
        })
        sn.addView(settingsCaption(a, "Tự động: máy có đảo riêng thì để hệ thống vẽ nhạc, cuộc gọi, hẹn giờ; banner vẫn theo kiểu bạn chọn."))
        body.addView(sn)
        gap(a, body)

        val s5 = SettingsKit.section(a, null)
        s5.addView(SettingsKit.buttonRow(a, "Mở bảng tiện ích", "Đèn pin, hẹn giờ, bấm giờ") {
            if (!Settings.canDrawOverlays(a)) needOverlay(a) else Island.openTools(a)
        })
        body.addView(s5)
        gap(a, body)

        val s6 = SettingsKit.section(a, "Thử nghiệm")
        val demos = listOf("Nhạc", "Cuộc gọi", "Hẹn giờ", "Tải xuống", "Sạc pin", "Chế độ chuông", "Dẫn đường")
        for ((i, name) in demos.withIndex()) {
            s6.addView(SettingsKit.buttonRow(a, name, null) {
                if (!Settings.canDrawOverlays(a)) needOverlay(a) else Island.demo(a, i)
            })
        }
        body.addView(s6)

        val note = TextView(a)
        note.text = "Dynamic Island cần quyền “Hiển thị trên ứng dụng khác”. Một số máy cần chỉnh thanh " +
            "“Vị trí dọc” để đảo khớp với camera trước."
        note.textSize = 13f
        note.typeface = Typeface.DEFAULT
        note.setTextColor(UiKit.secondary(dark))
        note.setPadding(UiKit.dp(a, 8), UiKit.dp(a, 12), UiKit.dp(a, 8), UiKit.dp(a, 12))
        body.addView(note, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
    }

    private fun needOverlay(a: Activity) {
        Toast.makeText(a, "Cần cấp quyền Hiển thị trên ứng dụng khác", Toast.LENGTH_LONG).show()
        UiKit.openOverlay(a)
    }
}

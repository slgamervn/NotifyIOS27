package app.notifyios27

import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Bitmap
import android.graphics.drawable.Drawable
import android.media.AudioManager
import android.media.MediaMetadata
import android.media.session.MediaController
import android.media.session.MediaSession
import android.media.session.PlaybackState
import android.os.BatteryManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import java.util.Locale

internal object IslandKind {
    const val MEDIA = 0
    const val CALL = 1
    const val TIMER = 2
    const val PROGRESS = 3
    const val NAV = 4
    const val CHARGE = 5
    const val RINGER = 6
    const val HEADSET = 7
    const val OTHER = 8

    fun priority(kind: Int): Int = when (kind) {
        CALL -> 100
        TIMER -> 80
        NAV -> 70
        MEDIA -> 60
        PROGRESS -> 50
        CHARGE -> 40
        RINGER -> 30
        HEADSET -> 20
        else -> 10
    }
}

data class LiveActivity(
    val key: String,
    val pkg: String,
    val kind: Int,
    val title: String,
    val subtitle: String,
    val art: Bitmap? = null,
    val appIcon: Drawable? = null,
    val progress: Int = -1,
    val progressMax: Int = 0,
    val indeterminate: Boolean = false,
    val chronoBase: Long = 0L,
    val chronoDown: Boolean = false,
    val actions: List<NotifAction> = emptyList(),
    val localActions: List<Pair<String, () -> Unit>> = emptyList(),
    val intent: PendingIntent? = null,
    val priority: Int = 0,
    val ephemeralUntil: Long = 0L,
    val appName: String = "",
    val value: Int = 0,
    val extra: Int = 0,
    val warn: Boolean = false,
    val sticky: Boolean = false,
    val playing: Boolean = true,
    val pausedAt: Long = 0L,
    val frozenMs: Long = -1L
) {
    fun toItem(): NotifItem = NotifItem(
        key = key, pkg = pkg, appName = appName, title = title, text = subtitle,
        time = System.currentTimeMillis(), intent = intent, actions = actions
    )
}

internal object IslandFmt {
    fun time(a: LiveActivity, now: Long): String {
        var ms = if (a.frozenMs >= 0L) a.frozenMs else if (a.chronoDown) a.chronoBase - now else now - a.chronoBase
        if (ms < 0L) ms = 0L
        val secs = if (a.chronoDown && a.frozenMs < 0L) (ms + 999L) / 1000L else ms / 1000L
        val h = secs / 3600L
        val m = (secs % 3600L) / 60L
        val s = secs % 60L
        return if (h > 0L) String.format(Locale.ROOT, "%d:%02d:%02d", h, m, s)
        else String.format(Locale.ROOT, "%02d:%02d", m, s)
    }

    fun mmss(ms: Long): String {
        val t = (if (ms < 0L) 0L else ms) / 1000L
        val h = t / 3600L
        val m = (t % 3600L) / 60L
        val s = t % 60L
        return if (h > 0L) String.format(Locale.ROOT, "%d:%02d:%02d", h, m, s)
        else String.format(Locale.ROOT, "%d:%02d", m, s)
    }

    fun firstLine(s: String): String {
        val i = s.indexOf('\n')
        return (if (i >= 0) s.substring(0, i) else s).trim()
    }
}

internal object IslandSources {
    private val main = Handler(Looper.getMainLooper())
    private val controllers = HashMap<String, MediaController>()
    private val callbacks = HashMap<String, MediaController.Callback>()

    /** Kind of live activity for an item, or -1 when it is not live (section 10). */
    fun classify(i: NotifItem): Int {
        val cat = i.category
        return when {
            cat == "transport" || i.mediaToken != null -> IslandKind.MEDIA
            cat == "call" -> IslandKind.CALL
            i.chronoBase > 0L && (cat == "alarm" || cat == "stopwatch" || i.ongoing) -> IslandKind.TIMER
            (i.progressMax > 0 || i.indeterminate) && i.ongoing -> IslandKind.PROGRESS
            cat == "navigation" -> IslandKind.NAV
            i.ongoing -> IslandKind.OTHER
            else -> -1
        }
    }

    fun srcBit(kind: Int): Int = when (kind) {
        IslandKind.MEDIA -> Island.SRC_MEDIA
        IslandKind.CALL -> Island.SRC_CALL
        IslandKind.TIMER -> Island.SRC_TIMER
        IslandKind.PROGRESS -> Island.SRC_PROGRESS
        IslandKind.NAV -> Island.SRC_NAV
        IslandKind.CHARGE -> Island.SRC_CHARGE
        IslandKind.RINGER -> Island.SRC_RINGER
        IslandKind.HEADSET -> Island.SRC_HEADSET
        else -> Island.SRC_OTHER
    }

    fun fromItem(i: NotifItem, kind: Int, old: LiveActivity?): LiveActivity {
        var base = i.chronoBase
        if (kind == IslandKind.CALL && base <= 0L) base = old?.chronoBase ?: System.currentTimeMillis()
        return LiveActivity(
            key = i.key, pkg = i.pkg, kind = kind,
            title = if (i.title.isNotBlank()) i.title else i.appName,
            subtitle = i.text,
            art = i.largeIcon ?: old?.art,
            appIcon = null,
            progress = i.progress, progressMax = i.progressMax, indeterminate = i.indeterminate,
            chronoBase = base, chronoDown = i.chronoDown,
            actions = i.actions, intent = i.intent,
            priority = IslandKind.priority(kind), appName = i.appName,
            playing = old?.playing ?: true, pausedAt = old?.pausedAt ?: 0L
        )
    }

    // ---- media ----

    fun controller(key: String): MediaController? = controllers[key]

    fun ensureController(c: Context, key: String, token: MediaSession.Token, onChange: (String) -> Unit) {
        try {
            val cur = controllers[key]
            if (cur != null && cur.sessionToken == token) return
            detachMedia(key)
            val mc = MediaController(c, token)
            val cb = object : MediaController.Callback() {
                override fun onPlaybackStateChanged(state: PlaybackState?) { onChange(key) }
                override fun onMetadataChanged(metadata: MediaMetadata?) { onChange(key) }
                override fun onSessionDestroyed() { onChange(key) }
            }
            mc.registerCallback(cb, main)
            controllers[key] = mc
            callbacks[key] = cb
        } catch (e: Throwable) {
        }
    }

    fun detachMedia(key: String) {
        val mc = controllers.remove(key)
        val cb = callbacks.remove(key)
        if (mc != null && cb != null) {
            try { mc.unregisterCallback(cb) } catch (e: Throwable) { }
        }
    }

    fun detachAll() {
        for (k in ArrayList(controllers.keys)) detachMedia(k)
    }

    /** Overrides title, artist, art and play state from the controller when one is attached. */
    fun applyMedia(la: LiveActivity): LiveActivity {
        val mc = controllers[la.key] ?: return la
        try {
            val md = mc.metadata
            var title = la.title
            var sub = la.subtitle
            var art = la.art
            if (md != null) {
                val t = md.getString(MediaMetadata.METADATA_KEY_TITLE)
                if (!t.isNullOrBlank()) title = t
                val ar = md.getString(MediaMetadata.METADATA_KEY_ARTIST)
                    ?: md.getString(MediaMetadata.METADATA_KEY_ALBUM_ARTIST)
                if (!ar.isNullOrBlank()) sub = ar
                art = md.getBitmap(MediaMetadata.METADATA_KEY_ALBUM_ART)
                    ?: md.getBitmap(MediaMetadata.METADATA_KEY_ART)
                    ?: md.getBitmap(MediaMetadata.METADATA_KEY_DISPLAY_ICON)
                    ?: art
            }
            val st = mc.playbackState?.state
            val playing = st == null || st == PlaybackState.STATE_PLAYING ||
                st == PlaybackState.STATE_BUFFERING || st == PlaybackState.STATE_CONNECTING ||
                st == PlaybackState.STATE_FAST_FORWARDING || st == PlaybackState.STATE_REWINDING
            val pausedAt = if (playing) 0L else (if (la.pausedAt > 0L) la.pausedAt else System.currentTimeMillis())
            return la.copy(title = title, subtitle = sub, art = art, playing = playing, pausedAt = pausedAt)
        } catch (e: Throwable) {
            return la
        }
    }

    /** [position, duration, canSeek(1/0)] in ms, or null without a controller. */
    fun position(key: String): LongArray? {
        val mc = controllers[key] ?: return null
        return try {
            val st = mc.playbackState ?: return null
            var pos = st.position
            if (st.state == PlaybackState.STATE_PLAYING) {
                val dt = SystemClock.elapsedRealtime() - st.lastPositionUpdateTime
                pos += (dt * st.playbackSpeed).toLong()
            }
            val dur = mc.metadata?.getLong(MediaMetadata.METADATA_KEY_DURATION) ?: 0L
            if (dur > 0L && pos > dur) pos = dur
            if (pos < 0L) pos = 0L
            val seek = if ((st.actions and PlaybackState.ACTION_SEEK_TO) != 0L) 1L else 0L
            longArrayOf(pos, dur, seek)
        } catch (e: Throwable) {
            null
        }
    }

    // ---- system events (builders) ----

    fun batteryInfo(c: Context): IntArray {
        return try {
            val i = c.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
            val level = i?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
            val scale = i?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100
            val plug = i?.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0) ?: 0
            val pct = if (level >= 0 && scale > 0) (level * 100 / scale) else 0
            intArrayOf(pct, plug)
        } catch (e: Throwable) {
            intArrayOf(0, 0)
        }
    }

    fun plugName(p: Int): String = when (p) {
        BatteryManager.BATTERY_PLUGGED_AC -> "Sạc nhanh"
        BatteryManager.BATTERY_PLUGGED_WIRELESS -> "Sạc không dây"
        BatteryManager.BATTERY_PLUGGED_USB -> "USB"
        else -> "Đang sạc"
    }

    fun makeCharge(c: Context, warn: Boolean): LiveActivity {
        val info = batteryInfo(c)
        val pct = info[0]
        var sub = if (warn) "Pin còn $pct%" else plugName(info[1])
        if (!warn && Build.VERSION.SDK_INT >= 28) {
            try {
                val bm = c.getSystemService(Context.BATTERY_SERVICE) as BatteryManager
                val ms = bm.computeChargeTimeRemaining()
                if (ms > 0L) sub += " · còn khoảng " + maxOf(1L, ms / 60000L) + " phút"
            } catch (e: Throwable) {
            }
        }
        return LiveActivity(
            key = if (warn) "n27i-sys-low" else "n27i-sys-charge", pkg = c.packageName,
            kind = IslandKind.CHARGE, title = if (warn) "Pin yếu" else "Đang sạc", subtitle = sub,
            priority = IslandKind.priority(IslandKind.CHARGE),
            ephemeralUntil = System.currentTimeMillis() + (if (warn) 5000L else 3000L),
            appName = "notifyIOS27", value = pct, extra = info[1], warn = warn
        )
    }

    fun makeRinger(c: Context): LiveActivity {
        val mode = try {
            (c.getSystemService(Context.AUDIO_SERVICE) as AudioManager).ringerMode
        } catch (e: Throwable) {
            AudioManager.RINGER_MODE_NORMAL
        }
        val t = when (mode) {
            AudioManager.RINGER_MODE_VIBRATE -> "Rung"
            AudioManager.RINGER_MODE_SILENT -> "Im lặng"
            else -> "Chuông"
        }
        return LiveActivity(
            key = "n27i-sys-ringer", pkg = c.packageName, kind = IslandKind.RINGER, title = t, subtitle = "",
            priority = IslandKind.priority(IslandKind.RINGER),
            ephemeralUntil = System.currentTimeMillis() + 3000L, appName = "notifyIOS27", value = mode
        )
    }

    fun makeHeadset(c: Context, name: String): LiveActivity {
        val n = if (name.isBlank()) "tai nghe" else name
        return LiveActivity(
            key = "n27i-sys-headset", pkg = c.packageName, kind = IslandKind.HEADSET,
            title = "Đã kết nối $n", subtitle = "",
            priority = IslandKind.priority(IslandKind.HEADSET),
            ephemeralUntil = System.currentTimeMillis() + 3000L, appName = "notifyIOS27"
        )
    }
}

/** System events: charging, battery low, ringer mode, headphones. */
internal object IslandSystem {
    private val main = Handler(Looper.getMainLooper())
    private var registered = false

    private val receiver = object : android.content.BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            try {
                val c = context ?: return
                if (Island.recentlyStarted()) return
                val src = Prefs.islandSources
                when (intent?.action) {
                    Intent.ACTION_POWER_CONNECTED ->
                        if ((src and Island.SRC_CHARGE) != 0) Island.putLocal(IslandSources.makeCharge(c, false))
                    Intent.ACTION_POWER_DISCONNECTED -> Island.removeLocal("n27i-sys-charge")
                    Intent.ACTION_BATTERY_LOW ->
                        if ((src and Island.SRC_CHARGE) != 0) Island.putLocal(IslandSources.makeCharge(c, true))
                    AudioManager.RINGER_MODE_CHANGED_ACTION ->
                        if ((src and Island.SRC_RINGER) != 0) Island.putLocal(IslandSources.makeRinger(c))
                }
            } catch (e: Throwable) {
            }
        }
    }

    private fun isHeadset(t: Int): Boolean =
        t == android.media.AudioDeviceInfo.TYPE_WIRED_HEADSET ||
            t == android.media.AudioDeviceInfo.TYPE_WIRED_HEADPHONES ||
            t == android.media.AudioDeviceInfo.TYPE_USB_HEADSET ||
            t == android.media.AudioDeviceInfo.TYPE_BLUETOOTH_A2DP ||
            t == android.media.AudioDeviceInfo.TYPE_BLUETOOTH_SCO

    fun start(c: Context) {
        if (registered) return
        registered = true
        try {
            val f = IntentFilter()
            f.addAction(Intent.ACTION_POWER_CONNECTED)
            f.addAction(Intent.ACTION_POWER_DISCONNECTED)
            f.addAction(Intent.ACTION_BATTERY_LOW)
            f.addAction(AudioManager.RINGER_MODE_CHANGED_ACTION)
            if (Build.VERSION.SDK_INT >= 33) {
                c.registerReceiver(receiver, f, Context.RECEIVER_NOT_EXPORTED)
            } else {
                c.registerReceiver(receiver, f)
            }
        } catch (e: Throwable) {
        }
        try {
            val am = c.getSystemService(Context.AUDIO_SERVICE) as AudioManager
            val cb = object : android.media.AudioDeviceCallback() {
                override fun onAudioDevicesAdded(addedDevices: Array<out android.media.AudioDeviceInfo>?) {
                    try {
                        if (Island.recentlyStarted()) return
                        if ((Prefs.islandSources and Island.SRC_HEADSET) == 0) return
                        val list = addedDevices ?: return
                        for (d in list) {
                            if (!d.isSink || !isHeadset(d.type)) continue
                            var name = ""
                            try { name = d.productName?.toString() ?: "" } catch (e: Throwable) { }
                            Island.putLocal(IslandSources.makeHeadset(c, name))
                            break
                        }
                    } catch (e: Throwable) {
                    }
                }
            }
            am.registerAudioDeviceCallback(cb, main)
        } catch (e: Throwable) {
        }
    }
}

package app.notifyios27

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.hardware.camera2.CameraAccessException
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioAttributes
import android.media.Ringtone
import android.media.RingtoneManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.VibrationEffect
import android.os.Vibrator
import android.view.Gravity
import android.view.View
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

internal object IslandTools {
    private const val PREFS = "n27_island"
    private const val ACT_FIRE = "app.notifyios27.ISLAND_TIMER_FIRE"
    const val KEY_TIMER = "n27i-timer"
    const val KEY_SW = "n27i-stopwatch"
    const val KEY_FIRED = "n27i-timer-fired"

    private val main = Handler(Looper.getMainLooper())
    private var alarmRt: Ringtone? = null

    private fun sp(c: Context) = c.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    // ---------------- torch ----------------

    @Volatile
    var torchOn = false
    var torchChanged: (() -> Unit)? = null
    private var torchId: String? = null
    private var torchCb: CameraManager.TorchCallback? = null

    private fun findTorch(cm: CameraManager): String? {
        for (id in cm.cameraIdList) {
            val ch = cm.getCameraCharacteristics(id)
            val flash = ch.get(CameraCharacteristics.FLASH_INFO_AVAILABLE) ?: false
            val facing = ch.get(CameraCharacteristics.LENS_FACING)
            if (flash && facing == CameraCharacteristics.LENS_FACING_BACK) return id
        }
        return null
    }

    fun watchTorch(c: Context) {
        if (torchCb != null) return
        try {
            val cm = c.getSystemService(Context.CAMERA_SERVICE) as CameraManager
            torchId = findTorch(cm)
            val cb = object : CameraManager.TorchCallback() {
                override fun onTorchModeChanged(cameraId: String, enabled: Boolean) {
                    if (cameraId == torchId) {
                        torchOn = enabled
                        torchChanged?.invoke()
                    }
                }
            }
            cm.registerTorchCallback(cb, main)
            torchCb = cb
        } catch (e: Throwable) {
        }
    }

    fun unwatchTorch(c: Context) {
        val cb = torchCb ?: return
        torchCb = null
        torchChanged = null
        try {
            (c.getSystemService(Context.CAMERA_SERVICE) as CameraManager).unregisterTorchCallback(cb)
        } catch (e: Throwable) {
        }
    }

    fun toggleTorch(c: Context) {
        try {
            val cm = c.getSystemService(Context.CAMERA_SERVICE) as CameraManager
            val id = torchId ?: findTorch(cm)
            if (id == null) {
                Toast.makeText(c, "Không bật được đèn pin", Toast.LENGTH_SHORT).show()
                return
            }
            torchId = id
            cm.setTorchMode(id, !torchOn)
        } catch (e: CameraAccessException) {
            Toast.makeText(c, "Không bật được đèn pin", Toast.LENGTH_SHORT).show()
        } catch (e: IllegalArgumentException) {
            Toast.makeText(c, "Không bật được đèn pin", Toast.LENGTH_SHORT).show()
        } catch (e: SecurityException) {
            Toast.makeText(c, "Không bật được đèn pin", Toast.LENGTH_SHORT).show()
        } catch (e: Throwable) {
        }
    }

    // ---------------- timer ----------------

    private fun firePi(c: Context): PendingIntent {
        val i = Intent(c, IslandReceiver::class.java)
        i.action = ACT_FIRE
        return PendingIntent.getBroadcast(c, 4127, i, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
    }

    private fun arm(c: Context, end: Long) {
        try {
            val am = c.getSystemService(Context.ALARM_SERVICE) as AlarmManager
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, end, firePi(c))
        } catch (e: Throwable) {
        }
    }

    private fun putTimer(c: Context, end: Long) {
        Island.putLocal(
            LiveActivity(
                key = KEY_TIMER, pkg = c.packageName, kind = IslandKind.TIMER, title = "Hẹn giờ", subtitle = "",
                chronoBase = end, chronoDown = true,
                localActions = listOf<Pair<String, () -> Unit>>(Pair("Hủy", { cancelTimer(c) })),
                priority = IslandKind.priority(IslandKind.TIMER), appName = "notifyIOS27"
            )
        )
    }

    fun startTimer(c: Context, minutes: Int) {
        val end = System.currentTimeMillis() + minutes * 60000L
        sp(c).edit().putLong("timerEnd", end).apply()
        arm(c, end)
        putTimer(c, end)
    }

    fun cancelTimer(c: Context) {
        try {
            (c.getSystemService(Context.ALARM_SERVICE) as AlarmManager).cancel(firePi(c))
        } catch (e: Throwable) {
        }
        sp(c).edit().remove("timerEnd").apply()
        Island.removeLocal(KEY_TIMER)
    }

    private val stopRun = Runnable {
        val c = appCtxForStop
        if (c != null) stopAlarm(c)
    }
    private var appCtxForStop: Context? = null

    fun onTimerFire(c: Context) {
        sp(c).edit().remove("timerEnd").apply()
        Island.removeLocal(KEY_TIMER)
        appCtxForStop = c
        Island.putLocal(
            LiveActivity(
                key = KEY_FIRED, pkg = c.packageName, kind = IslandKind.TIMER, title = "Hết giờ", subtitle = "",
                frozenMs = 0L,
                localActions = listOf<Pair<String, () -> Unit>>(Pair("Dừng", { stopAlarm(c) })),
                priority = 110, sticky = true, appName = "notifyIOS27"
            )
        )
        Island.expandKey(KEY_FIRED)
        startAlarm(c)
        main.removeCallbacks(stopRun)
        main.postDelayed(stopRun, 30000L)
    }

    @Suppress("DEPRECATION")
    private fun startAlarm(c: Context) {
        try {
            try { alarmRt?.stop() } catch (e: Throwable) { }
            val a = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM)
            val n = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)
            val r = (if (a != null) RingtoneManager.getRingtone(c, a) else null)
                ?: (if (n != null) RingtoneManager.getRingtone(c, n) else null)
            if (r != null) {
                try {
                    r.setAudioAttributes(
                        AudioAttributes.Builder()
                            .setUsage(AudioAttributes.USAGE_ALARM)
                            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                            .build()
                    )
                } catch (e: Throwable) {
                }
                if (Build.VERSION.SDK_INT >= 28) {
                    try { r.isLooping = true } catch (e: Throwable) { }
                }
                alarmRt = r
                r.play()
            }
        } catch (e: Throwable) {
        }
        try {
            val vib = c.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
            if (vib != null && vib.hasVibrator()) {
                vib.vibrate(VibrationEffect.createWaveform(longArrayOf(0L, 600L, 400L, 600L, 400L, 600L), -1))
            }
        } catch (e: Throwable) {
        }
    }

    @Suppress("DEPRECATION")
    fun stopAlarm(c: Context) {
        main.removeCallbacks(stopRun)
        try { alarmRt?.stop() } catch (e: Throwable) { }
        alarmRt = null
        try { (c.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator)?.cancel() } catch (e: Throwable) { }
        Island.removeLocal(KEY_FIRED)
    }

    // ---------------- stopwatch ----------------

    private fun putSw(c: Context) {
        val s = sp(c)
        if (!s.getBoolean("swActive", false)) return
        val base = s.getLong("swBase", System.currentTimeMillis())
        val paused = s.getLong("swPaused", -1L)
        val running = paused < 0L
        Island.putLocal(
            LiveActivity(
                key = KEY_SW, pkg = c.packageName, kind = IslandKind.TIMER, title = "Bấm giờ", subtitle = "",
                chronoBase = base, chronoDown = false, frozenMs = paused,
                localActions = listOf<Pair<String, () -> Unit>>(
                    Pair(if (running) "Tạm dừng" else "Tiếp tục", { toggleStopwatch(c) }),
                    Pair("Đặt lại", { resetStopwatch(c) })
                ),
                priority = IslandKind.priority(IslandKind.TIMER), appName = "notifyIOS27"
            )
        )
    }

    fun startStopwatch(c: Context) {
        val s = sp(c)
        if (!s.getBoolean("swActive", false)) {
            s.edit().putBoolean("swActive", true).putLong("swBase", System.currentTimeMillis())
                .putLong("swPaused", -1L).apply()
        }
        putSw(c)
    }

    fun toggleStopwatch(c: Context) {
        val s = sp(c)
        val now = System.currentTimeMillis()
        val paused = s.getLong("swPaused", -1L)
        if (paused < 0L) {
            s.edit().putLong("swPaused", now - s.getLong("swBase", now)).apply()
        } else {
            s.edit().putLong("swBase", now - paused).putLong("swPaused", -1L).apply()
        }
        putSw(c)
    }

    fun resetStopwatch(c: Context) {
        sp(c).edit().putBoolean("swActive", false).remove("swBase").remove("swPaused").apply()
        Island.removeLocal(KEY_SW)
    }

    fun rearm(c: Context) {
        try {
            val s = sp(c)
            val end = s.getLong("timerEnd", 0L)
            val now = System.currentTimeMillis()
            if (end > 0L) {
                if (end > now) {
                    arm(c, end)
                    putTimer(c, end)
                } else if (now - end < 120000L) {
                    onTimerFire(c)
                } else {
                    s.edit().remove("timerEnd").apply()
                }
            }
            putSw(c)
        } catch (e: Throwable) {
        }
    }

    fun buildPanel(c: Context, dim: Dim, width: Int): IslandContent? = ToolsContent(c, dim, width)
}

internal class ToolsContent(private val ctx: Context, dm: Dim, width: Int) : IslandContent(dm) {
    private var flash: GlyphButton? = null
    private var chips: LinearLayout? = null

    init {
        val col = LinearLayout(ctx)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dim.dp(16f), dim.dp(14f), dim.dp(16f), dim.dp(14f))
        val row = LinearLayout(ctx)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER
        val sz = dim.dp(56f)

        val fb = GlyphButton(ctx, sz, IslandGlyphs.FLASH)
        fb.setOnClickListener { IslandTools.toggleTorch(ctx) }
        flash = fb
        row.addView(item(fb, "Đèn pin"), lpOf(0, WC, 1f))

        val tb = GlyphButton(ctx, sz, IslandGlyphs.TIMER)
        tb.setOnClickListener {
            val ch = chips
            if (ch != null) ch.visibility = if (ch.visibility == View.VISIBLE) View.INVISIBLE else View.VISIBLE
        }
        row.addView(item(tb, "Hẹn giờ"), lpOf(0, WC, 1f))

        val sb = GlyphButton(ctx, sz, IslandGlyphs.STOPWATCH)
        sb.setOnClickListener {
            IslandTools.startStopwatch(ctx)
            Island.expandKey(IslandTools.KEY_SW)
        }
        row.addView(item(sb, "Bấm giờ"), lpOf(0, WC, 1f))
        col.addView(row, lpOf(MP, WC))

        val cr = LinearLayout(ctx)
        cr.orientation = LinearLayout.HORIZONTAL
        cr.gravity = Gravity.CENTER
        for ((i, m) in intArrayOf(1, 5, 10, 15, 30).withIndex()) {
            val t = mkText(ctx, dim, "$m phút", 13f, Color.WHITE, true)
            t.gravity = Gravity.CENTER
            t.setPadding(dim.dp(10f), 0, dim.dp(10f), 0)
            val g = GradientDrawable()
            g.setColor(IC.FILL18)
            g.cornerRadius = dim.dp(16f).toFloat()
            t.background = g
            t.setOnClickListener {
                IslandTools.startTimer(ctx, m)
                Island.closePanel()
            }
            val p = lpOf(WC, dim.dp(32f))
            if (i > 0) p.leftMargin = dim.dp(6f)
            cr.addView(t, p)
        }
        cr.visibility = View.INVISIBLE
        chips = cr
        col.addView(cr, lpOf(MP, WC).also { it.topMargin = dim.dp(14f) })

        root = col
        col.measure(
            View.MeasureSpec.makeMeasureSpec(width, View.MeasureSpec.EXACTLY),
            View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED)
        )
        w = width
        h = maxOf(col.measuredHeight, dim.dp(96f))

        IslandTools.torchChanged = { applyTorch() }
        IslandTools.watchTorch(ctx)
        applyTorch()
    }

    private fun item(b: View, label: String): LinearLayout {
        val l = LinearLayout(ctx)
        l.orientation = LinearLayout.VERTICAL
        l.gravity = Gravity.CENTER_HORIZONTAL
        l.addView(b, lpOf(WC, WC))
        val t: TextView = mkText(ctx, dim, label, 12f, IC.DIM)
        t.gravity = Gravity.CENTER
        l.addView(t, lpOf(WC, WC).also { it.topMargin = dim.dp(6f) })
        return l
    }

    private fun applyTorch() {
        val f = flash ?: return
        val on = IslandTools.torchOn
        f.bg = if (on) Color.WHITE else IC.FILL18
        f.fg = if (on) Color.BLACK else Color.WHITE
        f.cut = if (on) Color.WHITE else Color.BLACK
        f.invalidate()
    }

    override fun release() {
        IslandTools.unwatchTorch(ctx)
    }
}

package app.notifyios27

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Outline
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Typeface
import android.os.SystemClock
import android.text.TextUtils
import android.util.TypedValue
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.ViewGroup
import android.view.ViewOutlineProvider
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import java.util.Locale
import kotlin.math.abs
import kotlin.math.sin

internal const val MP = ViewGroup.LayoutParams.MATCH_PARENT
internal const val WC = ViewGroup.LayoutParams.WRAP_CONTENT

internal object IC {
    val GREEN = 0xFF30D158.toInt()
    val RED = 0xFFFF453A.toInt()
    val ORANGE = 0xFFFF9F0A.toInt()
    const val FILL18 = 0x2EFFFFFF
    const val TRACK = 0x40FFFFFF
    val DIM = 0x99FFFFFF.toInt()
}

internal class Dim(val c: Context) {
    val d: Float = c.resources.displayMetrics.density
    val s: Float = Prefs.islandScale
    val f: Float = Prefs.fontScale * Prefs.islandScale
    private val size: IntArray = UiKit.screenSize(c)
    val screenW: Int = size[0]
    val screenH: Int = size[1]
    val wide: Boolean = c.resources.configuration.smallestScreenWidthDp >= 600
    fun dp(v: Float): Int = (v * d * s + 0.5f).toInt()
    fun px(v: Float): Int = (v * d + 0.5f).toInt()
    fun sp(v: Float): Float = v * f
}

internal fun roundClip(v: View, radiusPx: Float) {
    v.outlineProvider = object : ViewOutlineProvider() {
        override fun getOutline(view: View, outline: Outline) {
            outline.setRoundRect(0, 0, view.width, view.height, radiusPx)
        }
    }
    v.clipToOutline = true
}

internal fun mkText(
    c: Context, dim: Dim, text: String, sp: Float,
    color: Int = Color.WHITE, bold: Boolean = false, lines: Int = 1
): TextView {
    val t = TextView(c)
    t.text = text
    t.setTextSize(TypedValue.COMPLEX_UNIT_SP, dim.sp(sp))
    t.setTextColor(color)
    t.typeface = Typeface.create("sans-serif-medium", if (bold) Typeface.BOLD else Typeface.NORMAL)
    t.maxLines = lines
    t.ellipsize = TextUtils.TruncateAt.END
    t.includeFontPadding = false
    return t
}

internal fun mkMarquee(t: TextView) {
    t.setSingleLine(true)
    t.ellipsize = TextUtils.TruncateAt.MARQUEE
    t.marqueeRepeatLimit = -1
    t.isSelected = true
}

internal fun lpOf(w: Int, h: Int, weight: Float = 0f): LinearLayout.LayoutParams =
    LinearLayout.LayoutParams(w, h, weight)

internal class Btn(val label: String, val color: Int, val onClick: () -> Unit)

internal fun btnColor(title: String, call: Boolean): Int {
    if (!call) return IC.FILL18
    val t = title.lowercase(Locale.ROOT)
    val red = arrayOf("từ chối", "decline", "reject", "end", "hang", "kết thúc")
    val green = arrayOf("trả lời", "answer", "accept", "nghe")
    for (w in red) if (t.contains(w)) return IC.RED
    for (w in green) if (t.contains(w)) return IC.GREEN
    return IC.FILL18
}

internal fun btnsOf(a: LiveActivity): List<Btn> {
    val call = a.kind == IslandKind.CALL
    val out = ArrayList<Btn>()
    for (la in a.localActions) {
        if (out.size >= 2) break
        out.add(Btn(la.first, btnColor(la.first, call), la.second))
    }
    if (out.isEmpty()) {
        for (act in a.actions) {
            if (out.size >= 2) break
            if (act.title.isBlank()) continue
            out.add(Btn(act.title, btnColor(act.title, call)) { Island.runAction(a, act, null) })
        }
    }
    return out
}

internal fun mkPill(c: Context, dim: Dim, b: Btn): TextView {
    val t = mkText(c, dim, b.label, 15f, Color.WHITE, true)
    t.gravity = Gravity.CENTER
    t.setPadding(dim.dp(14f), 0, dim.dp(14f), 0)
    t.background = FlatDrawable(b.color, dim.dp(22f).toFloat())
    t.setOnClickListener { b.onClick() }
    return t
}

internal fun btnRow(c: Context, dim: Dim, list: List<Btn>): LinearLayout? {
    if (list.isEmpty()) return null
    val row = LinearLayout(c)
    row.orientation = LinearLayout.HORIZONTAL
    for ((i, b) in list.withIndex()) {
        val p = lpOf(0, dim.dp(44f), 1f)
        if (i > 0) p.leftMargin = dim.dp(8f)
        row.addView(mkPill(c, dim, b), p)
    }
    return row
}

internal object IslandGlyphs {
    const val PHONE = 0
    const val HEADPHONES = 1
    const val BELL = 2
    const val BELL_SLASH = 3
    const val VIBRATE = 4
    const val BATTERY = 5
    const val ARROW = 6
    const val PLAY = 7
    const val PAUSE = 8
    const val PREV = 9
    const val NEXT = 10
    const val FLASH = 11
    const val TIMER = 12
    const val STOPWATCH = 13

    /** Draws a glyph inside a 24 x 24 box. */
    fun draw(cv: Canvas, id: Int, p: Paint, path: Path, rf: RectF, color: Int, cut: Int, level: Float) {
        p.color = color
        p.style = Paint.Style.FILL
        p.strokeCap = Paint.Cap.ROUND
        p.strokeJoin = Paint.Join.ROUND
        when (id) {
            PHONE -> {
                p.style = Paint.Style.STROKE
                p.strokeWidth = 3.4f
                path.reset()
                path.moveTo(6f, 7f)
                path.quadTo(7f, 16f, 17f, 18f)
                cv.drawPath(path, p)
                p.style = Paint.Style.FILL
                cv.drawCircle(5.8f, 6.2f, 2.3f, p)
                cv.drawCircle(17.8f, 18.2f, 2.3f, p)
            }
            HEADPHONES -> {
                p.style = Paint.Style.STROKE
                p.strokeWidth = 2f
                rf.set(4.5f, 3.5f, 19.5f, 18.5f)
                cv.drawArc(rf, 180f, 180f, false, p)
                p.style = Paint.Style.FILL
                rf.set(3f, 11.5f, 7f, 19.5f)
                cv.drawRoundRect(rf, 2f, 2f, p)
                rf.set(17f, 11.5f, 21f, 19.5f)
                cv.drawRoundRect(rf, 2f, 2f, p)
            }
            BELL, BELL_SLASH -> {
                path.reset()
                path.moveTo(4f, 18f)
                path.lineTo(6f, 16f)
                path.lineTo(6f, 11f)
                path.cubicTo(6f, 7.5f, 8.5f, 5f, 12f, 5f)
                path.cubicTo(15.5f, 5f, 18f, 7.5f, 18f, 11f)
                path.lineTo(18f, 16f)
                path.lineTo(20f, 18f)
                path.close()
                cv.drawPath(path, p)
                cv.drawCircle(12f, 4.4f, 1.3f, p)
                cv.drawCircle(12f, 20.4f, 1.9f, p)
                if (id == BELL_SLASH) {
                    p.style = Paint.Style.STROKE
                    p.color = cut
                    p.strokeWidth = 4.6f
                    cv.drawLine(4f, 3.5f, 20f, 21f, p)
                    p.color = color
                    p.strokeWidth = 2f
                    cv.drawLine(4f, 3.5f, 20f, 21f, p)
                }
            }
            VIBRATE -> {
                p.style = Paint.Style.STROKE
                p.strokeWidth = 1.9f
                rf.set(8f, 4f, 16f, 20f)
                cv.drawRoundRect(rf, 2f, 2f, p)
                cv.drawLine(4.5f, 8f, 4.5f, 16f, p)
                cv.drawLine(19.5f, 8f, 19.5f, 16f, p)
                cv.drawLine(2f, 10f, 2f, 14f, p)
                cv.drawLine(22f, 10f, 22f, 14f, p)
            }
            BATTERY -> {
                p.style = Paint.Style.STROKE
                p.strokeWidth = 1.8f
                rf.set(2.5f, 7f, 19f, 17f)
                cv.drawRoundRect(rf, 2.5f, 2.5f, p)
                p.style = Paint.Style.FILL
                rf.set(19.8f, 10f, 21.8f, 14f)
                cv.drawRoundRect(rf, 1f, 1f, p)
                val l = level.coerceIn(0f, 1f)
                if (l > 0.02f) {
                    rf.set(4.3f, 8.8f, 4.3f + 13.1f * l, 15.2f)
                    cv.drawRoundRect(rf, 1.2f, 1.2f, p)
                }
            }
            ARROW -> {
                path.reset()
                path.moveTo(12f, 3f)
                path.lineTo(19f, 20f)
                path.lineTo(12f, 16f)
                path.lineTo(5f, 20f)
                path.close()
                cv.drawPath(path, p)
            }
            PLAY -> {
                path.reset()
                path.moveTo(7f, 4f)
                path.lineTo(20f, 12f)
                path.lineTo(7f, 20f)
                path.close()
                cv.drawPath(path, p)
            }
            PAUSE -> {
                rf.set(6f, 4f, 10f, 20f)
                cv.drawRoundRect(rf, 1.2f, 1.2f, p)
                rf.set(14f, 4f, 18f, 20f)
                cv.drawRoundRect(rf, 1.2f, 1.2f, p)
            }
            PREV -> {
                rf.set(4.5f, 5f, 7.5f, 19f)
                cv.drawRoundRect(rf, 1f, 1f, p)
                path.reset()
                path.moveTo(20f, 5f)
                path.lineTo(20f, 19f)
                path.lineTo(8.5f, 12f)
                path.close()
                cv.drawPath(path, p)
            }
            NEXT -> {
                rf.set(16.5f, 5f, 19.5f, 19f)
                cv.drawRoundRect(rf, 1f, 1f, p)
                path.reset()
                path.moveTo(4f, 5f)
                path.lineTo(4f, 19f)
                path.lineTo(15.5f, 12f)
                path.close()
                cv.drawPath(path, p)
            }
            FLASH -> {
                rf.set(7f, 2.5f, 17f, 7.5f)
                cv.drawRoundRect(rf, 1.5f, 1.5f, p)
                path.reset()
                path.moveTo(9.5f, 7.5f)
                path.lineTo(14.5f, 7.5f)
                path.lineTo(14.5f, 20f)
                path.quadTo(14.5f, 21.5f, 13f, 21.5f)
                path.lineTo(11f, 21.5f)
                path.quadTo(9.5f, 21.5f, 9.5f, 20f)
                path.close()
                cv.drawPath(path, p)
                p.color = cut
                cv.drawCircle(12f, 12.5f, 1.2f, p)
            }
            TIMER -> {
                p.style = Paint.Style.STROKE
                p.strokeWidth = 2f
                cv.drawCircle(12f, 12f, 8f, p)
                cv.drawLine(12f, 12f, 12f, 7f, p)
                cv.drawLine(12f, 12f, 16f, 14f, p)
            }
            STOPWATCH -> {
                p.style = Paint.Style.STROKE
                p.strokeWidth = 2f
                cv.drawCircle(12f, 13.5f, 7.5f, p)
                cv.drawLine(12f, 13.5f, 15f, 10.5f, p)
                cv.drawLine(10f, 2.8f, 14f, 2.8f, p)
                cv.drawLine(12f, 3f, 12f, 6f, p)
            }
            else -> {
            }
        }
    }
}

internal class GlyphView(c: Context, var glyph: Int, var color: Int = Color.WHITE) : View(c) {
    var level = 0.7f
    var sizePx = 0

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        if (sizePx > 0) setMeasuredDimension(sizePx, sizePx) else super.onMeasure(widthMeasureSpec, heightMeasureSpec)
    }
    var cut = Color.BLACK
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val path = Path()
    private val rf = RectF()

    override fun onDraw(canvas: Canvas) {
        val sc = minOf(width, height) / 24f
        canvas.save()
        canvas.translate((width - 24f * sc) / 2f, (height - 24f * sc) / 2f)
        canvas.scale(sc, sc)
        IslandGlyphs.draw(canvas, glyph, p, path, rf, color, cut, level)
        canvas.restore()
    }
}

internal class GlyphButton(c: Context, private val sizePx: Int, var glyph: Int) : View(c) {
    var bg = IC.FILL18
    var fg = Color.WHITE
    var cut = Color.BLACK
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val gp = Paint(Paint.ANTI_ALIAS_FLAG)
    private val path = Path()
    private val rf = RectF()

    init {
        isClickable = true
    }

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        setMeasuredDimension(sizePx, sizePx)
    }

    override fun onDraw(canvas: Canvas) {
        p.color = bg
        p.style = Paint.Style.FILL
        val r = sizePx / 2f
        canvas.drawCircle(r, r, r, p)
        val gs = sizePx * 0.46f / 24f
        canvas.save()
        canvas.translate(r - 12f * gs, r - 12f * gs)
        canvas.scale(gs, gs)
        IslandGlyphs.draw(canvas, glyph, gp, path, rf, fg, cut, 0.7f)
        canvas.restore()
    }
}

internal class EqView(c: Context, private val barW: Int, private val gapPx: Int, private val maxH: Int) : View(c) {
    var playing = true
        set(v) {
            field = v
            invalidate()
        }
    var color = Color.WHITE
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rf = RectF()
    // no looping redraw on LITE or with animation off
    private val live = Perf.loops()

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        setMeasuredDimension(4 * barW + 3 * gapPx, maxH)
    }

    override fun onDraw(canvas: Canvas) {
        p.color = color
        val t = SystemClock.uptimeMillis() / 1000f
        val cy = height / 2f
        for (i in 0 until 4) {
            val x = i * (barW + gapPx).toFloat()
            if (playing) {
                val hh = if (live) maxH * (0.3f + 0.7f * abs(sin(t * (3.1f + i * 1.3f) + i * 1.7f)))
                else maxH * (0.45f + 0.15f * (i % 3))
                rf.set(x, cy - hh / 2f, x + barW, cy + hh / 2f)
                canvas.drawRoundRect(rf, barW / 2f, barW / 2f, p)
            } else {
                canvas.drawCircle(x + barW / 2f, cy, barW / 2f, p)
            }
        }
        if (playing && live && isAttachedToWindow) postInvalidateOnAnimation()
    }
}

internal class RingView(c: Context, private val sizePx: Int, private val strokePx: Float) : View(c) {
    var fraction = 0f
        set(v) {
            field = v.coerceIn(0f, 1f)
            invalidate()
        }
    var indeterminate = false
        set(v) {
            field = v
            invalidate()
        }
    var color = Color.WHITE
    var label = ""
        set(v) {
            field = v
            invalidate()
        }
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val tp = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rf = RectF()

    init {
        p.style = Paint.Style.STROKE
        p.strokeWidth = strokePx
        p.strokeCap = Paint.Cap.ROUND
        tp.color = Color.WHITE
        tp.textAlign = Paint.Align.CENTER
        tp.textSize = sizePx * 0.34f
        tp.typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
    }

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        setMeasuredDimension(sizePx, sizePx)
    }

    override fun onDraw(canvas: Canvas) {
        val m = strokePx / 2f
        rf.set(m, m, sizePx - m, sizePx - m)
        p.color = IC.TRACK
        canvas.drawArc(rf, 0f, 360f, false, p)
        p.color = color
        if (indeterminate) {
            val live = Perf.loops()
            val a = if (live) (SystemClock.uptimeMillis() % 900L) / 900f * 360f else -90f
            canvas.drawArc(rf, a, 100f, false, p)
            if (live && isAttachedToWindow) postInvalidateOnAnimation()
        } else {
            canvas.drawArc(rf, -90f, 360f * fraction, false, p)
            if (label.isNotEmpty()) {
                canvas.drawText(label, sizePx / 2f, sizePx / 2f + tp.textSize * 0.35f, tp)
            }
        }
    }
}

internal class BarView(c: Context, private val trackH: Int, private val touchH: Int) : View(c) {
    var fraction = 0f
        set(v) {
            field = v.coerceIn(0f, 1f)
            invalidate()
        }
    var fillColor = Color.WHITE
    var seekEnabled = false
    var onSeek: ((Float) -> Unit)? = null
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rf = RectF()
    private var drag = -1f

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        setMeasuredDimension(View.resolveSize(suggestedMinimumWidth, widthMeasureSpec), touchH)
    }

    override fun onDraw(canvas: Canvas) {
        val top = (height - trackH) / 2f
        val r = trackH / 2f
        p.color = IC.TRACK
        rf.set(0f, top, width.toFloat(), top + trackH)
        canvas.drawRoundRect(rf, r, r, p)
        val f = if (drag >= 0f) drag else fraction
        p.color = fillColor
        rf.set(0f, top, maxOf(trackH.toFloat(), width * f), top + trackH)
        canvas.drawRoundRect(rf, r, r, p)
    }

    override fun onTouchEvent(event: MotionEvent?): Boolean {
        val e = event ?: return true
        if (!seekEnabled || width <= 0) return true
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_MOVE -> {
                drag = (e.x / width).coerceIn(0f, 1f)
                invalidate()
            }
            MotionEvent.ACTION_UP -> {
                val f = (e.x / width).coerceIn(0f, 1f)
                drag = -1f
                invalidate()
                onSeek?.invoke(f)
            }
            MotionEvent.ACTION_CANCEL -> {
                drag = -1f
                invalidate()
            }
        }
        return true
    }
}

internal interface PillListener {
    fun onTap()
    fun onLong()
    fun onSwipeUp()
    fun onSwipeDown()
    fun onSwipeH()
    fun onTouch(down: Boolean)
}

internal class Pill(c: Context) : FrameLayout(c) {
    var listener: PillListener? = null
    var radius = 0f
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rect = RectF()
    private val path = Path()
    private val slop = ViewConfiguration.get(c).scaledTouchSlop
    private val th = 40f * c.resources.displayMetrics.density
    private var x0 = 0f
    private var y0 = 0f
    private var moved = false
    private var longDone = false
    private val longRun = Runnable {
        longDone = true
        listener?.onLong()
    }

    init {
        paint.color = Color.BLACK
        setWillNotDraw(false)
    }

    override fun onDraw(canvas: Canvas) {
        rect.set(0f, 0f, width.toFloat(), height.toFloat())
        canvas.drawRoundRect(rect, radius, radius, paint)
    }

    override fun dispatchDraw(canvas: Canvas) {
        rect.set(0f, 0f, width.toFloat(), height.toFloat())
        path.reset()
        path.addRoundRect(rect, radius, radius, Path.Direction.CW)
        canvas.save()
        canvas.clipPath(path)
        super.dispatchDraw(canvas)
        canvas.restore()
    }

    override fun onTouchEvent(event: MotionEvent?): Boolean {
        val e = event ?: return false
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                x0 = e.rawX
                y0 = e.rawY
                moved = false
                longDone = false
                listener?.onTouch(true)
                postDelayed(longRun, ViewConfiguration.getLongPressTimeout().toLong())
            }
            MotionEvent.ACTION_MOVE -> {
                if (!moved && (abs(e.rawX - x0) > slop || abs(e.rawY - y0) > slop)) {
                    moved = true
                    removeCallbacks(longRun)
                }
            }
            MotionEvent.ACTION_UP -> {
                removeCallbacks(longRun)
                listener?.onTouch(false)
                if (!longDone) {
                    val dx = e.rawX - x0
                    val dy = e.rawY - y0
                    when {
                        abs(dx) > th && abs(dx) > abs(dy) -> listener?.onSwipeH()
                        dy < -th -> listener?.onSwipeUp()
                        dy > th -> listener?.onSwipeDown()
                        !moved -> listener?.onTap()
                    }
                }
            }
            MotionEvent.ACTION_CANCEL -> {
                removeCallbacks(longRun)
                listener?.onTouch(false)
            }
        }
        return true
    }
}

internal class SplitCircle(c: Context) : FrameLayout(c) {
    private val icon = ImageView(c)

    init {
        background = FlatDrawable(Color.BLACK, 0f, true)
        icon.scaleType = ImageView.ScaleType.CENTER_CROP
        addView(icon, FrameLayout.LayoutParams(1, 1, Gravity.CENTER))
    }

    fun bind(a: LiveActivity, size: Int) {
        val s = (size * 0.62f).toInt()
        val lp = icon.layoutParams as FrameLayout.LayoutParams
        lp.width = s
        lp.height = s
        roundClip(icon, s * 0.25f)
        IslandUi.setArt(context, icon, a)
        icon.requestLayout()
    }
}

/** Window root: reports outside touches. */
internal class IslandView(c: Context) : FrameLayout(c) {
    val pill = Pill(c)
    val circle = SplitCircle(c)
    var onOutside: (() -> Unit)? = null

    init {
        clipChildren = false
        clipToPadding = false
        addView(pill, FrameLayout.LayoutParams(1, 1, Gravity.TOP or Gravity.START))
        circle.visibility = View.GONE
        addView(circle, FrameLayout.LayoutParams(1, 1, Gravity.TOP or Gravity.START))
    }

    override fun dispatchTouchEvent(ev: MotionEvent?): Boolean {
        if (ev != null && ev.actionMasked == MotionEvent.ACTION_OUTSIDE) {
            onOutside?.invoke()
            return true
        }
        return super.dispatchTouchEvent(ev)
    }
}

internal object IslandUi {
    fun setArt(c: Context, iv: ImageView, a: LiveActivity) {
        val b = a.art
        if (b != null) iv.setImageBitmap(b)
        else iv.setImageDrawable(a.appIcon ?: AppIcons.icon(c, a.pkg))
    }
}

internal abstract class IslandContent(val dim: Dim) {
    lateinit var root: View
    var w = 0
    var h = 0
    open fun update(a: LiveActivity) {}
    open fun tick() {}
    open fun release() {}
}

internal class CompactContent(
    private val ctx: Context, dm: Dim, a: LiveActivity, gap: Int, val idle: Boolean
) : IslandContent(dm) {
    val kind: Int = a.kind
    private var cur = a
    private var lead: ImageView? = null
    private var eq: EqView? = null
    private var ring: RingView? = null
    private var timeTv: TextView? = null
    private var textTv: TextView? = null
    private var batt: GlyphView? = null
    private var lastTime = ""
    private var lastArt: Any? = null

    init {
        h = dim.dp(36f)
        val fl = FrameLayout(ctx)
        root = fl
        if (idle) {
            w = gap + dim.dp(16f)
        } else {
            val pe = dim.dp(12f)
            val iv = ImageView(ctx)
            iv.scaleType = ImageView.ScaleType.CENTER_CROP
            roundClip(iv, dim.dp(6f).toFloat())
            lead = iv
            setLeading(a)
            val trailing = buildTrailing(a)
            trailing.measure(
                View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED),
                View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED)
            )
            val side = pe + maxOf(dim.dp(24f), trailing.measuredWidth)
            w = gap + 2 * side
            val l1 = FrameLayout.LayoutParams(dim.dp(24f), dim.dp(24f), Gravity.START or Gravity.CENTER_VERTICAL)
            l1.leftMargin = pe
            fl.addView(iv, l1)
            val l2 = FrameLayout.LayoutParams(WC, WC, Gravity.END or Gravity.CENTER_VERTICAL)
            l2.rightMargin = pe
            fl.addView(trailing, l2)
            tick()
        }
    }

    private fun setLeading(a: LiveActivity) {
        val iv = lead ?: return
        IslandUi.setArt(ctx, iv, a)
        lastArt = a.art
    }

    private fun row(vararg views: View): LinearLayout {
        val r = LinearLayout(ctx)
        r.orientation = LinearLayout.HORIZONTAL
        r.gravity = Gravity.CENTER_VERTICAL
        for ((i, v) in views.withIndex()) {
            val p = lpOf(WC, WC)
            if (i > 0) p.leftMargin = dim.dp(5f)
            r.addView(v, p)
        }
        return r
    }

    private fun glyph(g: Int, color: Int, size: Float): GlyphView {
        val v = GlyphView(ctx, g, color)
        v.sizePx = dim.dp(size)
        return v
    }

    private fun timeText(a: LiveActivity, color: Int): TextView {
        val s = IslandFmt.time(a, System.currentTimeMillis())
        val t = mkText(ctx, dim, s, 13f, color, true)
        t.gravity = Gravity.END
        val sample = s.replace(Regex("[0-9]"), "8")
        t.minWidth = t.paint.measureText(sample).toInt() + dim.dp(2f)
        t.setSingleLine(true)
        t.ellipsize = null
        timeTv = t
        lastTime = s
        return t
    }

    private fun ringerGlyph(mode: Int): Int = when (mode) {
        android.media.AudioManager.RINGER_MODE_VIBRATE -> IslandGlyphs.VIBRATE
        android.media.AudioManager.RINGER_MODE_SILENT -> IslandGlyphs.BELL_SLASH
        else -> IslandGlyphs.BELL
    }

    private fun buildTrailing(a: LiveActivity): View {
        when (a.kind) {
            IslandKind.MEDIA -> {
                val e = EqView(ctx, dim.dp(3f), dim.dp(2f), dim.dp(16f))
                e.color = UiKit.accent(ctx)
                e.playing = a.playing
                eq = e
                return e
            }
            IslandKind.CALL -> return row(glyph(IslandGlyphs.PHONE, IC.GREEN, 16f), timeText(a, IC.GREEN))
            IslandKind.TIMER -> return timeText(a, IC.ORANGE)
            IslandKind.PROGRESS -> {
                val r = RingView(ctx, dim.dp(24f), dim.dp(2.5f).toFloat())
                r.color = UiKit.accent(ctx)
                applyRing(r, a)
                ring = r
                return r
            }
            IslandKind.NAV -> {
                val t = mkText(ctx, dim, IslandFmt.firstLine(a.subtitle.ifBlank { a.title }), 12f)
                t.maxWidth = dim.dp(110f)
                textTv = t
                return row(glyph(IslandGlyphs.ARROW, IC.GREEN, 16f), t)
            }
            IslandKind.CHARGE -> {
                val col = if (a.warn) IC.RED else IC.GREEN
                val g = glyph(IslandGlyphs.BATTERY, col, 20f)
                g.level = a.value / 100f
                batt = g
                val t = mkText(ctx, dim, "${a.value}%", 13f, col, true)
                textTv = t
                return row(g, t)
            }
            IslandKind.RINGER -> return glyph(ringerGlyph(a.value), Color.WHITE, 22f)
            IslandKind.HEADSET -> return glyph(IslandGlyphs.HEADPHONES, Color.WHITE, 22f)
            else -> return glyph(IslandGlyphs.BELL, Color.WHITE, 20f)
        }
    }

    private fun applyRing(r: RingView, a: LiveActivity) {
        r.indeterminate = a.indeterminate || a.progressMax <= 0 || a.progress < 0
        if (!r.indeterminate) {
            val f = a.progress.toFloat() / a.progressMax
            r.fraction = f
            r.label = (f * 100f).toInt().coerceIn(0, 100).toString()
        }
    }

    override fun update(a: LiveActivity) {
        cur = a
        eq?.playing = a.playing
        ring?.let { applyRing(it, a) }
        if (a.kind == IslandKind.NAV) textTv?.text = IslandFmt.firstLine(a.subtitle.ifBlank { a.title })
        if (a.kind == IslandKind.CHARGE) {
            textTv?.text = "${a.value}%"
            batt?.level = a.value / 100f
            batt?.invalidate()
        }
        if (lastArt !== a.art) setLeading(a)
        tick()
    }

    override fun tick() {
        val tt = timeTv ?: return
        val s = IslandFmt.time(cur, System.currentTimeMillis())
        if (s != lastTime) {
            lastTime = s
            tt.text = s
        }
    }
}

private fun shapeOf(a: LiveActivity): String {
    val sb = StringBuilder()
    sb.append(a.kind)
    for (b in btnsOf(a)) sb.append('|').append(b.label)
    return sb.toString()
}

internal class ExpandedContent(
    private val ctx: Context, dm: Dim, a: LiveActivity, width: Int
) : IslandContent(dm) {
    private var cur = a
    private var titleTv: TextView? = null
    private var subTv: TextView? = null
    private var timeTv: TextView? = null
    private var pctTv: TextView? = null
    private var bar: BarView? = null
    private var posTv: TextView? = null
    private var durTv: TextView? = null
    private var playBtn: GlyphButton? = null
    private var art: ImageView? = null
    private var lastTime = ""
    private var lastArt: Any? = null
    private val shape: String = shapeOf(a)

    fun sameShape(a: LiveActivity): Boolean = shapeOf(a) == shape

    init {
        val col = LinearLayout(ctx)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dim.dp(16f), dim.dp(14f), dim.dp(16f), dim.dp(14f))
        when (a.kind) {
            IslandKind.MEDIA -> buildMedia(col, a)
            IslandKind.CALL -> buildCall(col, a)
            IslandKind.TIMER -> buildTimer(col, a)
            IslandKind.PROGRESS -> buildProgress(col, a)
            IslandKind.CHARGE -> buildCharge(col, a)
            IslandKind.RINGER, IslandKind.HEADSET -> buildGlyphCard(col, a)
            else -> buildText(col, a)
        }
        root = col
        col.measure(
            View.MeasureSpec.makeMeasureSpec(width, View.MeasureSpec.EXACTLY),
            View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED)
        )
        w = width
        h = maxOf(col.measuredHeight, dim.dp(96f)).coerceAtMost((dim.screenH * 0.7f).toInt())
        tick()
    }

    private fun gap(v: View, top: Float) {
        (v.layoutParams as? LinearLayout.LayoutParams)?.topMargin = dim.dp(top)
    }

    private fun addButtons(col: LinearLayout, a: LiveActivity) {
        val r = btnRow(ctx, dim, btnsOf(a)) ?: return
        col.addView(r, lpOf(MP, WC).also { it.topMargin = dim.dp(12f) })
    }

    private fun iconView(a: LiveActivity, size: Float): ImageView {
        val iv = ImageView(ctx)
        iv.scaleType = ImageView.ScaleType.CENTER_CROP
        roundClip(iv, dim.dp(size * 0.25f).toFloat())
        IslandUi.setArt(ctx, iv, a)
        return iv
    }

    private fun buildMedia(col: LinearLayout, a: LiveActivity) {
        val top = LinearLayout(ctx)
        top.gravity = Gravity.CENTER_VERTICAL
        val iv = ImageView(ctx)
        iv.scaleType = ImageView.ScaleType.CENTER_CROP
        iv.setBackgroundColor(IC.TRACK)
        roundClip(iv, dim.dp(10f).toFloat())
        IslandUi.setArt(ctx, iv, a)
        lastArt = a.art
        art = iv
        top.addView(iv, lpOf(dim.dp(56f), dim.dp(56f)))
        val tc = LinearLayout(ctx)
        tc.orientation = LinearLayout.VERTICAL
        val t = mkText(ctx, dim, a.title, 16f, Color.WHITE, true)
        mkMarquee(t)
        titleTv = t
        val s = mkText(ctx, dim, a.subtitle, 13f, IC.DIM)
        mkMarquee(s)
        subTv = s
        tc.addView(t, lpOf(MP, WC))
        tc.addView(s, lpOf(MP, WC).also { it.topMargin = dim.dp(3f) })
        top.addView(tc, lpOf(0, WC, 1f).also { it.leftMargin = dim.dp(12f) })
        col.addView(top, lpOf(MP, WC))

        val row = LinearLayout(ctx)
        row.gravity = Gravity.CENTER_VERTICAL
        val pos = mkText(ctx, dim, "0:00", 11f, IC.DIM)
        val dur = mkText(ctx, dim, "0:00", 11f, IC.DIM)
        val b = BarView(ctx, dim.dp(5f), dim.dp(24f))
        b.onSeek = { f -> Island.seekTo(cur.key, f) }
        posTv = pos
        durTv = dur
        bar = b
        row.addView(pos, lpOf(WC, WC))
        row.addView(b, lpOf(0, dim.dp(24f), 1f).also {
            it.leftMargin = dim.dp(8f)
            it.rightMargin = dim.dp(8f)
        })
        row.addView(dur, lpOf(WC, WC))
        col.addView(row, lpOf(MP, WC).also { it.topMargin = dim.dp(8f) })

        val br = LinearLayout(ctx)
        br.gravity = Gravity.CENTER
        val sz = dim.dp(44f)
        val prev = GlyphButton(ctx, sz, IslandGlyphs.PREV)
        prev.setOnClickListener { Island.mediaCommand(cur, 0) }
        val play = GlyphButton(ctx, sz, if (a.playing) IslandGlyphs.PAUSE else IslandGlyphs.PLAY)
        play.setOnClickListener { Island.mediaCommand(cur, 1) }
        playBtn = play
        val next = GlyphButton(ctx, sz, IslandGlyphs.NEXT)
        next.setOnClickListener { Island.mediaCommand(cur, 2) }
        val m = dim.dp(14f)
        br.addView(prev, lpOf(sz, sz).also { it.rightMargin = m })
        br.addView(play, lpOf(sz, sz).also { it.leftMargin = m; it.rightMargin = m })
        br.addView(next, lpOf(sz, sz).also { it.leftMargin = m })
        col.addView(br, lpOf(MP, WC).also { it.topMargin = dim.dp(4f) })
    }

    private fun buildCall(col: LinearLayout, a: LiveActivity) {
        val top = LinearLayout(ctx)
        top.gravity = Gravity.CENTER_VERTICAL
        top.addView(iconView(a, 40f), lpOf(dim.dp(40f), dim.dp(40f)))
        val tc = LinearLayout(ctx)
        tc.orientation = LinearLayout.VERTICAL
        val t = mkText(ctx, dim, a.title, 17f, Color.WHITE, true)
        val s = mkText(ctx, dim, a.subtitle, 13f, IC.DIM)
        titleTv = t
        subTv = s
        tc.addView(t, lpOf(MP, WC))
        tc.addView(s, lpOf(MP, WC).also { it.topMargin = dim.dp(2f) })
        top.addView(tc, lpOf(0, WC, 1f).also { it.leftMargin = dim.dp(12f) })
        val tm = mkText(ctx, dim, "00:00", 16f, IC.GREEN, true)
        timeTv = tm
        top.addView(tm, lpOf(WC, WC))
        col.addView(top, lpOf(MP, WC))
        addButtons(col, a)
    }

    private fun buildTimer(col: LinearLayout, a: LiveActivity) {
        val tm = mkText(ctx, dim, "00:00", 44f, IC.ORANGE, false)
        tm.typeface = Typeface.create("sans-serif-thin", Typeface.NORMAL)
        tm.gravity = Gravity.CENTER
        timeTv = tm
        col.addView(tm, lpOf(MP, WC))
        val t = mkText(ctx, dim, a.title, 14f, IC.DIM)
        t.gravity = Gravity.CENTER
        titleTv = t
        col.addView(t, lpOf(MP, WC).also { it.topMargin = dim.dp(4f) })
        addButtons(col, a)
    }

    private fun frac(a: LiveActivity): Float =
        if (a.progressMax > 0 && a.progress >= 0) (a.progress.toFloat() / a.progressMax).coerceIn(0f, 1f) else 0f

    private fun buildProgress(col: LinearLayout, a: LiveActivity) {
        val t = mkText(ctx, dim, a.title, 16f, Color.WHITE, true)
        val s = mkText(ctx, dim, a.subtitle, 13f, IC.DIM)
        titleTv = t
        subTv = s
        col.addView(t, lpOf(MP, WC))
        col.addView(s, lpOf(MP, WC).also { it.topMargin = dim.dp(3f) })
        val row = LinearLayout(ctx)
        row.gravity = Gravity.CENTER_VERTICAL
        val b = BarView(ctx, dim.dp(6f), dim.dp(20f))
        b.fillColor = UiKit.accent(ctx)
        b.fraction = frac(a)
        bar = b
        val p = mkText(ctx, dim, "${(frac(a) * 100f).toInt()}%", 13f, Color.WHITE, true)
        pctTv = p
        row.addView(b, lpOf(0, dim.dp(20f), 1f).also { it.rightMargin = dim.dp(10f) })
        row.addView(p, lpOf(WC, WC))
        col.addView(row, lpOf(MP, WC).also { it.topMargin = dim.dp(10f) })
        addButtons(col, a)
    }

    private fun buildCharge(col: LinearLayout, a: LiveActivity) {
        val color = if (a.warn) IC.RED else IC.GREEN
        val top = LinearLayout(ctx)
        top.gravity = Gravity.CENTER_VERTICAL
        val big = mkText(ctx, dim, "${a.value}%", 40f, color, false)
        big.typeface = Typeface.create("sans-serif-thin", Typeface.NORMAL)
        pctTv = big
        top.addView(big, lpOf(WC, WC))
        val tc = LinearLayout(ctx)
        tc.orientation = LinearLayout.VERTICAL
        val t = mkText(ctx, dim, a.title, 16f, Color.WHITE, true)
        val s = mkText(ctx, dim, a.subtitle, 13f, IC.DIM, false, 2)
        titleTv = t
        subTv = s
        tc.addView(t, lpOf(MP, WC))
        tc.addView(s, lpOf(MP, WC).also { it.topMargin = dim.dp(2f) })
        top.addView(tc, lpOf(0, WC, 1f).also { it.leftMargin = dim.dp(14f) })
        col.addView(top, lpOf(MP, WC))
        val b = BarView(ctx, dim.dp(8f), dim.dp(16f))
        b.fillColor = color
        b.fraction = a.value / 100f
        bar = b
        col.addView(b, lpOf(MP, dim.dp(16f)).also { it.topMargin = dim.dp(12f) })
    }

    private fun buildGlyphCard(col: LinearLayout, a: LiveActivity) {
        val row = LinearLayout(ctx)
        row.gravity = Gravity.CENTER_VERTICAL
        val g = if (a.kind == IslandKind.HEADSET) IslandGlyphs.HEADPHONES else when (a.value) {
            android.media.AudioManager.RINGER_MODE_VIBRATE -> IslandGlyphs.VIBRATE
            android.media.AudioManager.RINGER_MODE_SILENT -> IslandGlyphs.BELL_SLASH
            else -> IslandGlyphs.BELL
        }
        val gv = GlyphView(ctx, g, Color.WHITE)
        row.addView(gv, lpOf(dim.dp(44f), dim.dp(44f)))
        val t = mkText(ctx, dim, a.title, 20f, Color.WHITE, true, 2)
        titleTv = t
        row.addView(t, lpOf(0, WC, 1f).also { it.leftMargin = dim.dp(14f) })
        col.addView(row, lpOf(MP, WC).also { it.topMargin = dim.dp(6f) })
    }

    private fun buildText(col: LinearLayout, a: LiveActivity) {
        val big = a.kind == IslandKind.NAV
        val t = mkText(ctx, dim, a.title, if (big) 18f else 16f, Color.WHITE, true, 2)
        val s = mkText(ctx, dim, a.subtitle, 14f, IC.DIM, false, 2)
        titleTv = t
        subTv = s
        col.addView(t, lpOf(MP, WC))
        col.addView(s, lpOf(MP, WC).also { it.topMargin = dim.dp(4f) })
        addButtons(col, a)
    }

    private fun setIf(t: TextView?, s: String) {
        if (t != null && t.text.toString() != s) t.text = s
    }

    override fun update(a: LiveActivity) {
        cur = a
        setIf(titleTv, a.title)
        setIf(subTv, a.subtitle)
        playBtn?.let {
            it.glyph = if (a.playing) IslandGlyphs.PAUSE else IslandGlyphs.PLAY
            it.invalidate()
        }
        if (a.kind == IslandKind.PROGRESS) {
            val f = frac(a)
            bar?.fraction = f
            setIf(pctTv, "${(f * 100f).toInt()}%")
        }
        if (a.kind == IslandKind.CHARGE) {
            bar?.fraction = a.value / 100f
            setIf(pctTv, "${a.value}%")
        }
        if (a.kind == IslandKind.MEDIA && lastArt !== a.art) {
            art?.let { IslandUi.setArt(ctx, it, a) }
            lastArt = a.art
        }
        tick()
    }

    override fun tick() {
        val a = cur
        val tt = timeTv
        if (tt != null) {
            val s = IslandFmt.time(a, System.currentTimeMillis())
            if (s != lastTime) {
                lastTime = s
                tt.text = s
            }
        }
        if (a.kind == IslandKind.MEDIA) {
            val pd = IslandSources.position(a.key)
            if (pd != null) {
                bar?.fraction = if (pd[1] > 0L) pd[0].toFloat() / pd[1] else 0f
                posTv?.text = IslandFmt.mmss(pd[0])
                durTv?.text = IslandFmt.mmss(pd[1])
                bar?.seekEnabled = pd[2] == 1L && pd[1] > 0L
            }
        }
    }
}

internal class NotifContent(
    private val ctx: Context, dm: Dim, val item: NotifItem, val big: Boolean, width: Int, more: Int = 0
) : IslandContent(dm) {
    var hasReply = false
        private set
    private var moreView: TextView? = null

    /** "+N" chip for notifications waiting behind this one. */
    fun setMore(n: Int) {
        val v = moreView ?: return
        v.text = "+$n"
        v.visibility = if (n > 0) View.VISIBLE else View.GONE
    }

    init {
        val col = LinearLayout(ctx)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dim.dp(16f), dim.dp(14f), dim.dp(16f), dim.dp(14f))

        val top = LinearLayout(ctx)
        val iv = ImageView(ctx)
        iv.scaleType = ImageView.ScaleType.CENTER_CROP
        roundClip(iv, dim.dp(9f).toFloat())
        iv.setImageDrawable(AppIcons.icon(ctx, item.pkg))
        top.addView(iv, lpOf(dim.dp(38f), dim.dp(38f)))
        val tc = LinearLayout(ctx)
        tc.orientation = LinearLayout.VERTICAL
        val head = LinearLayout(ctx)
        head.gravity = Gravity.CENTER_VERTICAL
        val title = if (item.title.isNotBlank()) item.title else item.appName
        head.addView(mkText(ctx, dim, title, 15f, Color.WHITE, true), lpOf(0, WC, 1f))
        val mv = mkText(ctx, dim, "+$more", 11f, Color.WHITE, true)
        mv.setPadding(dim.dp(6f), dim.dp(1f), dim.dp(6f), dim.dp(1f))
        mv.background = UiKit.flat(ctx, IC.FILL18, 8f)
        mv.visibility = if (more > 0) View.VISIBLE else View.GONE
        moreView = mv
        head.addView(mv, lpOf(WC, WC).also { it.leftMargin = dim.dp(6f) })
        head.addView(mkText(ctx, dim, "bây giờ", 12f, IC.DIM), lpOf(WC, WC).also { it.leftMargin = dim.dp(8f) })
        tc.addView(head, lpOf(MP, WC))
        if (item.text.isNotBlank()) {
            val t = mkText(ctx, dim, item.text, 14f, Color.WHITE, false, if (big) 100 else 2)
            if (big) t.ellipsize = null
            tc.addView(t, lpOf(MP, WC).also { it.topMargin = dim.dp(3f) })
        }
        top.addView(tc, lpOf(0, WC, 1f).also { it.leftMargin = dim.dp(12f) })
        col.addView(top, lpOf(MP, WC))

        if (big) buildBig(col)

        root = col
        col.measure(
            View.MeasureSpec.makeMeasureSpec(width, View.MeasureSpec.EXACTLY),
            View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED)
        )
        w = width
        h = maxOf(col.measuredHeight, dim.dp(72f)).coerceAtMost((dim.screenH * 0.8f).toInt())
    }

    private fun chip(label: String, onClick: () -> Unit): TextView {
        val t = mkText(ctx, dim, label, 13f, Color.WHITE, true)
        t.gravity = Gravity.CENTER
        t.setPadding(dim.dp(12f), 0, dim.dp(12f), 0)
        t.background = FlatDrawable(IC.FILL18, dim.dp(16f).toFloat())
        t.setOnClickListener { onClick() }
        return t
    }

    private fun buildBig(col: LinearLayout) {
        val pic = item.bigPicture
        if (pic != null) {
            val iv = ImageView(ctx)
            iv.scaleType = ImageView.ScaleType.CENTER_CROP
            roundClip(iv, dim.dp(14f).toFloat())
            iv.setImageBitmap(pic)
            col.addView(iv, lpOf(MP, dim.dp(160f)).also { it.topMargin = dim.dp(10f) })
        }
        val chips = LinearLayout(ctx)
        chips.gravity = Gravity.CENTER_VERTICAL
        val otp = item.otp
        var n = 0
        fun addChip(label: String, onClick: () -> Unit) {
            val p = lpOf(WC, dim.dp(32f))
            if (n > 0) p.leftMargin = dim.dp(8f)
            chips.addView(chip(label, onClick), p)
            n++
        }
        if (otp != null) addChip("Sao chép mã $otp") {
            ItemActions.copyOtp(ctx, item)
            Island.dismissNotif()
        }
        addChip("Nhắc lại") {
            try { Snooze.snooze(ctx, item, 60) } catch (e: Throwable) { }
            Island.dismissNotif()
        }
        addChip("Tắt 1 giờ") {
            try { Rules.muteApp(ctx, item.pkg, 60) } catch (e: Throwable) { }
            Island.dismissNotif()
        }
        val hs = HorizontalScrollView(ctx)
        hs.isHorizontalScrollBarEnabled = false
        hs.addView(chips, ViewGroup.LayoutParams(WC, WC))
        col.addView(hs, lpOf(MP, WC).also { it.topMargin = dim.dp(12f) })

        var reply: NotifAction? = null
        val btns = ArrayList<Btn>()
        for (act in item.actions) {
            if (act.replyKey != null && act.remoteInputs != null) {
                if (reply == null) reply = act
                continue
            }
            if (btns.size < 3 && act.title.isNotBlank()) {
                btns.add(Btn(act.title, IC.FILL18) {
                    ItemActions.runAction(ctx, item, act, null)
                })
            }
        }
        val row = btnRow(ctx, dim, btns)
        if (row != null) col.addView(row, lpOf(MP, WC).also { it.topMargin = dim.dp(10f) })

        val ra = reply
        if (ra != null) {
            hasReply = true
            val rr = LinearLayout(ctx)
            rr.gravity = Gravity.CENTER_VERTICAL
            val et = EditText(ctx)
            et.hint = "Trả lời…"
            et.setHintTextColor(IC.DIM)
            et.setTextColor(Color.WHITE)
            et.setTextSize(TypedValue.COMPLEX_UNIT_SP, dim.sp(14f))
            et.setSingleLine(true)
            et.setPadding(dim.dp(14f), 0, dim.dp(14f), 0)
            et.background = FlatDrawable(IC.FILL18, dim.dp(20f).toFloat())
            rr.addView(et, lpOf(0, dim.dp(40f), 1f))
            val send = mkPill(ctx, dim, Btn("Gửi", UiKit.accent(ctx)) {
                val txt = et.text.toString().trim()
                if (txt.isNotEmpty()) {
                    ItemActions.runAction(ctx, item, ra, txt)
                    Island.dismissNotif()
                }
            })
            rr.addView(send, lpOf(WC, dim.dp(40f)).also { it.leftMargin = dim.dp(8f) })
            col.addView(rr, lpOf(MP, WC).also { it.topMargin = dim.dp(10f) })
        }
    }
}

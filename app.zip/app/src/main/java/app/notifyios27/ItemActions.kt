@file:Suppress("DEPRECATION")
package app.notifyios27


import android.app.ActivityOptions
import android.app.PendingIntent
import android.app.RemoteInput
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.widget.Toast

object ItemActions {

    fun runAction(c: Context, item: NotifItem, action: NotifAction, replyText: String?): Boolean {
        val pi = action.intent ?: return false
        return try {
            var fill: Intent? = null
            val key = action.replyKey
            val inputs = action.remoteInputs
            if (key != null && inputs != null && inputs.isNotEmpty() && replyText != null) {
                val results = Bundle()
                results.putCharSequence(key, replyText)
                val i = Intent()
                RemoteInput.addResultsToIntent(inputs, i, results)
                if (Build.VERSION.SDK_INT >= 28) {
                    try { RemoteInput.setResultsSource(i, RemoteInput.SOURCE_FREE_FORM_INPUT) } catch (e: Exception) { }
                }
                fill = i
            }
            if (Build.VERSION.SDK_INT >= 34) {
                val o = ActivityOptions.makeBasic()
                o.setPendingIntentBackgroundActivityStartMode(
                    ActivityOptions.MODE_BACKGROUND_ACTIVITY_START_ALLOWED
                )
                pi.send(c, 0, fill, null, null, null, o.toBundle())
            } else {
                pi.send(c, 0, fill)
            }
            true
        } catch (e: PendingIntent.CanceledException) {
            false
        } catch (e: Exception) {
            false
        }
    }

    fun copyOtp(c: Context, item: NotifItem): Boolean {
        val code = item.otp ?: return false
        if (!put(c, code)) return false
        try {
            val app = c.applicationContext
            Handler(Looper.getMainLooper()).post {
                try {
                    Toast.makeText(app, "Đã sao chép mã", Toast.LENGTH_SHORT).show()
                } catch (e: Exception) {
                }
            }
        } catch (e: Exception) {
        }
        return true
    }

    fun copyText(c: Context, text: String) {
        put(c, text)
    }

    private fun put(c: Context, text: String): Boolean {
        return try {
            val cm = c.applicationContext.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            cm.setPrimaryClip(ClipData.newPlainText("n27", text))
            true
        } catch (e: Exception) {
            false
        }
    }
}

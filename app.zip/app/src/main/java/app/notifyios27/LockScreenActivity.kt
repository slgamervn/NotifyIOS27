package app.notifyios27

import android.app.Activity
import android.graphics.Color
import android.graphics.Typeface
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.TextUtils
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import java.util.Calendar
import java.util.Locale

class LockScreenActivity : Activity() {
    private val handler = Handler(Looper.getMainLooper())
    private lateinit var timeView: TextView
    private lateinit var dateView: TextView
    private lateinit var scroll: ScrollView
    private lateinit var list: LinearLayout
    private var downY = 0f
    private var downT = 0L
    private var tracking = false
    private var canScrollAtDown = false

    private val refresher: () -> Unit = {
        runOnUiThread {
            if (!isFinishing && !isDestroyed) rebuild()
        }
    }

    private val tick = object : Runnable {
        override fun run() {
            updateClock()
            handler.postDelayed(this, 15000L)
        }
    }

    private fun dp(v: Int): Int = UiKit.dp(this, v)

    @Suppress("DEPRECATION")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= 27) {
            setShowWhenLocked(true)
            setTurnScreenOn(true)
        } else {
            window.addFlags(
                WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or
                    WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON
            )
        }
        if (Prefs.lockKeepScreenOn) {
            window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        }

        val match = ViewGroup.LayoutParams.MATCH_PARENT
        val wrap = ViewGroup.LayoutParams.WRAP_CONTENT
        val compact = Prefs.lockClockMode == 1

        val root = FrameLayout(this)
        root.background = UiKit.wallpaper(this)
        val scrim = View(this)
        scrim.setBackgroundColor(Color.argb(40, 0, 0, 0))
        root.addView(scrim, FrameLayout.LayoutParams(match, match))

        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        root.addView(col, FrameLayout.LayoutParams(match, match))

        timeView = TextView(this)
        timeView.setTextColor(Color.WHITE)
        timeView.includeFontPadding = false
        timeView.setShadowLayer(8f, 0f, 2f, Color.argb(90, 0, 0, 0))
        dateView = TextView(this)
        dateView.setTextColor(Color.WHITE)
        dateView.setShadowLayer(8f, 0f, 2f, Color.argb(90, 0, 0, 0))

        val head = LinearLayout(this)
        head.orientation = LinearLayout.VERTICAL
        if (compact) {
            timeView.textSize = 34f * clockScale()
            timeView.typeface = Typeface.create("sans-serif-light", Typeface.NORMAL)
            dateView.textSize = 15f * clockScale()
            dateView.typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
            head.gravity = Gravity.START
            head.setPadding(dp(20), dp(12), dp(20), dp(8))
            head.addView(timeView, LinearLayout.LayoutParams(wrap, wrap))
            head.addView(dateView, LinearLayout.LayoutParams(wrap, wrap))
        } else {
            timeView.textSize = 84f * clockScale()
            timeView.typeface = Typeface.create("sans-serif-thin", Typeface.NORMAL)
            dateView.textSize = 20f * clockScale()
            dateView.typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
            head.gravity = Gravity.CENTER_HORIZONTAL
            head.setPadding(dp(20), if (UiKit.isLandscape(this)) dp(8) else dp(36), dp(20), dp(if (UiKit.isLandscape(this)) 8 else 20))
            head.addView(dateView, LinearLayout.LayoutParams(wrap, wrap))
            head.addView(timeView, LinearLayout.LayoutParams(wrap, wrap))
        }
        col.addView(head, LinearLayout.LayoutParams(match, wrap))

        scroll = ScrollView(this)
        scroll.isVerticalScrollBarEnabled = false
        scroll.overScrollMode = View.OVER_SCROLL_NEVER
        list = N27MaxWidthColumn(this, 640)
        list.setPadding(dp(16), dp(4), dp(16), dp(12))
        scroll.addView(list, FrameLayout.LayoutParams(match, wrap, Gravity.CENTER_HORIZONTAL))
        col.addView(scroll, LinearLayout.LayoutParams(match, 0, 1f))

        val hint = TextView(this)
        hint.text = "Vuốt lên để đóng"
        hint.textSize = 13f
        hint.gravity = Gravity.CENTER
        hint.setTextColor(Color.argb(170, 255, 255, 255))
        hint.setPadding(0, dp(8), 0, dp(10))
        col.addView(hint, LinearLayout.LayoutParams(match, wrap))

        setContentView(root)
        UiKit.edgeToEdge(this, root, true) { l, t, r, b -> col.setPadding(l, t, r, b) }
        updateClock()
    }

    // clock sizes follow the smaller screen side so nothing overflows in landscape
    private fun clockScale(): Float {
        val smallDp = UiKit.smallSide(this) / resources.displayMetrics.density
        return (smallDp / 400f).coerceIn(0.6f, 1.3f)
    }

    override fun onConfigurationChanged(newConfig: android.content.res.Configuration) {
        super.onConfigurationChanged(newConfig)
        try {
            val compact = Prefs.lockClockMode == 1
            timeView.textSize = (if (compact) 34f else 84f) * clockScale()
            dateView.textSize = (if (compact) 15f else 20f) * clockScale()
            window.decorView.requestApplyInsets()
        } catch (e: Throwable) {
        }
    }

    private fun updateClock() {
        val cal = Calendar.getInstance()
        timeView.text = String.format(
            Locale.ROOT, "%d:%02d", cal.get(Calendar.HOUR_OF_DAY), cal.get(Calendar.MINUTE)
        )
        val dow = DAYS[(cal.get(Calendar.DAY_OF_WEEK) - 1).coerceIn(0, 6)]
        dateView.text = "$dow, ${cal.get(Calendar.DAY_OF_MONTH)} tháng ${cal.get(Calendar.MONTH) + 1}"
    }

    private fun rebuild() {
        list.removeAllViews()
        val items: List<NotifItem> = try { NotifStore.all() } catch (e: Throwable) { emptyList() }
        if (items.isEmpty()) {
            val t = TextView(this)
            t.text = "Không có thông báo"
            t.textSize = 16f
            t.gravity = Gravity.CENTER
            t.setTextColor(Color.argb(190, 255, 255, 255))
            t.setPadding(0, dp(40), 0, dp(40))
            list.addView(t, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
            return
        }
        val dark = Prefs.isDark(this)
        for (item in items) {
            val v = card(item, dark)
            val p = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            p.bottomMargin = dp(8)
            list.addView(v, p)
        }
    }

    private fun card(item: NotifItem, dark: Boolean): View {
        val wrap = ViewGroup.LayoutParams.WRAP_CONTENT
        val c = LinearLayout(this)
        c.orientation = LinearLayout.HORIZONTAL
        c.background = UiKit.glass(this, 22f)
        c.setPadding(dp(14), dp(12), dp(14), dp(12))

        val icon = UiKit.iconView(this, item.pkg, 38)
        c.addView(icon, LinearLayout.LayoutParams(dp(38), dp(38)))

        val body = LinearLayout(this)
        body.orientation = LinearLayout.VERTICAL
        val bp = LinearLayout.LayoutParams(0, wrap, 1f)
        bp.leftMargin = dp(12)
        c.addView(body, bp)

        val top = LinearLayout(this)
        top.orientation = LinearLayout.HORIZONTAL
        val app = TextView(this)
        app.text = item.appName
        app.textSize = 12f
        app.maxLines = 1
        app.ellipsize = TextUtils.TruncateAt.END
        app.setTextColor(UiKit.secondary(dark))
        top.addView(app, LinearLayout.LayoutParams(0, wrap, 1f))
        val time = TextView(this)
        time.text = UiKit.relativeTime(item.time)
        time.textSize = 12f
        time.setTextColor(UiKit.secondary(dark))
        top.addView(time, LinearLayout.LayoutParams(wrap, wrap))
        body.addView(top, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, wrap))

        if (item.title.isNotBlank()) {
            val t = TextView(this)
            t.text = item.title
            t.textSize = 15f
            t.typeface = Typeface.DEFAULT_BOLD
            t.maxLines = 1
            t.ellipsize = TextUtils.TruncateAt.END
            t.setTextColor(UiKit.primary(dark))
            body.addView(t, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, wrap))
        }
        if (item.text.isNotBlank()) {
            val x = TextView(this)
            x.text = item.text
            x.textSize = 14f
            x.maxLines = 2
            x.ellipsize = TextUtils.TruncateAt.END
            x.setTextColor(UiKit.primary(dark))
            body.addView(x, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, wrap))
        }

        c.setOnClickListener {
            NotifStore.open(this, item)
            finish()
        }
        return c
    }

    override fun dispatchTouchEvent(ev: MotionEvent?): Boolean {
        if (ev != null) {
            when (ev.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    downY = ev.rawY
                    downT = ev.eventTime
                    tracking = true
                    canScrollAtDown = scroll.canScrollVertically(1)
                }
                MotionEvent.ACTION_UP -> {
                    val swipe = tracking && !canScrollAtDown &&
                        downY - ev.rawY > dp(140) && ev.eventTime - downT < 500L
                    tracking = false
                    if (swipe) {
                        finish()
                        return true
                    }
                }
                MotionEvent.ACTION_CANCEL -> tracking = false
            }
        }
        return super.dispatchTouchEvent(ev)
    }

    override fun onResume() {
        super.onResume()
        NotifStore.addListener(refresher)
        rebuild()
        handler.removeCallbacks(tick)
        handler.post(tick)
    }

    override fun onPause() {
        NotifStore.removeListener(refresher)
        handler.removeCallbacks(tick)
        super.onPause()
    }

    companion object {
        private val DAYS = arrayOf(
            "Chủ nhật", "Thứ Hai", "Thứ Ba", "Thứ Tư", "Thứ Năm", "Thứ Sáu", "Thứ Bảy"
        )
    }
}

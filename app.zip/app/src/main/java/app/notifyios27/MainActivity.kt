package app.notifyios27

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.text.TextUtils
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.ViewGroup
import android.view.animation.DecelerateInterpolator
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

class MainActivity : Activity() {
    private val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
    private val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT

    private val handler = Handler(Looper.getMainLooper())
    private var dark = false
    private lateinit var root: FrameLayout
    private lateinit var dateText: TextView
    private lateinit var clearBtn: TextView
    private lateinit var permHolder: LinearLayout
    private lateinit var listHolder: LinearLayout
    private lateinit var emptyText: TextView

    private val expanded = HashSet<String>()
    private var knownKeys = HashSet<String>()
    private var initialized = false
    private var confirmClear = false
    private val timeViews = ArrayList<Pair<TextView, Long>>()

    private val listener: () -> Unit = { refresh() }
    private val ticker = object : Runnable {
        override fun run() {
            updateTimes()
            handler.postDelayed(this, 30000L)
        }
    }
    private val resetConfirm = Runnable {
        confirmClear = false
        updateClearBtn()
    }

    private fun dp(v: Int): Int = UiKit.dp(this, v)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Prefs.init(applicationContext)
        dark = Prefs.isDark(this)
        buildUi()
    }

    private fun buildUi() {
        val ctx: Context = this
        root = FrameLayout(ctx)
        root.background = UiKit.wallpaper(dark)

        val scroll = ScrollView(ctx)
        scroll.isVerticalScrollBarEnabled = false
        scroll.clipToPadding = false
        scroll.overScrollMode = View.OVER_SCROLL_NEVER

        val content = LinearLayout(ctx)
        content.orientation = LinearLayout.VERTICAL
        content.setPadding(dp(16), dp(12), dp(16), dp(40))

        dateText = TextView(ctx)
        dateText.textSize = 14f
        dateText.setTextColor(UiKit.secondary(dark))
        content.addView(dateText, LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(8) })

        val titleRow = LinearLayout(ctx)
        titleRow.orientation = LinearLayout.HORIZONTAL
        titleRow.gravity = Gravity.CENTER_VERTICAL
        val title = TextView(ctx)
        title.text = "Trung tâm thông báo"
        title.textSize = 30f
        title.typeface = Typeface.DEFAULT_BOLD
        title.setTextColor(UiKit.primary(dark))
        titleRow.addView(title, LinearLayout.LayoutParams(0, WRAP, 1f))

        clearBtn = circleButton("✕")
        clearBtn.visibility = View.GONE
        clearBtn.setOnClickListener {
            if (!confirmClear) {
                confirmClear = true
                updateClearBtn()
                handler.removeCallbacks(resetConfirm)
                handler.postDelayed(resetConfirm, 4000L)
            } else {
                confirmClear = false
                handler.removeCallbacks(resetConfirm)
                clearAll()
            }
        }
        titleRow.addView(clearBtn, LinearLayout.LayoutParams(WRAP, WRAP).apply { leftMargin = dp(8) })

        val gear = circleButton("⚙")
        gear.setOnClickListener { startActivity(Intent(ctx, SettingsActivity::class.java)) }
        titleRow.addView(gear, LinearLayout.LayoutParams(WRAP, WRAP).apply { leftMargin = dp(8) })
        content.addView(titleRow, LinearLayout.LayoutParams(MATCH, WRAP).apply {
            topMargin = dp(2)
            bottomMargin = dp(16)
        })

        permHolder = LinearLayout(ctx)
        permHolder.orientation = LinearLayout.VERTICAL
        content.addView(permHolder, LinearLayout.LayoutParams(MATCH, WRAP).apply { bottomMargin = dp(12) })

        listHolder = LinearLayout(ctx)
        listHolder.orientation = LinearLayout.VERTICAL
        content.addView(listHolder, LinearLayout.LayoutParams(MATCH, WRAP))

        emptyText = TextView(ctx)
        emptyText.text = "Không có thông báo"
        emptyText.textSize = 17f
        emptyText.gravity = Gravity.CENTER
        emptyText.setTextColor(UiKit.secondary(dark))
        emptyText.setPadding(0, dp(80), 0, 0)
        content.addView(emptyText, LinearLayout.LayoutParams(MATCH, WRAP))

        scroll.addView(content, ViewGroup.LayoutParams(MATCH, WRAP))
        root.addView(scroll, FrameLayout.LayoutParams(MATCH, MATCH))
        setContentView(root)
        UiKit.edgeToEdge(this, root, dark) { l, t, r, b -> scroll.setPadding(l, t, r, b) }
    }

    private fun circleButton(text: String): TextView {
        val t = TextView(this)
        t.text = text
        t.textSize = 16f
        t.typeface = Typeface.DEFAULT_BOLD
        t.gravity = Gravity.CENTER
        t.minWidth = dp(40)
        t.minHeight = dp(40)
        t.setPadding(dp(10), 0, dp(10), 0)
        t.setTextColor(UiKit.primary(dark))
        t.background = UiKit.glass(this, 20f)
        return t
    }

    private fun updateClearBtn() {
        clearBtn.text = if (confirmClear) "Xóa tất cả" else "✕"
        clearBtn.setTextColor(if (confirmClear) UiKit.RED else UiKit.primary(dark))
    }

    override fun onResume() {
        super.onResume()
        if (Prefs.isDark(this) != dark) {
            recreate()
            return
        }
        updateDate()
        NotifStore.addListener(listener)
        refresh()
        handler.removeCallbacks(ticker)
        handler.postDelayed(ticker, 30000L)
    }

    override fun onPause() {
        super.onPause()
        NotifStore.removeListener(listener)
        handler.removeCallbacks(ticker)
        handler.removeCallbacks(resetConfirm)
        confirmClear = false
    }

    private fun updateDate() {
        val s = SimpleDateFormat("EEEE, d MMMM", Locale.forLanguageTag("vi")).format(Date())
        dateText.text = s.replaceFirstChar { it.uppercase() }
    }

    private fun updateTimes() {
        for ((tv, t) in timeViews) tv.text = UiKit.relativeTime(t)
    }

    private fun refresh() {
        val items = NotifStore.all().sortedByDescending { it.time }
        updatePermCard()
        timeViews.clear()
        listHolder.removeAllViews()

        val groups = LinkedHashMap<String, MutableList<NotifItem>>()
        for (i in items) groups.getOrPut(i.pkg) { ArrayList() }.add(i)
        expanded.retainAll(groups.keys)

        for ((pkg, list) in groups) addGroup(pkg, list)

        val current = HashSet<String>()
        for (i in items) current.add(i.key)
        knownKeys = current
        initialized = true

        emptyText.visibility = if (items.isEmpty()) View.VISIBLE else View.GONE
        clearBtn.visibility = if (items.size >= 2) View.VISIBLE else View.GONE
        if (items.size < 2) confirmClear = false
        updateClearBtn()
    }

    private fun isNew(key: String): Boolean = initialized && !knownKeys.contains(key)

    private fun slideIn(v: View) {
        val w = resources.displayMetrics.widthPixels.toFloat()
        v.translationX = -w
        v.alpha = 0f
        v.animate().translationX(0f).alpha(1f).setDuration(380L)
            .setInterpolator(DecelerateInterpolator()).start()
    }

    private fun rowLp(): LinearLayout.LayoutParams =
        LinearLayout.LayoutParams(MATCH, WRAP).apply { bottomMargin = dp(10) }

    private fun addGroup(pkg: String, list: List<NotifItem>) {
        if (list.size == 1 || expanded.contains(pkg)) {
            for (item in list) {
                val row = makeRow(item)
                listHolder.addView(row, rowLp())
                if (isNew(item.key)) slideIn(row)
            }
            if (list.size > 1) {
                val pill = TextView(this)
                pill.text = "Thu gọn"
                pill.textSize = 14f
                pill.typeface = Typeface.DEFAULT_BOLD
                pill.setTextColor(UiKit.primary(dark))
                pill.gravity = Gravity.CENTER
                pill.setPadding(dp(18), dp(8), dp(18), dp(8))
                pill.background = UiKit.glass(this, 20f)
                pill.setOnClickListener {
                    expanded.remove(pkg)
                    refresh()
                }
                listHolder.addView(pill, LinearLayout.LayoutParams(WRAP, WRAP).apply {
                    gravity = Gravity.CENTER_HORIZONTAL
                    bottomMargin = dp(10)
                })
            }
        } else {
            val stack = makeStack(pkg, list)
            listHolder.addView(stack, rowLp())
            if (isNew(list[0].key)) slideIn(stack)
        }
        listHolder.addView(View(this), LinearLayout.LayoutParams(MATCH, dp(8)))
    }

    private fun makeStack(pkg: String, list: List<NotifItem>): View {
        val ctx: Context = this
        val f = FrameLayout(ctx)
        val l2 = View(ctx)
        l2.background = UiKit.glass(ctx, 24f, 0.7f)
        f.addView(l2, FrameLayout.LayoutParams(MATCH, dp(14)).apply {
            gravity = Gravity.BOTTOM
            leftMargin = dp(24)
            rightMargin = dp(24)
        })
        val l1 = View(ctx)
        l1.background = UiKit.glass(ctx, 24f, 0.85f)
        f.addView(l1, FrameLayout.LayoutParams(MATCH, dp(14)).apply {
            gravity = Gravity.BOTTOM
            bottomMargin = dp(8)
            leftMargin = dp(12)
            rightMargin = dp(12)
        })
        val card = makeCardView(list[0])
        card.setOnClickListener {
            expanded.add(pkg)
            refresh()
        }
        f.addView(card, FrameLayout.LayoutParams(MATCH, WRAP).apply {
            gravity = Gravity.TOP
            bottomMargin = dp(16)
        })
        return f
    }

    private fun makeRow(item: NotifItem): View {
        val ctx: Context = this
        val card = makeCardView(item)
        val del = TextView(ctx)
        del.text = "Xóa"
        del.textSize = 15f
        del.typeface = Typeface.DEFAULT_BOLD
        del.setTextColor(Color.WHITE)
        del.gravity = Gravity.CENTER
        del.background = UiKit.rounded(ctx, UiKit.RED, 24f)
        return N27SwipeRow(ctx, card, del, { NotifStore.open(ctx, item) }, { clearItem(item) })
    }

    private fun makeCardView(item: NotifItem): LinearLayout {
        val ctx: Context = this
        val sec = UiKit.secondary(dark)
        val prim = UiKit.primary(dark)
        val card = LinearLayout(ctx)
        card.orientation = LinearLayout.HORIZONTAL
        card.setPadding(dp(14), dp(12), dp(14), dp(12))
        card.background = UiKit.glass(ctx, 24f)
        card.addView(UiKit.iconView(ctx, item.pkg, 40), LinearLayout.LayoutParams(dp(40), dp(40)))

        val col = LinearLayout(ctx)
        col.orientation = LinearLayout.VERTICAL
        val top = LinearLayout(ctx)
        top.orientation = LinearLayout.HORIZONTAL
        top.gravity = Gravity.CENTER_VERTICAL

        val name = TextView(ctx)
        name.text = if (item.appName.isBlank()) AppIcons.label(ctx, item.pkg) else item.appName
        name.textSize = 12.5f
        name.setTextColor(sec)
        name.maxLines = 1
        name.ellipsize = TextUtils.TruncateAt.END
        top.addView(name, LinearLayout.LayoutParams(0, WRAP, 1f))

        if (item.timeSensitive) {
            val u = TextView(ctx)
            u.text = "Khẩn cấp"
            u.textSize = 11f
            u.typeface = Typeface.DEFAULT_BOLD
            u.setTextColor(UiKit.ORANGE)
            u.setPadding(dp(6), dp(1), dp(6), dp(1))
            u.background = UiKit.rounded(ctx, Color.argb(45, 255, 159, 10), 8f)
            top.addView(u, LinearLayout.LayoutParams(WRAP, WRAP).apply { leftMargin = dp(6) })
        }
        val time = TextView(ctx)
        time.text = UiKit.relativeTime(item.time)
        time.textSize = 12.5f
        time.setTextColor(sec)
        timeViews.add(Pair(time, item.time))
        top.addView(time, LinearLayout.LayoutParams(WRAP, WRAP).apply { leftMargin = dp(6) })
        col.addView(top, LinearLayout.LayoutParams(MATCH, WRAP))

        if (item.title.isNotBlank()) {
            val t = TextView(ctx)
            t.text = item.title
            t.textSize = 15f
            t.typeface = Typeface.DEFAULT_BOLD
            t.setTextColor(prim)
            t.maxLines = 1
            t.ellipsize = TextUtils.TruncateAt.END
            col.addView(t, LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(2) })
        }
        if (item.text.isNotBlank()) {
            val t = TextView(ctx)
            t.text = item.text
            t.textSize = 14f
            t.setTextColor(prim)
            t.maxLines = 3
            t.ellipsize = TextUtils.TruncateAt.END
            col.addView(t, LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(1) })
        }
        card.addView(col, LinearLayout.LayoutParams(0, WRAP, 1f).apply { leftMargin = dp(12) })
        return card
    }

    private fun clearItem(item: NotifItem) {
        NotifStore.remove(item.key)
        if (Prefs.syncClear) N27ListenerService.instance?.cancelNotification(item.key)
        refresh()
    }

    private fun clearAll() {
        val keys = NotifStore.all().map { it.key }
        NotifStore.clearAll()
        if (Prefs.syncClear) {
            val svc = N27ListenerService.instance
            for (k in keys) svc?.cancelNotification(k)
        }
        refresh()
    }

    private fun updatePermCard() {
        val ctx: Context = this
        permHolder.removeAllViews()
        val notif = UiKit.notifAccessGranted(ctx)
        val overlay = Settings.canDrawOverlays(ctx)
        if (notif && overlay) {
            permHolder.visibility = View.GONE
            return
        }
        permHolder.visibility = View.VISIBLE
        val card = LinearLayout(ctx)
        card.orientation = LinearLayout.VERTICAL
        card.setPadding(dp(16), dp(14), dp(16), dp(14))
        card.background = UiKit.glass(ctx, 24f)

        val t = TextView(ctx)
        t.text = "Cần cấp quyền"
        t.textSize = 17f
        t.typeface = Typeface.DEFAULT_BOLD
        t.setTextColor(UiKit.primary(dark))
        card.addView(t)
        val d = TextView(ctx)
        d.text = "Cho phép truy cập thông báo và hiển thị trên ứng dụng khác để notifyIOS27 hoạt động. " +
            "Nếu công tắc bị mờ, xem hướng dẫn trong Cài đặt của ứng dụng."
        d.textSize = 13.5f
        d.setTextColor(UiKit.secondary(dark))
        card.addView(d, LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(4) })

        if (!notif) {
            val b = UiKit.pillButton(ctx, "Cấp quyền truy cập thông báo", true)
            b.setOnClickListener { UiKit.openNotifAccess(ctx) }
            card.addView(b, LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(10) })
        }
        if (!overlay) {
            val b = UiKit.pillButton(ctx, "Cấp quyền hiển thị trên ứng dụng khác", true)
            b.setOnClickListener { UiKit.openOverlay(ctx) }
            card.addView(b, LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(10) })
        }
        permHolder.addView(card, LinearLayout.LayoutParams(MATCH, WRAP))
    }
}

/** A card that can be swiped left: short swipe reveals "Xóa", long swipe clears; tap calls onTap. */
private class N27SwipeRow(
    ctx: Context,
    private val card: View,
    private val del: View,
    private val onTap: () -> Unit,
    private val onClear: () -> Unit
) : FrameLayout(ctx) {
    private val slop = ViewConfiguration.get(ctx).scaledTouchSlop
    private val revealW = UiKit.dp(ctx, 88)
    private var downX = 0f
    private var downY = 0f
    private var startTx = 0f
    private var dragging = false
    private var done = false

    init {
        addView(del, FrameLayout.LayoutParams(revealW, ViewGroup.LayoutParams.MATCH_PARENT, Gravity.END))
        addView(card, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        del.visibility = View.INVISIBLE
        del.setOnClickListener { dismiss() }
    }

    private fun syncDel() {
        val t = card.translationX
        if (t < 0f) {
            del.visibility = View.VISIBLE
            val w = max(revealW, (-t).toInt())
            val lp = del.layoutParams
            if (lp.width != w) {
                lp.width = w
                del.layoutParams = lp
            }
            del.alpha = min(1f, -t / revealW)
        } else {
            del.visibility = View.INVISIBLE
        }
    }

    private fun animateTo(target: Float) {
        card.animate().translationX(target).setDuration(160L)
            .setUpdateListener { syncDel() }
            .withEndAction { syncDel() }
            .start()
    }

    private fun dismiss() {
        if (done) return
        done = true
        card.animate().translationX(-width.toFloat()).setDuration(160L)
            .setUpdateListener { syncDel() }
            .withEndAction { onClear() }
            .start()
    }

    private fun settle() {
        val t = card.translationX
        if (t < -width * 0.55f) dismiss()
        else if (t < -revealW * 0.5f) animateTo(-revealW.toFloat())
        else animateTo(0f)
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                downX = e.rawX
                downY = e.rawY
                startTx = card.translationX
                dragging = false
                return true
            }
            MotionEvent.ACTION_MOVE -> {
                val dx = e.rawX - downX
                val dy = e.rawY - downY
                if (!dragging && abs(dx) > slop && abs(dx) > abs(dy)) {
                    dragging = true
                    parent?.requestDisallowInterceptTouchEvent(true)
                }
                if (dragging && !done) {
                    card.translationX = min(0f, startTx + dx)
                    syncDel()
                }
                return true
            }
            MotionEvent.ACTION_UP -> {
                if (dragging) {
                    settle()
                } else if (abs(e.rawX - downX) < slop && abs(e.rawY - downY) < slop) {
                    if (card.translationX < -1f) animateTo(0f) else onTap()
                }
                dragging = false
                return true
            }
            MotionEvent.ACTION_CANCEL -> {
                if (dragging) settle()
                dragging = false
                return true
            }
        }
        return super.onTouchEvent(e)
    }
}

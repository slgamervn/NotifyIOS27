package app.notifyios27

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.res.Configuration
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : Activity() {
    private val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
    private val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT

    private val handler = Handler(Looper.getMainLooper())
    private var dark = false
    private var tabIndex = 0
    private lateinit var root: FrameLayout
    private lateinit var dateText: TextView
    private lateinit var badge: TextView
    private lateinit var focusChip: TextView
    private lateinit var clearBtn: TextView
    private lateinit var permHolder: LinearLayout
    private lateinit var tabHolder: LinearLayout
    private lateinit var segWrap: LinearLayout
    private val segViews = ArrayList<TextView>()
    private val railViews = ArrayList<TextView>()
    private var rail: LinearLayout? = null
    private lateinit var scrollView: ScrollView
    private var pendingScroll = 0
    private val railDp = 72
    private lateinit var tabs: List<N27Tab>
    private var confirmClear = false

    private val refreshRun = Runnable { refreshAll() }
    private val listener: () -> Unit = {
        handler.removeCallbacks(refreshRun)
        handler.post(refreshRun)
    }
    private val focusListener: () -> Unit = {
        handler.post { updateFocusChip() }
    }
    private val ticker = object : Runnable {
        override fun run() {
            tabs[tabIndex].onTick()
            handler.postDelayed(this, 30000L)
        }
    }
    private val resetConfirm = Runnable {
        confirmClear = false
        updateClearBtn()
    }

    companion object {
        const val EXTRA_OPEN_CC = "open_cc"

        @Volatile
        private var onboardingShown = false
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        if (intent.getBooleanExtra(EXTRA_OPEN_CC, false)) {
            handler.post { ControlCenter.showInApp(this) }
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (ControlCenter.closeInApp()) return
        @Suppress("DEPRECATION")
        super.onBackPressed()
    }

    private fun dp(v: Int): Int = UiKit.dp(this, v)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Prefs.init(applicationContext)
        UpdateChecker.check(this)
        dark = Prefs.isDark(this)
        tabIndex = savedInstanceState?.getInt("tab", 0)?.coerceIn(0, 2) ?: 0
        tabs = listOf(RecentTab(this), HistoryTab(this), StatsTab(this))
        pendingScroll = savedInstanceState?.getInt("scrollY", 0) ?: 0
        buildUi()
        if (intent?.getBooleanExtra(EXTRA_OPEN_CC, false) == true && savedInstanceState == null) {
            handler.post { ControlCenter.showInApp(this) }
        }
        if (pendingScroll > 0) {
            val y = pendingScroll
            pendingScroll = 0
            scrollView.post { try { scrollView.scrollTo(0, y) } catch (e: Throwable) { } }
        }
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        try {
            if (Prefs.isDark(this) != dark) {
                recreate()
                return
            }
            val sy = scrollView.scrollY
            tabHolder.removeAllViews()
            segViews.clear()
            railViews.clear()
            buildUi()
            refreshChrome()
            scrollView.post { try { scrollView.scrollTo(0, sy) } catch (e: Throwable) { } }
        } catch (e: Throwable) {
        }
    }

    private fun refreshChrome() {
        root.background = UiKit.wallpaper(this)
        updateDate()
        updateFocusChip()
        styleSegments()
        updatePermCard()
        updateHeader()
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        outState.putInt("tab", tabIndex)
        try { outState.putInt("scrollY", scrollView.scrollY) } catch (e: Throwable) { }
    }

    private fun buildUi() {
        val ctx: Context = this
        root = FrameLayout(ctx)
        root.background = UiKit.wallpaper(ctx)

        val land = UiKit.isLandscape(ctx)
        val scroll = ScrollView(ctx)
        scrollView = scroll
        scroll.isVerticalScrollBarEnabled = false
        scroll.clipToPadding = false
        scroll.overScrollMode = View.OVER_SCROLL_NEVER
        scroll.isFillViewport = false

        val content = N27MaxWidthColumn(ctx, 640)
        content.setPadding(dp(16), dp(12), dp(16), dp(40))

        dateText = TextView(ctx)
        dateText.textSize = 14f
        dateText.setTextColor(UiKit.secondary(dark))
        content.addView(dateText, LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(8) })

        val titleRow = LinearLayout(ctx)
        titleRow.orientation = LinearLayout.HORIZONTAL
        titleRow.gravity = Gravity.CENTER_VERTICAL
        val title = TextView(ctx)
        title.text = "Trung tâm thông báo"
        title.textSize = 28f
        title.typeface = Typeface.DEFAULT_BOLD
        title.setTextColor(UiKit.primary(dark))
        titleRow.addView(title, LinearLayout.LayoutParams(0, WRAP, 1f))

        badge = TextView(ctx)
        badge.textSize = 13f
        badge.typeface = Typeface.DEFAULT_BOLD
        badge.setTextColor(Color.WHITE)
        badge.gravity = Gravity.CENTER
        badge.minWidth = dp(24)
        badge.setPadding(dp(8), dp(2), dp(8), dp(2))
        badge.visibility = View.GONE
        titleRow.addView(badge, LinearLayout.LayoutParams(WRAP, WRAP).apply { leftMargin = dp(8) })
        content.addView(titleRow, LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(2) })

        val btnRow = LinearLayout(ctx)
        btnRow.orientation = LinearLayout.HORIZONTAL
        btnRow.gravity = Gravity.CENTER_VERTICAL
        focusChip = TextView(ctx)
        focusChip.textSize = 14f
        focusChip.typeface = Typeface.DEFAULT_BOLD
        focusChip.gravity = Gravity.CENTER
        focusChip.maxLines = 1
        focusChip.ellipsize = android.text.TextUtils.TruncateAt.END
        focusChip.minHeight = dp(40)
        focusChip.setPadding(dp(14), 0, dp(14), 0)
        focusChip.setOnClickListener { showFocusDialog() }
        btnRow.addView(focusChip, LinearLayout.LayoutParams(0, WRAP, 1f).apply { rightMargin = dp(8) })

        clearBtn = circleButton("")
        N27Icons.set(clearBtn, N27Icons.CLOSE, UiKit.primary(dark))
        clearBtn.visibility = View.GONE
        clearBtn.setOnClickListener {
            if (!confirmClear) {
                confirmClear = true
                updateClearBtn()
                handler.removeCallbacks(resetConfirm)
                handler.postDelayed(resetConfirm, 4000L)
            } else {
                confirmClear = false
                handler.removeCallbacks(resetConfirm)
                clearAll()
            }
        }
        btnRow.addView(clearBtn, LinearLayout.LayoutParams(WRAP, WRAP).apply { leftMargin = dp(8) })

        val cc = circleButton("")
        cc.setCompoundDrawablesWithIntrinsicBounds(CcIcon(ctx, UiKit.primary(dark)), null, null, null)
        cc.setOnClickListener { ControlCenter.showInApp(this) }
        btnRow.addView(cc, LinearLayout.LayoutParams(WRAP, WRAP).apply { leftMargin = dp(8) })

        val lock = circleButton("")
        N27Icons.set(lock, N27Icons.LOCK, UiKit.primary(dark))
        lock.setOnClickListener {
            try { startActivity(Intent(ctx, LockScreenActivity::class.java)) } catch (e: Exception) { }
        }
        btnRow.addView(lock, LinearLayout.LayoutParams(WRAP, WRAP).apply { leftMargin = dp(8) })

        val power = circleButton("")
        fun stylePower() {
            N27Icons.set(power, N27Icons.POWER, if (Prefs.appEnabled) UiKit.GREEN else UiKit.RED)
        }
        stylePower()
        power.setOnClickListener {
            Prefs.appEnabled = !Prefs.appEnabled
            if (!Prefs.appEnabled) AppSwitch.stopAll(ctx)
            stylePower()
            try {
                android.widget.Toast.makeText(
                    ctx, if (Prefs.appEnabled) "Đã bật notifyIOS27" else "Đã tắt notifyIOS27",
                    android.widget.Toast.LENGTH_SHORT
                ).show()
            } catch (e: Exception) { }
        }
        btnRow.addView(power, LinearLayout.LayoutParams(WRAP, WRAP).apply { leftMargin = dp(8) })

        val gear = circleButton("")
        N27Icons.set(gear, N27Icons.GEAR, UiKit.primary(dark))
        gear.setOnClickListener {
            try { startActivity(Intent(ctx, SettingsActivity::class.java)) } catch (e: Exception) { }
        }
        btnRow.addView(gear, LinearLayout.LayoutParams(WRAP, WRAP).apply { leftMargin = dp(8) })
        content.addView(btnRow, LinearLayout.LayoutParams(MATCH, WRAP).apply {
            topMargin = dp(12)
            bottomMargin = dp(14)
        })

        segWrap = LinearLayout(ctx)
        segWrap.orientation = LinearLayout.HORIZONTAL
        segWrap.setPadding(dp(3), dp(3), dp(3), dp(3))
        val names = listOf("Gần đây", "Lịch sử", "Thống kê")
        for ((i, n) in names.withIndex()) {
            val tv = TextView(ctx)
            tv.text = n
            tv.textSize = 14f
            tv.gravity = Gravity.CENTER
            tv.setPadding(0, dp(8), 0, dp(8))
            tv.setOnClickListener { selectTab(i) }
            segViews.add(tv)
            segWrap.addView(tv, LinearLayout.LayoutParams(0, WRAP, 1f))
        }
        if (!land) {
            content.addView(segWrap, LinearLayout.LayoutParams(MATCH, WRAP).apply { bottomMargin = dp(14) })
        }

        permHolder = LinearLayout(ctx)
        permHolder.orientation = LinearLayout.VERTICAL
        content.addView(permHolder, LinearLayout.LayoutParams(MATCH, WRAP).apply { bottomMargin = dp(12) })

        tabHolder = LinearLayout(ctx)
        tabHolder.orientation = LinearLayout.VERTICAL
        tabHolder.addView(tabs[tabIndex].view, LinearLayout.LayoutParams(MATCH, WRAP))
        content.addView(tabHolder, LinearLayout.LayoutParams(MATCH, WRAP))

        scroll.addView(content, FrameLayout.LayoutParams(MATCH, WRAP, Gravity.CENTER_HORIZONTAL))
        root.addView(scroll, FrameLayout.LayoutParams(MATCH, MATCH))

        var railView: LinearLayout? = null
        if (land) {
            val rv = LinearLayout(ctx)
            rv.orientation = LinearLayout.VERTICAL
            rv.gravity = Gravity.CENTER_VERTICAL
            rv.background = UiKit.glass(ctx, 0f)
            val icons = listOf(N27Icons.BELL, N27Icons.CLOCK, N27Icons.CHART)
            val names = listOf("Gần đây", "Lịch sử", "Thống kê")
            for (i in 0 until 3) {
                val tv = TextView(ctx)
                tv.text = names[i]
                tv.textSize = 11f
                tv.gravity = Gravity.CENTER
                tv.setPadding(0, dp(10), 0, dp(10))
                tv.setOnClickListener { selectTab(i) }
                railViews.add(tv)
                N27Icons.setTop(tv, icons[i], UiKit.primary(dark))
                rv.addView(tv, LinearLayout.LayoutParams(MATCH, WRAP).apply {
                    leftMargin = dp(4)
                    rightMargin = dp(4)
                    topMargin = dp(4)
                    bottomMargin = dp(4)
                })
            }
            root.addView(rv, FrameLayout.LayoutParams(dp(railDp), MATCH, Gravity.START))
            railView = rv
        }
        rail = railView
        setContentView(root)
        UiKit.edgeToEdge(this, root, dark) { l, t, r, b ->
            val rv = railView
            if (rv != null) {
                rv.setPadding(l, t, 0, b)
                val lp = rv.layoutParams
                if (lp != null && lp.width != dp(railDp) + l) {
                    lp.width = dp(railDp) + l
                    rv.layoutParams = lp
                }
                scroll.setPadding(l + dp(railDp), t, r, b)
            } else {
                scroll.setPadding(l, t, r, b)
            }
        }
    }

    private fun circleButton(text: String): TextView {
        val t = TextView(this)
        t.text = text
        t.textSize = 16f
        t.typeface = Typeface.DEFAULT_BOLD
        t.gravity = Gravity.CENTER
        t.minWidth = dp(40)
        t.minHeight = dp(40)
        t.setPadding(dp(10), 0, dp(10), 0)
        t.setTextColor(UiKit.primary(dark))
        t.background = UiKit.glass(this, 20f)
        return t
    }

    private fun styleSegments() {
        segWrap.background = UiKit.glass(this, 18f)
        for ((i, tv) in segViews.withIndex()) {
            if (i == tabIndex) {
                tv.setTextColor(Color.WHITE)
                tv.typeface = Typeface.DEFAULT_BOLD
                tv.background = UiKit.rounded(this, UiKit.accent(this), 15f)
            } else {
                tv.setTextColor(UiKit.primary(dark))
                tv.typeface = Typeface.DEFAULT
                tv.background = null
            }
        }
        for ((i, tv) in railViews.withIndex()) {
            if (i == tabIndex) {
                tv.setTextColor(Color.WHITE)
                tv.typeface = Typeface.DEFAULT_BOLD
                tv.background = UiKit.rounded(this, UiKit.accent(this), 14f)
                N27Icons.setTop(tv, railIcon(i), Color.WHITE)
            } else {
                tv.setTextColor(UiKit.primary(dark))
                tv.typeface = Typeface.DEFAULT
                tv.background = null
                N27Icons.setTop(tv, railIcon(i), UiKit.primary(dark))
            }
        }
    }

    private fun railIcon(i: Int): Int =
        when (i) { 0 -> N27Icons.BELL; 1 -> N27Icons.CLOCK; else -> N27Icons.CHART }

    private fun selectTab(i: Int) {
        if (i == tabIndex) return
        tabs[tabIndex].onHide()
        tabIndex = i
        tabHolder.removeAllViews()
        tabHolder.addView(tabs[i].view, LinearLayout.LayoutParams(MATCH, WRAP))
        styleSegments()
        tabs[i].onShow()
        updateHeader()
    }

    private fun updateClearBtn() {
        if (confirmClear) {
            N27Icons.clear(clearBtn)
            clearBtn.text = "Xóa tất cả"
            clearBtn.setTextColor(UiKit.RED)
        } else {
            N27Icons.set(clearBtn, N27Icons.CLOSE, UiKit.primary(dark))
        }
    }

    private fun updateFocusChip() {
        val p = try { Focus.active(this) } catch (e: Exception) { null }
        focusChip.text = if (p != null) p.name else "Focus tắt"
        focusChip.setTextColor(if (p != null) UiKit.accent(this) else UiKit.primary(dark))
        focusChip.background = UiKit.glass(this, 20f)
    }

    private fun showFocusDialog() {
        val profiles = try { Focus.profiles(this) } catch (e: Exception) { emptyList<FocusProfile>() }
        val labels = ArrayList<String>()
        for (p in profiles) labels.add(p.name)
        labels.add("Tắt")
        try {
            Cards.dialog(this).setTitle("Focus")
                .setItems(labels.toTypedArray()) { _, which ->
                    try {
                        if (which in profiles.indices) Focus.setManual(this, profiles[which].id)
                        else Focus.setManual(this, null)
                    } catch (e: Exception) {
                    }
                    updateFocusChip()
                }.show()
        } catch (e: Exception) {
        }
    }

    override fun onResume() {
        super.onResume()
        if (Prefs.isDark(this) != dark) {
            recreate()
            return
        }
        root.background = UiKit.wallpaper(this)
        updateDate()
        updateFocusChip()
        styleSegments()
        NotifStore.addListener(listener)
        try { Focus.addListener(focusListener) } catch (e: Exception) { }
        ControlCenter.start(this)
        updatePermCard()
        updateHeader()
        tabs[tabIndex].onShow()
        handler.removeCallbacks(ticker)
        handler.postDelayed(ticker, 30000L)
        if (!Prefs.onboarded && !onboardingShown) {
            onboardingShown = true
            try { startActivity(Intent(this, OnboardingActivity::class.java)) } catch (e: Exception) { }
        }
    }

    override fun onPause() {
        super.onPause()
        ControlCenter.closeInApp()
        NotifStore.removeListener(listener)
        try { Focus.removeListener(focusListener) } catch (e: Exception) { }
        handler.removeCallbacks(ticker)
        handler.removeCallbacks(refreshRun)
        handler.removeCallbacks(resetConfirm)
        confirmClear = false
        tabs[tabIndex].onHide()
        // everything the person has seen on screen counts as read
        try { NotifStore.markAllRead() } catch (e: Exception) { }
    }

    private fun updateDate() {
        val s = SimpleDateFormat("EEEE, d MMMM", Locale.forLanguageTag("vi")).format(Date())
        dateText.text = s.replaceFirstChar { it.uppercase() }
    }

    private fun updateHeader() {
        val unread = try { NotifStore.unreadCount() } catch (e: Exception) { 0 }
        if (unread > 0) {
            badge.text = if (unread > 99) "99+" else unread.toString()
            badge.background = UiKit.rounded(this, UiKit.accent(this), 12f)
            badge.visibility = View.VISIBLE
        } else {
            badge.visibility = View.GONE
        }
        val removable = NotifStore.all().count { !it.pinned }
        val show = tabIndex == 0 && removable >= 2
        clearBtn.visibility = if (show) View.VISIBLE else View.GONE
        if (!show) confirmClear = false
        updateClearBtn()
    }

    private fun refreshAll() {
        updatePermCard()
        updateHeader()
        tabs[tabIndex].onStoreChanged()
    }

    private fun clearAll() {
        val svc = N27ListenerService.instance
        for (item in NotifStore.all()) {
            if (item.pinned) continue
            NotifStore.remove(item.key)
            if (Prefs.syncClear) {
                try { svc?.cancelNotification(item.key) } catch (e: Exception) { }
            }
        }
        handler.removeCallbacks(refreshRun)
        refreshAll()
    }

    private fun updatePermCard() {
        val ctx: Context = this
        permHolder.removeAllViews()
        val notif = UiKit.notifAccessGranted(ctx)
        val overlay = try { Settings.canDrawOverlays(ctx) } catch (e: Exception) { true }
        if (notif && overlay) {
            permHolder.visibility = View.GONE
            return
        }
        permHolder.visibility = View.VISIBLE
        val card = LinearLayout(ctx)
        card.orientation = LinearLayout.VERTICAL
        card.setPadding(dp(16), dp(14), dp(16), dp(14))
        card.background = UiKit.glass(ctx, 24f)

        val t = TextView(ctx)
        t.text = "Cần cấp quyền"
        t.textSize = 17f
        t.typeface = Typeface.DEFAULT_BOLD
        t.setTextColor(UiKit.primary(dark))
        card.addView(t)
        val d = TextView(ctx)
        d.text = "Cho phép truy cập thông báo và hiển thị trên ứng dụng khác để notifyIOS27 hoạt động. " +
            "Nếu công tắc bị mờ, xem hướng dẫn trong Cài đặt của ứng dụng."
        d.textSize = 13.5f
        d.setTextColor(UiKit.secondary(dark))
        card.addView(d, LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(4) })

        if (!notif) {
            val b = UiKit.pillButton(ctx, "Cấp quyền truy cập thông báo", true)
            b.setOnClickListener { UiKit.openNotifAccess(ctx) }
            card.addView(b, LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(10) })
        }
        if (!overlay) {
            val b = UiKit.pillButton(ctx, "Cấp quyền hiển thị trên ứng dụng khác", true)
            b.setOnClickListener { UiKit.openOverlay(ctx) }
            card.addView(b, LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(10) })
        }
        permHolder.addView(card, LinearLayout.LayoutParams(MATCH, WRAP))
    }
}

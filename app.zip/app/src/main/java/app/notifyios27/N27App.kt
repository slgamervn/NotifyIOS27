package app.notifyios27

import android.app.Application
import android.os.Handler
import android.os.Looper

class N27App : Application() {
    override fun onCreate() {
        super.onCreate()
        // only what the first frame needs; the rest runs on the background thread
        Prefs.init(this)
        Perf.init(this)
        try { History.init(this) } catch (e: Exception) { }
        val app = applicationContext
        try {
            Perf.io.execute {
                try { NotifStore.init(app) } catch (e: Exception) { }
                try {
                    if (Prefs.historyDays > 0) History.purgeOld(Prefs.historyDays)
                } catch (e: Exception) { }
                try { Summary.reschedule(app) } catch (e: Exception) { }
                try { Snooze.restore(app) } catch (e: Exception) { }
                Handler(Looper.getMainLooper()).post {
                    try { Perf.start(app) } catch (e: Exception) { }
                    try { Island.start(app) } catch (e: Exception) { }
                    try { VolumeHud.start(app) } catch (e: Exception) { }
                    try { ControlCenter.start(app) } catch (e: Exception) { }
                }
            }
        } catch (e: Exception) {
            NotifStore.init(app)
        }
    }

    override fun onTerminate() {
        try { Perf.stop() } catch (e: Exception) { }
        super.onTerminate()
    }
}

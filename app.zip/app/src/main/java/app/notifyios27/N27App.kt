package app.notifyios27

import android.app.Application

class N27App : Application() {
    override fun onCreate() {
        super.onCreate()
        Prefs.init(this)
        NotifStore.init(this)
    }
}

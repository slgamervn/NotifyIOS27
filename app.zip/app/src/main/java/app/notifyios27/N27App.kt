package app.notifyios27

import android.app.Application

class N27App : Application() {
    override fun onCreate() {
        super.onCreate()
        Prefs.init(this)
        NotifStore.init(this)
        try { History.init(this) } catch (e: Exception) { }
        try {
            if (Prefs.historyDays > 0) History.purgeOld(Prefs.historyDays)
        } catch (e: Exception) { }
        try { Summary.reschedule(this) } catch (e: Exception) { }
        try { Snooze.restore(this) } catch (e: Exception) { }
        try { Island.start(this) } catch (e: Exception) { }
    }
}

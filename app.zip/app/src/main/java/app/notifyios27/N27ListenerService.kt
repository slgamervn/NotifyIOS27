package app.notifyios27

import android.app.KeyguardManager
import android.app.Notification
import android.app.RemoteInput
import android.content.ComponentName
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.drawable.BitmapDrawable
import android.graphics.drawable.Drawable
import android.graphics.drawable.Icon
import android.media.session.MediaSession
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.Parcelable
import android.os.PowerManager
import android.provider.Settings
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import java.util.concurrent.Executors

class N27ListenerService : NotificationListenerService() {

    companion object {
        @Volatile
        var instance: N27ListenerService? = null

        @Volatile
        var connected: Boolean = false

        @Volatile
        var lastConnectAt: Long = 0L

        private val bg = Executors.newSingleThreadExecutor()
    }

    private val main = Handler(Looper.getMainLooper())
    private val selfCancelled: MutableSet<String> = java.util.Collections.synchronizedSet(HashSet<String>())

    override fun onListenerConnected() {
        super.onListenerConnected()
        instance = this
        connected = true
        lastConnectAt = System.currentTimeMillis()
        val c = applicationContext
        try { Island.start(c) } catch (e: Exception) { }
        try {
            val active = activeNotifications ?: return
            for (sbn in active) {
                try {
                    val item = buildItem(sbn) ?: continue
                    Island.onPosted(c, item)
                } catch (e: Exception) {
                }
            }
        } catch (e: Exception) {
        }
    }

    override fun onListenerDisconnected() {
        super.onListenerDisconnected()
        instance = null
        connected = false
        try {
            if (Build.VERSION.SDK_INT >= 24) {
                requestRebind(ComponentName(this, N27ListenerService::class.java))
            }
        } catch (e: Exception) {
        }
    }

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        try {
            if (!Prefs.appEnabled) return
            val c = applicationContext
            val item = buildItem(sbn) ?: return

            val live = try { Island.onPosted(c, item) } catch (e: Exception) { false }
            if (live) return

            // v1 rules that remain after the island hook
            if (item.ongoing) return
            if (!Prefs.isAppEnabled(item.pkg)) return
            if (item.title.isEmpty() && item.text.isEmpty()) return

            val d = try {
                Rules.evaluate(c, item)
            } catch (e: Exception) {
                Decision(store = true, banner = true, sound = true, timeSensitive = false, summary = false)
            }
            if (!d.store) return

            val item2 = item.copy(
                timeSensitive = item.timeSensitive || d.timeSensitive,
                silent = !d.banner
            )
            val blocked = try {
                val rk = NotificationListenerService.Ranking()
                currentRanking.getRanking(sbn.key, rk) && Dnd.blocks(rk)
            } catch (e: Throwable) {
                false
            }
            val dndSilent = blocked && Prefs.dndMode == 1
            val dndHide = blocked && Prefs.dndMode == 0
            val existing = NotifStore.get(item2.key)
            val unchanged = existing != null && existing.title == item2.title && existing.text == item2.text

            NotifStore.add(item2)
            if (!unchanged) {
                try { bg.execute { try { History.add(item2) } catch (e: Exception) { } } } catch (e: Exception) { }
            }
            try { Health.markPosted(c) } catch (e: Exception) { }

            if (d.summary && !unchanged) {
                try { Summary.defer(c, item2) } catch (e: Exception) { }
            }

            if (d.banner && !unchanged && !dndHide && canShowBanner()) {
                main.post {
                    try {
                        BannerController.show(c, item2, d.sound, dndSilent)
                    } catch (e: Exception) {
                    }
                }
            }

            if (Prefs.autoCopyOtp && item2.otp != null && !unchanged) {
                main.post {
                    try {
                        ItemActions.copyOtp(c, item2)
                    } catch (e: Exception) {
                    }
                }
            }

            if (Prefs.hideOriginal) {
                selfCancelled.add(item2.key)
                cancelNotification(item2.key)
            }
        } catch (e: Exception) {
        }
    }

    override fun onNotificationRemoved(sbn: StatusBarNotification) {
        try {
            val key = sbn.key
            try { Island.onRemoved(applicationContext, key) } catch (e: Exception) { }
            if (selfCancelled.remove(key)) return
            NotifStore.remove(key)
        } catch (e: Exception) {
        }
    }

    private fun canShowBanner(): Boolean {
        if (!Prefs.bannerEnabled) return false
        if (!Settings.canDrawOverlays(this)) return false
        if (Prefs.bannerHideLandscape && UiKit.isLandscape(this)) return false
        val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
        if (!pm.isInteractive) return false
        val km = getSystemService(Context.KEYGUARD_SERVICE) as KeyguardManager
        if (km.isKeyguardLocked) return false
        return true
    }

    @Suppress("DEPRECATION")
    private fun parcelOf(b: Bundle?, key: String): Parcelable? {
        if (b == null) return null
        return try {
            if (Build.VERSION.SDK_INT >= 33) b.getParcelable(key, Parcelable::class.java)
            else b.getParcelable<Parcelable>(key)
        } catch (e: Exception) {
            null
        }
    }

    private fun drawableToBitmap(d: Drawable): Bitmap? {
        if (d is BitmapDrawable && d.bitmap != null) return d.bitmap
        var w = d.intrinsicWidth
        var h = d.intrinsicHeight
        if (w <= 0 || h <= 0) { w = 96; h = 96 }
        val max = 512
        if (w > max || h > max) {
            val s = max.toFloat() / maxOf(w, h)
            w = maxOf(1, (w * s).toInt())
            h = maxOf(1, (h * s).toInt())
        }
        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val cv = Canvas(bmp)
        d.setBounds(0, 0, w, h)
        d.draw(cv)
        return bmp
    }

    private fun toBitmap(p: Parcelable?): Bitmap? {
        return try {
            when (p) {
                is Bitmap -> p
                is Icon -> p.loadDrawable(applicationContext)?.let { drawableToBitmap(it) }
                else -> null
            }
        } catch (e: Exception) {
            null
        }
    }

    private fun buildActions(n: Notification): List<NotifAction> {
        val out = ArrayList<NotifAction>()
        try {
            val acts = n.actions ?: return out
            for (a in acts) {
                try {
                    val ris: Array<RemoteInput>? = a.remoteInputs
                    val free = ris?.firstOrNull { it.allowFreeFormInput }
                    out.add(
                        NotifAction(
                            title = a.title?.toString() ?: "",
                            intent = a.actionIntent,
                            replyKey = free?.resultKey,
                            remoteInputs = if (ris != null && ris.isNotEmpty()) ris else null
                        )
                    )
                } catch (e: Exception) {
                }
            }
        } catch (e: Exception) {
        }
        return out
    }

    /**
     * Builds a NotifItem from a notification. Returns null only for the three v1 filters that run before
     * the island hook (group summary, own package, "android"). Ongoing, disabled-app and empty-content
     * checks are done by the caller.
     */
    private fun buildItem(sbn: StatusBarNotification): NotifItem? {
        val n = sbn.notification ?: return null
        val pkg = sbn.packageName ?: return null
        val flags = n.flags
        if (flags and Notification.FLAG_GROUP_SUMMARY != 0) return null
        if (pkg == packageName || pkg == "android") return null

        val extras: Bundle? = n.extras
        val title = extras?.getCharSequence(Notification.EXTRA_TITLE)?.toString() ?: ""
        val big = extras?.getCharSequence(Notification.EXTRA_BIG_TEXT)?.toString()
        val text = if (!big.isNullOrEmpty()) {
            big
        } else {
            extras?.getCharSequence(Notification.EXTRA_TEXT)?.toString() ?: ""
        }

        val cat = n.category
        val sensitive = cat == Notification.CATEGORY_CALL ||
            cat == Notification.CATEGORY_ALARM ||
            cat == Notification.CATEGORY_REMINDER

        val ongoing = sbn.isOngoing ||
            (flags and Notification.FLAG_ONGOING_EVENT != 0) ||
            (flags and Notification.FLAG_FOREGROUND_SERVICE != 0)

        var bigPicture = toBitmap(parcelOf(extras, Notification.EXTRA_PICTURE))
        if (bigPicture == null) bigPicture = toBitmap(parcelOf(extras, "android.pictureIcon"))
        var largeIcon = toBitmap(parcelOf(extras, Notification.EXTRA_LARGE_ICON))
        if (largeIcon == null) {
            largeIcon = try { toBitmap(n.getLargeIcon()) } catch (e: Exception) { null }
        }

        val showChrono = extras?.getBoolean(Notification.EXTRA_SHOW_CHRONOMETER, false) ?: false
        val mediaToken = try {
            parcelOf(extras, Notification.EXTRA_MEDIA_SESSION) as? MediaSession.Token
        } catch (e: Exception) {
            null
        }

        return NotifItem(
            key = sbn.key,
            pkg = pkg,
            appName = AppIcons.label(applicationContext, pkg),
            title = title,
            text = text,
            time = sbn.postTime,
            timeSensitive = sensitive,
            intent = n.contentIntent,
            subText = extras?.getCharSequence(Notification.EXTRA_SUB_TEXT)?.toString(),
            category = cat,
            groupKey = n.group,
            actions = buildActions(n),
            bigPicture = bigPicture,
            largeIcon = largeIcon,
            otp = Otp.find("$title\n$text"),
            ongoing = ongoing,
            progress = extras?.getInt(Notification.EXTRA_PROGRESS, -1) ?: -1,
            progressMax = extras?.getInt(Notification.EXTRA_PROGRESS_MAX, 0) ?: 0,
            indeterminate = extras?.getBoolean(Notification.EXTRA_PROGRESS_INDETERMINATE, false) ?: false,
            chronoBase = if (showChrono) n.`when` else 0L,
            chronoDown = showChrono && (extras?.getBoolean(Notification.EXTRA_CHRONOMETER_COUNT_DOWN, false) ?: false),
            mediaToken = mediaToken
        )
    }
}

package app.notifyios27

import android.app.KeyguardManager
import android.app.Notification
import android.content.ComponentName
import android.content.Context
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.provider.Settings
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

class N27ListenerService : NotificationListenerService() {

    companion object {
        @Volatile
        var instance: N27ListenerService? = null
    }

    private val main = Handler(Looper.getMainLooper())
    private val selfCancelled: MutableSet<String> = java.util.Collections.synchronizedSet(HashSet<String>())

    override fun onListenerConnected() {
        super.onListenerConnected()
        instance = this
        try {
            val active = activeNotifications ?: return
            val list = ArrayList<NotifItem>()
            for (sbn in active) {
                try {
                    build(sbn)?.let { list.add(it) }
                } catch (e: Exception) {
                }
            }
            list.sortBy { it.time }
            for (item in list) NotifStore.add(item)
        } catch (e: Exception) {
        }
    }

    override fun onListenerDisconnected() {
        super.onListenerDisconnected()
        instance = null
        try {
            requestRebind(ComponentName(this, N27ListenerService::class.java))
        } catch (e: Exception) {
        }
    }

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        try {
            val item = build(sbn) ?: return
            val existing = NotifStore.all().firstOrNull { it.key == item.key }
            val unchanged = existing != null && existing.title == item.title && existing.text == item.text
            NotifStore.add(item)

            if (!unchanged && canShowBanner()) {
                val app = applicationContext
                main.post {
                    try {
                        BannerController.show(app, item)
                    } catch (e: Exception) {
                    }
                }
            }

            if (Prefs.hideOriginal) {
                selfCancelled.add(item.key)
                cancelNotification(item.key)
            }
        } catch (e: Exception) {
        }
    }

    override fun onNotificationRemoved(sbn: StatusBarNotification) {
        try {
            val key = sbn.key
            if (selfCancelled.remove(key)) return
            NotifStore.remove(key)
        } catch (e: Exception) {
        }
    }

    private fun canShowBanner(): Boolean {
        if (!Prefs.bannerEnabled) return false
        if (!Settings.canDrawOverlays(this)) return false
        val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
        if (!pm.isInteractive) return false
        val km = getSystemService(Context.KEYGUARD_SERVICE) as KeyguardManager
        if (km.isKeyguardLocked) return false
        return true
    }

    private fun build(sbn: StatusBarNotification): NotifItem? {
        val n = sbn.notification ?: return null
        val pkg = sbn.packageName ?: return null
        if (pkg == packageName || pkg == "android") return null
        if (sbn.isOngoing) return null
        val flags = n.flags
        if (flags and Notification.FLAG_ONGOING_EVENT != 0) return null
        if (flags and Notification.FLAG_FOREGROUND_SERVICE != 0) return null
        if (flags and Notification.FLAG_GROUP_SUMMARY != 0) return null
        if (!Prefs.isAppEnabled(pkg)) return null

        val extras = n.extras
        val title = extras?.getCharSequence(Notification.EXTRA_TITLE)?.toString() ?: ""
        val big = extras?.getCharSequence(Notification.EXTRA_BIG_TEXT)?.toString()
        val text = if (!big.isNullOrEmpty()) {
            big
        } else {
            extras?.getCharSequence(Notification.EXTRA_TEXT)?.toString() ?: ""
        }
        if (title.isEmpty() && text.isEmpty()) return null

        val cat = n.category
        val sensitive = cat == Notification.CATEGORY_CALL ||
            cat == Notification.CATEGORY_ALARM ||
            cat == Notification.CATEGORY_REMINDER

        return NotifItem(
            key = sbn.key,
            pkg = pkg,
            appName = AppIcons.label(applicationContext, pkg),
            title = title,
            text = text,
            time = sbn.postTime,
            timeSensitive = sensitive,
            intent = n.contentIntent
        )
    }
}

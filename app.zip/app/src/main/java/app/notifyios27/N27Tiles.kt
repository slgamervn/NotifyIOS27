package app.notifyios27

import android.graphics.drawable.Icon
import android.os.Build
import android.service.quicksettings.Tile
import android.service.quicksettings.TileService

class BannerTileService : TileService() {
    override fun onStartListening() {
        super.onStartListening()
        refresh()
    }

    override fun onClick() {
        super.onClick()
        try {
            Prefs.bannerEnabled = !Prefs.bannerEnabled
        } catch (e: Throwable) {
        }
        refresh()
    }

    private fun refresh() {
        val t = qsTile ?: return
        try {
            val on = Prefs.bannerEnabled
            t.state = if (on) Tile.STATE_ACTIVE else Tile.STATE_INACTIVE
            t.label = "Banner"
            if (Build.VERSION.SDK_INT >= 29) {
                t.subtitle = if (on) "Bật" else "Tắt"
            }
            t.icon = Icon.createWithResource(this, R.drawable.n27w_tile_bell)
            t.updateTile()
        } catch (e: Throwable) {
        }
    }
}

class FocusTileService : TileService() {
    override fun onStartListening() {
        super.onStartListening()
        refresh()
    }

    override fun onClick() {
        super.onClick()
        try {
            if (Focus.manualId(this) != null) {
                Focus.setManual(this, null)
            } else {
                val first = Focus.profiles(this).firstOrNull()
                if (first != null) Focus.setManual(this, first.id)
            }
        } catch (e: Throwable) {
        }
        refresh()
    }

    private fun refresh() {
        val t = qsTile ?: return
        try {
            val active = Focus.active(this)
            t.state = if (active != null) Tile.STATE_ACTIVE else Tile.STATE_INACTIVE
            if (Build.VERSION.SDK_INT >= 29) {
                t.label = "Focus"
                t.subtitle = active?.name ?: "Tắt"
            } else {
                t.label = if (active != null) "Focus · " + active.name else "Focus"
            }
            t.icon = Icon.createWithResource(this, R.drawable.n27w_tile_focus)
            t.updateTile()
        } catch (e: Throwable) {
        }
    }
}

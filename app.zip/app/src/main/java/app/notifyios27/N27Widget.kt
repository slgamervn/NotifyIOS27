package app.notifyios27

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.View
import android.widget.RemoteViews

class N27Widget : AppWidgetProvider() {
    override fun onUpdate(context: Context?, appWidgetManager: AppWidgetManager?, appWidgetIds: IntArray?) {
        if (context == null) return
        WidgetUpdater.updateNow(context)
    }

    override fun onEnabled(context: Context?) {
        if (context == null) return
        WidgetUpdater.updateNow(context)
    }
}

object WidgetUpdater {
    private val main = Handler(Looper.getMainLooper())
    private val token = Any()

    @Volatile
    private var appCtx: Context? = null

    private val rowIds = intArrayOf(R.id.n27w_row1, R.id.n27w_row2, R.id.n27w_row3, R.id.n27w_row4)
    private val iconIds = intArrayOf(R.id.n27w_icon1, R.id.n27w_icon2, R.id.n27w_icon3, R.id.n27w_icon4)
    private val titleIds = intArrayOf(R.id.n27w_title1, R.id.n27w_title2, R.id.n27w_title3, R.id.n27w_title4)
    private val textIds = intArrayOf(R.id.n27w_text1, R.id.n27w_text2, R.id.n27w_text3, R.id.n27w_text4)

    /** Debounced (about 500 ms); never throws. */
    fun refresh(c: Context) {
        try {
            appCtx = c.applicationContext ?: c
            main.removeCallbacksAndMessages(token)
            main.postAtTime({ runPending() }, token, SystemClock.uptimeMillis() + 500L)
        } catch (e: Throwable) {
        }
    }

    private fun runPending() {
        val c = appCtx ?: return
        updateNow(c)
    }

    /** Immediate update of every placed widget; never throws. */
    fun updateNow(c: Context) {
        try {
            val app = c.applicationContext ?: c
            val mgr = AppWidgetManager.getInstance(app)
            val cn = ComponentName(app, N27Widget::class.java)
            val ids = mgr.getAppWidgetIds(cn)
            if (ids == null || ids.isEmpty()) return
            mgr.updateAppWidget(ids, build(app))
        } catch (e: Throwable) {
        }
    }

    private fun build(c: Context): RemoteViews {
        val rv = RemoteViews(c.packageName, R.layout.n27w_widget)
        val items: List<NotifItem> = try { NotifStore.all() } catch (e: Throwable) { emptyList() }
        val unread = try { NotifStore.unreadCount() } catch (e: Throwable) { 0 }

        if (unread > 0) {
            rv.setTextViewText(R.id.n27w_count, unread.toString())
            rv.setViewVisibility(R.id.n27w_count, View.VISIBLE)
        } else {
            rv.setViewVisibility(R.id.n27w_count, View.GONE)
        }
        rv.setViewVisibility(R.id.n27w_empty, if (items.isEmpty()) View.VISIBLE else View.GONE)

        for (i in 0 until 4) {
            if (i < items.size) {
                val n = items[i]
                rv.setViewVisibility(rowIds[i], View.VISIBLE)
                val bmp = iconBitmap(c, n.pkg)
                if (bmp != null) rv.setImageViewBitmap(iconIds[i], bmp)
                val title = if (n.title.isNotBlank()) n.title else n.appName
                rv.setTextViewText(titleIds[i], title)
                rv.setTextViewText(textIds[i], n.text)
            } else {
                rv.setViewVisibility(rowIds[i], View.GONE)
            }
        }

        val open = Intent(c, MainActivity::class.java)
        open.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
        val pi = PendingIntent.getActivity(
            c, 0, open, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        rv.setOnClickPendingIntent(R.id.n27w_root, pi)
        return rv
    }

    private fun iconBitmap(c: Context, pkg: String): Bitmap? {
        return try {
            val d = AppIcons.icon(c, pkg) ?: return null
            val size = 96
            val bmp = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
            d.setBounds(0, 0, size, size)
            d.draw(Canvas(bmp))
            bmp
        } catch (e: Throwable) {
            null
        }
    }
}

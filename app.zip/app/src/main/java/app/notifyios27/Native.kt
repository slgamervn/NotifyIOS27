package app.notifyios27

import android.os.Build

/** Detects a system-drawn island / live-activity surface. Heuristic: the user can override in IslandPage. */
object Native {
    const val NONE = 0
    const val ANDROID16_LIVE = 1
    const val HYPER_ISLAND = 2
    const val ONE_UI_LIVE = 3
    const val COLOROS_LIVE = 4

    @Volatile private var cached = -1

    private fun prop(key: String): String {
        return try {
            val c = Class.forName("android.os.SystemProperties")
            val m = c.getMethod("get", String::class.java, String::class.java)
            (m.invoke(null, key, "") as? String) ?: ""
        } catch (e: Throwable) {
            ""
        }
    }

    fun detect(): Int {
        val c = cached
        if (c >= 0) return c
        val man = (Build.MANUFACTURER ?: "").lowercase()
        val brand = (Build.BRAND ?: "").lowercase()
        val r = when {
            man == "xiaomi" && prop("ro.mi.os.version.name").isNotEmpty() -> HYPER_ISLAND
            man == "samsung" && Build.VERSION.SDK_INT >= 35 -> ONE_UI_LIVE
            (man == "oppo" || man == "oneplus" || man == "realme" || brand == "oneplus" || brand == "realme") &&
                (prop("ro.build.version.oplusrom").isNotEmpty() || prop("ro.build.version.opporom").isNotEmpty() ||
                    prop("ro.oxygen.version").isNotEmpty()) -> COLOROS_LIVE
            Build.VERSION.SDK_INT >= 36 -> ANDROID16_LIVE
            else -> NONE
        }
        cached = r
        return r
    }

    fun name(kind: Int = detect()): String = when (kind) {
        ANDROID16_LIVE -> "Live Updates của Android 16"
        HYPER_ISLAND -> "Hyper Island"
        ONE_UI_LIVE -> "Now Bar của One UI"
        COLOROS_LIVE -> "Live Alerts"
        else -> ""
    }

    /** True when live activities should be left to the system and the app draws no island for them. */
    fun systemDrawsLive(): Boolean = when (try { Prefs.islandMode } catch (e: Throwable) { 0 }) {
        1 -> false
        2 -> true
        else -> detect() != NONE
    }
}

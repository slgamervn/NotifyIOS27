package app.notifyios27

import android.app.PendingIntent

data class NotifItem(
    val key: String,
    val pkg: String,
    val appName: String,
    val title: String,
    val text: String,
    val time: Long,
    val timeSensitive: Boolean = false,
    val intent: PendingIntent? = null
)

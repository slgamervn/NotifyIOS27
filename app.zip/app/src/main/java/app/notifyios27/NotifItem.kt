package app.notifyios27

import android.app.PendingIntent
import android.graphics.Bitmap

data class NotifAction(
    val title: String,
    val intent: PendingIntent?,
    val replyKey: String? = null,
    val remoteInputs: Array<android.app.RemoteInput>? = null
)

data class NotifItem(
    val key: String,
    val pkg: String,
    val appName: String,
    val title: String,
    val text: String,
    val time: Long,
    val timeSensitive: Boolean = false,
    val intent: PendingIntent? = null,
    val subText: String? = null,
    val category: String? = null,
    val groupKey: String? = null,
    val actions: List<NotifAction> = emptyList(),
    val bigPicture: Bitmap? = null,
    val largeIcon: Bitmap? = null,
    val otp: String? = null,
    val silent: Boolean = false,
    val pinned: Boolean = false,
    val read: Boolean = false,
    val ongoing: Boolean = false,
    val progress: Int = -1,
    val progressMax: Int = 0,
    val indeterminate: Boolean = false,
    val chronoBase: Long = 0L,
    val chronoDown: Boolean = false,
    val mediaToken: android.media.session.MediaSession.Token? = null
)

data class HistoryRow(
    val id: Long,
    val pkg: String,
    val appName: String,
    val title: String,
    val text: String,
    val time: Long,
    val otp: String?
)

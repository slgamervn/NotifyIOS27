@file:Suppress("DEPRECATION")
package app.notifyios27


import android.app.ActivityOptions
import android.content.Context
import android.os.Build
import android.os.Handler
import android.os.Looper
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.concurrent.CopyOnWriteArrayList

object NotifStore {
    private const val MAX = 100
    private val lock = Any()
    private val items = ArrayList<NotifItem>()
    private val listeners = CopyOnWriteArrayList<() -> Unit>()
    private val main = Handler(Looper.getMainLooper())
    private var file: File? = null
    @Volatile
    private var appCtx: Context? = null

    fun init(c: Context) {
        appCtx = c.applicationContext
        synchronized(lock) {
            if (file != null) return
            val f = File(c.applicationContext.filesDir, "n27_store.json")
            file = f
            try {
                if (f.exists()) {
                    val arr = JSONArray(f.readText())
                    for (i in 0 until arr.length()) {
                        val o = arr.getJSONObject(i)
                        items.add(
                            NotifItem(
                                key = o.getString("key"),
                                pkg = o.getString("pkg"),
                                appName = o.optString("appName"),
                                title = o.optString("title"),
                                text = o.optString("text"),
                                time = o.optLong("time"),
                                timeSensitive = o.optBoolean("timeSensitive", false),
                                pinned = o.optBoolean("pinned", false),
                                read = o.optBoolean("read", false)
                            )
                        )
                    }
                    while (items.size > MAX) items.removeAt(items.size - 1)
                }
            } catch (e: Exception) {
                items.clear()
            }
        }
    }

    fun all(): List<NotifItem> = synchronized(lock) {
        ArrayList(items).sortedWith(
            compareByDescending<NotifItem> { it.pinned }.thenByDescending { it.time }
        )
    }

    fun get(key: String): NotifItem? = synchronized(lock) { items.firstOrNull { it.key == key } }

    fun unreadCount(): Int = synchronized(lock) { items.count { !it.read } }

    fun add(i: NotifItem) {
        mutate {
            val old = items.firstOrNull { it.key == i.key }
            items.removeIf { it.key == i.key }
            val keepRead = old != null && old.title == i.title && old.text == i.text
            val merged = i.copy(
                pinned = i.pinned || (old?.pinned ?: false),
                read = i.read || (keepRead && old?.read == true)
            )
            items.add(0, merged)
            // never evict pinned items while an unpinned one exists
            while (items.size > MAX) {
                val idx = items.indexOfLast { !it.pinned }
                items.removeAt(if (idx >= 0) idx else items.size - 1)
            }
            true
        }
    }

    fun remove(key: String) {
        mutate { items.removeIf { it.key == key } }
    }

    fun clearApp(pkg: String) {
        mutate { items.removeIf { it.pkg == pkg } }
    }

    fun clearAll() {
        mutate {
            val had = items.isNotEmpty()
            items.clear()
            had
        }
    }

    fun setPinned(key: String, on: Boolean) {
        mutate {
            val idx = items.indexOfFirst { it.key == key }
            if (idx < 0 || items[idx].pinned == on) {
                false
            } else {
                items[idx] = items[idx].copy(pinned = on)
                true
            }
        }
    }

    fun markRead(key: String) {
        mutate {
            val idx = items.indexOfFirst { it.key == key }
            if (idx < 0 || items[idx].read) {
                false
            } else {
                items[idx] = items[idx].copy(read = true)
                true
            }
        }
    }

    fun markAllRead() {
        mutate {
            var changed = false
            for (idx in items.indices) {
                if (!items[idx].read) {
                    items[idx] = items[idx].copy(read = true)
                    changed = true
                }
            }
            changed
        }
    }

    fun addListener(l: () -> Unit) {
        listeners.add(l)
    }

    fun removeListener(l: () -> Unit) {
        listeners.remove(l)
    }

    fun open(c: Context, i: NotifItem) {
        val pi = i.intent ?: return
        try {
            if (Build.VERSION.SDK_INT >= 34) {
                val o = ActivityOptions.makeBasic()
                o.setPendingIntentBackgroundActivityStartMode(
                    ActivityOptions.MODE_BACKGROUND_ACTIVITY_START_ALLOWED
                )
                pi.send(c, 0, null, null, null, null, o.toBundle())
            } else {
                pi.send()
            }
        } catch (e: Exception) {
        }
    }

    private fun mutate(block: () -> Boolean) {
        var changed = false
        synchronized(lock) {
            changed = block()
            if (changed) save()
        }
        if (changed) fire()
    }

    private fun save() {
        val f = file ?: return
        try {
            val arr = JSONArray()
            for (n in items) {
                val o = JSONObject()
                o.put("key", n.key)
                o.put("pkg", n.pkg)
                o.put("appName", n.appName)
                o.put("title", n.title)
                o.put("text", n.text)
                o.put("time", n.time)
                o.put("timeSensitive", n.timeSensitive)
                o.put("pinned", n.pinned)
                o.put("read", n.read)
                arr.put(o)
            }
            f.writeText(arr.toString())
        } catch (e: Exception) {
        }
    }

    private fun fire() {
        val run = Runnable {
            for (l in listeners) {
                try { l() } catch (e: Exception) { }
            }
        }
        if (Looper.myLooper() == Looper.getMainLooper()) run.run() else main.post(run)
        try {
            appCtx?.let { WidgetUpdater.refresh(it) }
        } catch (e: Throwable) {
        }
    }
}

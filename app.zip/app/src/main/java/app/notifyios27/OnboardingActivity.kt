package app.notifyios27

@file:Suppress("DEPRECATION")

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

class OnboardingActivity : Activity() {
    private val total = 5
    private var step = 0
    private lateinit var content: LinearLayout
    private lateinit var segs: LinearLayout
    private lateinit var counter: TextView
    private lateinit var back: TextView
    private lateinit var next: TextView

    private fun dp(v: Int): Int = UiKit.dp(this, v)

    private fun lp(w: Int, h: Int, top: Int = 0, bottom: Int = 0): LinearLayout.LayoutParams {
        val p = LinearLayout.LayoutParams(w, h)
        p.topMargin = top
        p.bottomMargin = bottom
        return p
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        step = (savedInstanceState?.getInt("step", 0) ?: 0).coerceIn(0, total - 1)
        val dark = Prefs.isDark(this)
        val match = ViewGroup.LayoutParams.MATCH_PARENT
        val wrap = ViewGroup.LayoutParams.WRAP_CONTENT

        val root = FrameLayout(this)
        root.background = UiKit.wallpaper(this)
        val main = N27MaxWidthColumn(this, 640)
        root.addView(main, FrameLayout.LayoutParams(match, match, Gravity.CENTER_HORIZONTAL))

        counter = TextView(this)
        counter.textSize = 13f
        counter.setTextColor(UiKit.secondary(dark))
        main.addView(counter, lp(wrap, wrap, bottom = dp(8)))

        segs = LinearLayout(this)
        segs.orientation = LinearLayout.HORIZONTAL
        for (i in 0 until total) {
            val v = View(this)
            val p = LinearLayout.LayoutParams(0, dp(4), 1f)
            p.leftMargin = dp(2)
            p.rightMargin = dp(2)
            segs.addView(v, p)
        }
        main.addView(segs, lp(match, dp(4), bottom = dp(16)))

        val sv = ScrollView(this)
        sv.isVerticalScrollBarEnabled = false
        content = LinearLayout(this)
        content.orientation = LinearLayout.VERTICAL
        sv.addView(content, ViewGroup.LayoutParams(match, wrap))
        main.addView(sv, LinearLayout.LayoutParams(match, 0, 1f))

        val nav = LinearLayout(this)
        nav.orientation = LinearLayout.HORIZONTAL
        back = UiKit.pillButton(this, "Quay lại", false)
        next = UiKit.pillButton(this, "Tiếp", true)
        val pb = LinearLayout.LayoutParams(0, wrap, 1f)
        pb.rightMargin = dp(6)
        val pn = LinearLayout.LayoutParams(0, wrap, 1f)
        pn.leftMargin = dp(6)
        nav.addView(back, pb)
        nav.addView(next, pn)
        main.addView(nav, lp(match, wrap, top = dp(12)))

        back.setOnClickListener {
            if (step > 0) {
                step--
                render()
            }
        }
        next.setOnClickListener {
            if (step < total - 1) {
                if (step == 0) askPostNotifications()
                step++
                render()
            } else {
                finishOnboarding()
            }
        }

        setContentView(root)
        UiKit.edgeToEdge(this, root, dark) { l, t, r, b ->
            main.setPadding(l + dp(20), t + dp(16), r + dp(20), b + dp(16))
        }
    }

    override fun onConfigurationChanged(newConfig: android.content.res.Configuration) {
        super.onConfigurationChanged(newConfig)
        try { window.decorView.requestApplyInsets() } catch (e: Throwable) { }
    }

    private fun finishOnboarding() {
        try { Prefs.onboarded = true } catch (e: Throwable) { }
        try { startActivity(Intent(this, MainActivity::class.java)) } catch (e: Throwable) { }
        finish()
    }

    private fun statusLine(ok: Boolean, yes: String, no: String): TextView {
        val t = TextView(this)
        t.text = if (ok) yes else no
        t.compoundDrawablePadding = dp(8)
        t.setCompoundDrawablesWithIntrinsicBounds(
            N27Icons.drawable(this, if (ok) N27Icons.CHECK else N27Icons.WARN, if (ok) UiKit.GREEN else UiKit.ORANGE, 20),
            null, null, null
        )
        t.textSize = 15f
        t.typeface = Typeface.DEFAULT_BOLD
        t.gravity = Gravity.CENTER
        t.setTextColor(if (ok) UiKit.GREEN else UiKit.ORANGE)
        return t
    }

    private fun render() {
        val dark = Prefs.isDark(this)
        val match = ViewGroup.LayoutParams.MATCH_PARENT
        val wrap = ViewGroup.LayoutParams.WRAP_CONTENT
        content.removeAllViews()
        counter.text = "Bước ${step + 1}/$total"
        val off = if (dark) Color.argb(60, 255, 255, 255) else Color.argb(50, 0, 0, 0)
        for (i in 0 until total) {
            segs.getChildAt(i).background =
                UiKit.rounded(this, if (i <= step) UiKit.accent(this) else off, 2f)
        }
        back.visibility = if (step == 0) View.INVISIBLE else View.VISIBLE
        next.text = if (step == total - 1) "Hoàn tất" else "Tiếp"

        var iconKind = N27Icons.BELL
        var title = ""
        var body = ""
        var status: TextView? = null
        var btnText: String? = null
        var btnAction: (() -> Unit)? = null

        when (step) {
            0 -> {
                iconKind = N27Icons.BELL
                title = "Chào mừng đến notifyIOS27"
                body = "Ứng dụng hiển thị thông báo thật của điện thoại theo phong cách iOS 27. " +
                    "Bốn bước tiếp theo giúp bạn cấp quyền cần thiết, chỉ mất khoảng một phút."
            }
            1 -> {
                iconKind = N27Icons.SHIELD
                title = "Cho phép cài đặt bị hạn chế"
                body = "Android 13 trở lên chặn các quyền nhạy cảm với ứng dụng cài thủ công. " +
                    "Hãy mở Thông tin ứng dụng, nhấn dấu ba chấm dọc ở góc trên bên phải rồi chọn " +
                    "“Cho phép cài đặt bị hạn chế”. Nếu không thấy mục này, bạn có thể bỏ qua bước này."
                btnText = "Mở thông tin ứng dụng"
                btnAction = {
                    UiKit.safeStart(
                        this,
                        Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + packageName))
                    )
                }
            }
            2 -> {
                iconKind = N27Icons.DOWNLOAD
                title = "Quyền truy cập thông báo"
                body = "Cho phép notifyIOS27 đọc thông báo để hiển thị lại theo kiểu iOS."
                val ok = try { UiKit.notifAccessGranted(this) } catch (e: Throwable) { false }
                status = statusLine(ok, "Đã cấp quyền", "Chưa cấp quyền")
                btnText = "Mở cài đặt truy cập thông báo"
                btnAction = { UiKit.openNotifAccess(this) }
            }
            3 -> {
                iconKind = N27Icons.WINDOW
                title = "Hiển thị trên ứng dụng khác"
                body = "Quyền này cho phép banner thông báo xuất hiện phía trên mọi ứng dụng."
                val ok = try { Settings.canDrawOverlays(this) } catch (e: Throwable) { false }
                status = statusLine(ok, "Đã cấp quyền", "Chưa cấp quyền")
                btnText = "Mở cài đặt hiển thị"
                btnAction = { UiKit.openOverlay(this) }
            }
            else -> {
                iconKind = N27Icons.BATTERY
                title = "Chạy nền ổn định"
                val oem = try { Health.oemHelpIntent(this) } catch (e: Throwable) { null }
                val name = try { Health.oemName() } catch (e: Throwable) { "" }
                body = "Để thông báo không bị trễ hoặc mất khi tắt màn hình, hãy bỏ giới hạn pin" +
                    (if (oem != null) " và bật tự khởi động, cho phép chạy nền cho ứng dụng." else ".") +
                    (if (name.isNotBlank()) "\n\nHãng máy: $name" else "")
                val ok = try { UiKit.batteryIgnored(this) } catch (e: Throwable) { false }
                status = statusLine(ok, "Không bị hạn chế", "Đang bị hạn chế")
                btnText = if (oem != null) "Mở cài đặt chạy nền của hãng máy" else "Mở cài đặt pin"
                btnAction = {
                    if (oem != null) UiKit.safeStart(this, oem) else UiKit.openBattery(this)
                }
            }
        }

        val card = LinearLayout(this)
        card.orientation = LinearLayout.VERTICAL
        card.gravity = Gravity.CENTER_HORIZONTAL
        card.background = UiKit.glass(this, 26f)
        card.setPadding(dp(22), dp(28), dp(22), dp(24))

        val e = android.widget.ImageView(this)
        e.setImageDrawable(N27Icons.drawable(this, iconKind, UiKit.accent(this), 56))
        card.addView(e, lp(dp(56), dp(56), bottom = dp(12)))

        val t = TextView(this)
        t.text = title
        t.textSize = 24f
        t.typeface = Typeface.DEFAULT_BOLD
        t.gravity = Gravity.CENTER
        t.setTextColor(UiKit.primary(dark))
        card.addView(t, lp(match, wrap, bottom = dp(12)))

        val b = TextView(this)
        b.text = body
        b.textSize = 16f
        b.gravity = Gravity.CENTER
        b.setTextColor(UiKit.secondary(dark))
        card.addView(b, lp(match, wrap, bottom = dp(16)))

        if (status != null) card.addView(status, lp(match, wrap, bottom = dp(14)))

        val action = btnAction
        if (btnText != null && action != null) {
            val btn = UiKit.pillButton(this, btnText, true)
            btn.setOnClickListener { action() }
            card.addView(btn, lp(match, wrap))
        }

        content.addView(card, lp(match, wrap))
        if (step >= 2 && !(try { UiKit.notifAccessGranted(this) } catch (e: Throwable) { true })) {
            content.addView(UiKit.restrictedCard(this, dark), lp(match, wrap, top = dp(12)))
        }
    }

    private fun askPostNotifications() {
        try {
            if (Build.VERSION.SDK_INT >= 33 &&
                checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
            ) {
                requestPermissions(arrayOf(android.Manifest.permission.POST_NOTIFICATIONS), 27)
            }
        } catch (e: Throwable) {
        }
    }

    override fun onResume() {
        super.onResume()
        render()
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        outState.putInt("step", step)
    }

    @Suppress("DEPRECATION")
    override fun onBackPressed() {
        if (step > 0) {
            step--
            render()
        } else {
            super.onBackPressed()
        }
    }
}

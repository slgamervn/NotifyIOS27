package app.notifyios27

import java.text.Normalizer
import java.util.Locale

object Otp {
    private val KEYWORD = Regex(
        "(?<![\\p{L}\\p{N}])(mã|otp|code|xác thực|xác minh|xac thuc|xac minh|verification|verify|pin|passcode|password|mật khẩu)(?![\\p{L}\\p{N}])"
    )
    private val NUMBER = Regex("\\d{4,8}")
    private val CURRENCY_AFTER = Regex(
        "^\\s*(%|[\\$€£¥₫]|(đ|vnd|vnđ|usd|k|tr|triệu|nghìn|ngàn)(?![\\p{L}\\p{N}]))"
    )
    private const val CURRENCY_BEFORE = "\$₫€£¥"

    fun find(text: String): String? {
        if (text.isEmpty()) return null
        val s = Normalizer.normalize(text, Normalizer.Form.NFC).lowercase(Locale.ROOT)
        val keys = KEYWORD.findAll(s).map { it.range.first }.toList()
        if (keys.isEmpty()) return null
        var best: String? = null
        var bestDist = Int.MAX_VALUE
        for (m in NUMBER.findAll(s)) {
            val start = m.range.first
            val end = m.range.last + 1
            val code = m.value
            // part of a longer digit run, separators, dates or decimals
            if (start > 0) {
                val prev = s[start - 1]
                if (prev.isDigit() || prev == '/' || prev == '.' || prev == ',' || CURRENCY_BEFORE.indexOf(prev) >= 0) continue
            }
            if (end < s.length) {
                val next = s[end]
                if (next.isDigit() || next == '/') continue
                if ((next == '.' || next == ',') && end + 1 < s.length && s[end + 1].isDigit()) continue
            }
            if (CURRENCY_AFTER.containsMatchIn(s.substring(end, minOf(s.length, end + 8)))) continue
            if (code.length == 4) {
                val y = code.toInt()
                if (y in 1900..2099) continue
            }
            var d = Int.MAX_VALUE
            for (k in keys) {
                val dist = if (k < start) start - k else k - start
                if (dist < d) d = dist
            }
            if (d < bestDist) {
                bestDist = d
                best = code
            }
        }
        return best
    }
}

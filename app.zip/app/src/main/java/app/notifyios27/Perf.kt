package app.notifyios27

import android.animation.TimeInterpolator
import android.app.ActivityManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.database.ContentObserver
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.provider.Settings
import android.view.HapticFeedbackConstants
import android.view.View
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

/** Device tier and the motion / blur / memory budget derived from it. Everything tier-dependent reads from here. */
object Perf {
    const val LITE = 0
    const val BALANCED = 1
    const val FULL = 2

    /** The one background thread for disk, database and bitmap work. */
    val io: ExecutorService = Executors.newSingleThreadExecutor()
    private val main = Handler(Looper.getMainLooper())

    @Volatile private var base = -1
    @Volatile private var powerSave = false
    @Volatile private var thermal = false
    @Volatile private var animScale = 1f
    @Volatile private var memClass = 128
    private var app: Context? = null
    private var started = false
    private var thermalListener: Any? = null

    private fun detect(c: Context): Int {
        return try {
            val am = c.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
            memClass = am.memoryClass
            val sdk = Build.VERSION.SDK_INT
            when {
                am.isLowRamDevice || am.memoryClass <= 128 || sdk <= 27 ||
                    Runtime.getRuntime().availableProcessors() <= 4 && am.memoryClass <= 192 -> LITE
                am.memoryClass <= 256 || sdk <= 29 -> BALANCED
                else -> FULL
            }
        } catch (e: Throwable) {
            BALANCED
        }
    }

    fun init(c: Context) {
        if (base >= 0) return
        base = detect(c.applicationContext ?: c)
        readAnimScale(c)
    }

    private fun readAnimScale(c: Context) {
        animScale = try {
            Settings.Global.getFloat(c.contentResolver, Settings.Global.ANIMATOR_DURATION_SCALE, 1f)
        } catch (e: Throwable) {
            1f
        }
    }

    private val powerReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            val c = context ?: return
            try {
                val pm = c.getSystemService(Context.POWER_SERVICE) as PowerManager
                powerSave = pm.isPowerSaveMode
            } catch (e: Throwable) {
            }
        }
    }

    private val scaleObserver = object : ContentObserver(main) {
        override fun onChange(selfChange: Boolean) {
            app?.let { readAnimScale(it) }
        }
    }

    /** Registers the power-save, thermal and animator-scale watchers. */
    fun start(c: Context) {
        val ctx = c.applicationContext ?: c
        init(ctx)
        main.post {
            if (started) return@post
            started = true
            app = ctx
            try {
                val pm = ctx.getSystemService(Context.POWER_SERVICE) as PowerManager
                powerSave = pm.isPowerSaveMode
                val f = IntentFilter(PowerManager.ACTION_POWER_SAVE_MODE_CHANGED)
                if (Build.VERSION.SDK_INT >= 33) ctx.registerReceiver(powerReceiver, f, Context.RECEIVER_NOT_EXPORTED)
                else ctx.registerReceiver(powerReceiver, f)
                if (Build.VERSION.SDK_INT >= 29) {
                    thermal = pm.currentThermalStatus >= PowerManager.THERMAL_STATUS_SEVERE
                    val l = PowerManager.OnThermalStatusChangedListener { s ->
                        thermal = s >= PowerManager.THERMAL_STATUS_SEVERE
                    }
                    pm.addThermalStatusListener(l)
                    thermalListener = l
                }
            } catch (e: Throwable) {
            }
            try {
                ctx.contentResolver.registerContentObserver(
                    Settings.Global.getUriFor(Settings.Global.ANIMATOR_DURATION_SCALE), false, scaleObserver
                )
            } catch (e: Throwable) {
            }
        }
    }

    fun stop() {
        main.post {
            val ctx = app ?: return@post
            if (!started) return@post
            started = false
            try { ctx.unregisterReceiver(powerReceiver) } catch (e: Throwable) { }
            try { ctx.contentResolver.unregisterContentObserver(scaleObserver) } catch (e: Throwable) { }
            if (Build.VERSION.SDK_INT >= 29) {
                try {
                    val pm = ctx.getSystemService(Context.POWER_SERVICE) as PowerManager
                    val l = thermalListener as? PowerManager.OnThermalStatusChangedListener
                    if (l != null) pm.removeThermalStatusListener(l)
                } catch (e: Throwable) {
                }
            }
            thermalListener = null
        }
    }

    /** Detected tier before the user override and the power / thermal drop. */
    fun detected(): Int = if (base < 0) BALANCED else base

    fun tier(): Int {
        val forced = try { Prefs.perfMode } catch (e: Throwable) { 0 }
        var t = when (forced) {
            1 -> FULL
            2 -> BALANCED
            3 -> LITE
            else -> detected()
        }
        if (forced == 0 && (powerSave || thermal)) t = maxOf(LITE, t - 1)
        return t
    }

    val lite: Boolean get() = tier() == LITE

    fun blurAllowed(): Boolean = tier() != LITE

    /** Blur radius after the tier cap (BALANCED: 16 dp). */
    fun blurPx(c: Context, px: Int): Int =
        if (tier() == BALANCED) minOf(px, UiKit.dp(c, 16)) else px

    /** 0 = continuous blur ramp, otherwise the number of steps (LITE never blurs). */
    fun blurSteps(): Int = if (tier() == FULL) 0 else 2

    /** True when the system or the user turned animation off. */
    fun noMotion(): Boolean = animScale == 0f

    /** Scales a duration by tier, the animator scale, reduce-motion and the user speed. */
    fun dur(ms: Long): Long {
        if (noMotion()) return 0L
        var d = ms.toFloat()
        val speed = try { Prefs.animSpeed } catch (e: Throwable) { 1f }
        d /= speed.coerceIn(0.5f, 2f)
        if (try { Prefs.reduceMotion } catch (e: Throwable) { false }) d = minOf(d, 160f)
        if (lite) d = d.coerceIn(150f, 200f)
        d *= animScale.coerceIn(0.25f, 4f)
        return d.toLong().coerceAtLeast(0L)
    }

    fun loops(): Boolean = !lite && !noMotion() && !(try { Prefs.reduceMotion } catch (e: Throwable) { false })

    fun shadows(): Boolean = !lite

    fun historyPage(): Int = if (lite) 25 else 50

    fun maxBitmapW(c: Context): Int {
        val w = UiKit.smallSide(c)
        return if (lite) maxOf(96, w / 2) else maxOf(256, w)
    }

    fun iconCacheSize(): Int = (memClass / 4).coerceIn(16, 96)

    /** Haptic through the view: works without the VIBRATE path and respects the system setting. */
    fun haptic(v: View?, kind: Int) {
        if (v == null) return
        if (!(try { Prefs.haptic } catch (e: Throwable) { true })) return
        try {
            val k = when (kind) {
                H_CONFIRM -> if (Build.VERSION.SDK_INT >= 30) HapticFeedbackConstants.CONFIRM else HapticFeedbackConstants.VIRTUAL_KEY
                H_REJECT -> if (Build.VERSION.SDK_INT >= 30) HapticFeedbackConstants.REJECT else HapticFeedbackConstants.LONG_PRESS
                H_KEY -> HapticFeedbackConstants.VIRTUAL_KEY
                else -> HapticFeedbackConstants.CLOCK_TICK
            }
            v.performHapticFeedback(k)
        } catch (e: Throwable) {
        }
    }

    const val H_TICK = 0
    const val H_CONFIRM = 1
    const val H_REJECT = 2
    const val H_KEY = 3

    /** Press feedback: scale 0.97 for 60 ms on touch, back on release. */
    fun pressable(v: View) {
        v.setOnTouchListener { view, e ->
            when (e.actionMasked) {
                android.view.MotionEvent.ACTION_DOWN ->
                    view.animate().scaleX(0.97f).scaleY(0.97f).setDuration(if (noMotion()) 0L else 60L).start()
                android.view.MotionEvent.ACTION_UP, android.view.MotionEvent.ACTION_CANCEL ->
                    view.animate().scaleX(1f).scaleY(1f).setDuration(if (noMotion()) 0L else 90L).start()
            }
            false
        }
    }

    /** Damped spring look-alike: one overshoot then settle. No allocation per frame. */
    class Damped(private val bounce: Float = 0.12f) : TimeInterpolator {
        override fun getInterpolation(t: Float): Float {
            if (t <= 0f) return 0f
            if (t >= 1f) return 1f
            val decay = Math.exp((-6.0 * t)).toFloat()
            val osc = Math.cos(t * Math.PI * 1.5).toFloat()
            return 1f - decay * osc * (1f - bounce) - (1f - t) * bounce * decay
        }
    }

    val SPRING: TimeInterpolator = Damped(0.12f)
    val SPRING_SOFT: TimeInterpolator = Damped(0.0f)
}

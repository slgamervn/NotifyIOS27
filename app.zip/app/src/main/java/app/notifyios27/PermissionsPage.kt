package app.notifyios27

import android.app.Activity
import android.content.Intent
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class PermissionsPage : SettingsPage {
    override val title: String = "Quyền và tình trạng"
    private var box: LinearLayout? = null

    override fun build(a: Activity, push: (SettingsPage) -> Unit): View {
        val b = LinearLayout(a)
        b.orientation = LinearLayout.VERTICAL
        box = b
        fill(a, b)
        return b
    }

    override fun onResume() {
        val b = box ?: return
        val a = b.context as? Activity ?: return
        fill(a, b)
    }

    private fun permRow(a: Activity, label: String, ok: Boolean, okText: String, badText: String, open: () -> Unit): View {
        val dark = Prefs.isDark(a)
        val row = LinearLayout(a)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        row.setPadding(UiKit.dp(a, 16), UiKit.dp(a, 12), UiKit.dp(a, 16), UiKit.dp(a, 12))
        val col = LinearLayout(a)
        col.orientation = LinearLayout.VERTICAL
        val l = TextView(a)
        l.text = label
        l.textSize = 16f
        l.setTextColor(UiKit.primary(dark))
        col.addView(l)
        val s = TextView(a)
        s.text = if (ok) okText else badText
        s.textSize = 13f
        s.setTextColor(if (ok) UiKit.GREEN else UiKit.RED)
        col.addView(s)
        row.addView(col, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        val btn = UiKit.pillButton(a, "Mở cài đặt", !ok)
        btn.setOnClickListener { open() }
        row.addView(btn, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
            leftMargin = UiKit.dp(a, 12)
        })
        return row
    }

    private fun fill(a: Activity, b: LinearLayout) {
        b.removeAllViews()
        val dark = Prefs.isDark(a)
        val notif = UiKit.notifAccessGranted(a)
        val overlay = try { Settings.canDrawOverlays(a) } catch (e: Exception) { false }
        val battery = try { UiKit.batteryIgnored(a) } catch (e: Exception) { false }

        val s = SettingsKit.section(a, "Quyền")
        s.addView(permRow(a, "Truy cập thông báo", notif, "Đã cấp", "Chưa cấp") { UiKit.openNotifAccess(a) })
        s.addView(permRow(a, "Hiển thị trên ứng dụng khác", overlay, "Đã cấp", "Chưa cấp") { UiKit.openOverlay(a) })
        s.addView(permRow(a, "Chạy nền không giới hạn pin", battery, "Đã bỏ giới hạn", "Đang bị giới hạn") { UiKit.openBattery(a) })
        b.addView(s, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        b.addView(SettingsKit.spacer(a, 16))

        val help = SettingsKit.section(a, "Nếu công tắc bị mờ")
        val t = TextView(a)
        t.text = "Android chặn cấp quyền cho ứng dụng cài từ ngoài. Hãy vào Cài đặt > Ứng dụng > notifyIOS27 > " +
            "menu ⋮ > \"Cho phép cài đặt bị hạn chế\", sau đó quay lại cấp quyền."
        t.textSize = 14f
        t.setTextColor(UiKit.primary(dark))
        t.setPadding(UiKit.dp(a, 16), UiKit.dp(a, 6), UiKit.dp(a, 16), UiKit.dp(a, 14))
        help.addView(t, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        b.addView(help, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        b.addView(SettingsKit.spacer(a, 16))

        val h = SettingsKit.section(a, null)
        h.addView(SettingsKit.buttonRow(a, "Tình trạng hoạt động", "Kiểm tra dịch vụ, pin và khởi động lại") {
            try {
                a.startActivity(Intent(a, HealthActivity::class.java))
            } catch (e: Exception) {
                Toast.makeText(a, "Không thể mở màn hình này", Toast.LENGTH_SHORT).show()
            }
        })
        b.addView(h, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
    }
}

package app.notifyios27

import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.text.Editable
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.CheckBox
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

internal fun n27Dialog(a: Activity): AlertDialog.Builder {
    val dark = Prefs.isDark(a)
    return AlertDialog.Builder(
        a,
        if (dark) android.R.style.Theme_DeviceDefault_Dialog_Alert
        else android.R.style.Theme_DeviceDefault_Light_Dialog_Alert
    )
}

internal fun n27Note(a: Activity, text: String): TextView {
    val t = TextView(a)
    t.text = text
    t.textSize = 12.5f
    t.setTextColor(UiKit.secondary(Prefs.isDark(a)))
    t.setPadding(UiKit.dp(a, 6), UiKit.dp(a, 6), UiKit.dp(a, 6), UiKit.dp(a, 6))
    return t
}

/** Package names of every launcher app except this one. */
internal fun n27LauncherPkgs(c: Context): List<String> {
    val out = ArrayList<String>()
    try {
        val pm = c.packageManager
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val infos = if (Build.VERSION.SDK_INT >= 33)
            pm.queryIntentActivities(intent, PackageManager.ResolveInfoFlags.of(0L))
        else
            pm.queryIntentActivities(intent, 0)
        val seen = HashSet<String>()
        for (ri in infos) {
            val p = ri.activityInfo?.packageName ?: continue
            if (p == c.packageName || !seen.add(p)) continue
            out.add(p)
        }
    } catch (e: Exception) {
    }
    return out
}

object PickerDialogs {
    fun pickApps(a: Activity, selected: Set<String>, onDone: (Set<String>) -> Unit) {
        try {
            val dark = Prefs.isDark(a)
            val chosen = HashSet<String>(selected)
            val apps = n27LauncherPkgs(a).map { Pair(it, AppIcons.label(a, it)) }
                .sortedBy { it.second.lowercase() }

            val root = LinearLayout(a)
            root.orientation = LinearLayout.VERTICAL
            root.setPadding(UiKit.dp(a, 16), UiKit.dp(a, 8), UiKit.dp(a, 16), 0)

            val search = EditText(a)
            search.hint = "Tìm ứng dụng"
            search.setSingleLine(true)
            root.addView(search, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

            val list = LinearLayout(a)
            list.orientation = LinearLayout.VERTICAL
            val scroll = ScrollView(a)
            scroll.addView(list, ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
            val h = (a.resources.displayMetrics.heightPixels * 0.5f).toInt()
            root.addView(scroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, h))

            val rows = ArrayList<Pair<View, String>>()
            for ((pkg, label) in apps) {
                val row = LinearLayout(a)
                row.orientation = LinearLayout.HORIZONTAL
                row.gravity = Gravity.CENTER_VERTICAL
                row.setPadding(0, UiKit.dp(a, 6), 0, UiKit.dp(a, 6))
                row.addView(UiKit.iconView(a, pkg, 36), LinearLayout.LayoutParams(UiKit.dp(a, 36), UiKit.dp(a, 36)))
                val tv = TextView(a)
                tv.text = label
                tv.textSize = 15f
                tv.setTextColor(UiKit.primary(dark))
                row.addView(tv, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply {
                    leftMargin = UiKit.dp(a, 12)
                })
                val cb = CheckBox(a)
                cb.isChecked = chosen.contains(pkg)
                cb.setOnCheckedChangeListener { _, on -> if (on) chosen.add(pkg) else chosen.remove(pkg) }
                row.addView(cb, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT))
                row.setOnClickListener { cb.toggle() }
                list.addView(row, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
                rows.add(Pair(row, label.lowercase()))
            }

            search.addTextChangedListener(object : TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
                override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
                override fun afterTextChanged(s: Editable?) {
                    val q = (s?.toString() ?: "").trim().lowercase()
                    for ((v, l) in rows) v.visibility = if (q.isEmpty() || l.contains(q)) View.VISIBLE else View.GONE
                }
            })

            n27Dialog(a).setTitle("Chọn ứng dụng")
                .setView(root)
                .setPositiveButton("Xong") { _, _ -> onDone(chosen.toSet()) }
                .setNegativeButton("Hủy", null)
                .show()
        } catch (e: Exception) {
        }
    }
}

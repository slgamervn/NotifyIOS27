package app.notifyios27

import android.content.Context
import android.content.SharedPreferences
import android.content.res.Configuration

object Prefs {
    private var sp: SharedPreferences? = null

    fun init(c: Context) {
        if (sp == null) {
            sp = c.applicationContext.getSharedPreferences("n27", Context.MODE_PRIVATE)
        }
    }

    private fun p(): SharedPreferences = sp ?: throw IllegalStateException("Prefs.init not called")

    var bannerEnabled: Boolean
        get() = p().getBoolean("bannerEnabled", true)
        set(v) { p().edit().putBoolean("bannerEnabled", v).apply() }

    var bannerSeconds: Int
        get() = p().getInt("bannerSeconds", 5).coerceIn(2, 10)
        set(v) { p().edit().putInt("bannerSeconds", v.coerceIn(2, 10)).apply() }

    var glass: Float
        get() = p().getFloat("glass", 0.30f).coerceIn(0.15f, 0.80f)
        set(v) { p().edit().putFloat("glass", v.coerceIn(0.15f, 0.80f)).apply() }

    var theme: Int
        get() = p().getInt("theme", 0)
        set(v) { p().edit().putInt("theme", v).apply() }

    var hideOriginal: Boolean
        get() = p().getBoolean("hideOriginal", false)
        set(v) { p().edit().putBoolean("hideOriginal", v).apply() }

    var syncClear: Boolean
        get() = p().getBoolean("syncClear", true)
        set(v) { p().edit().putBoolean("syncClear", v).apply() }

    fun isDark(c: Context): Boolean = when (theme) {
        1 -> false
        2 -> true
        else -> (c.resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) ==
            Configuration.UI_MODE_NIGHT_YES
    }

    fun isAppEnabled(pkg: String): Boolean = p().getBoolean("app_$pkg", true)

    fun setAppEnabled(pkg: String, on: Boolean) {
        p().edit().putBoolean("app_$pkg", on).apply()
    }
}

package app.notifyios27

import android.content.Context
import android.content.SharedPreferences
import android.content.res.Configuration

object Prefs {
    private var sp: SharedPreferences? = null

    fun init(c: Context) {
        if (sp == null) {
            sp = c.applicationContext.getSharedPreferences("n27", Context.MODE_PRIVATE)
        }
    }

    private fun p(): SharedPreferences = sp ?: throw IllegalStateException("Prefs.init not called")

    var bannerEnabled: Boolean
        get() = p().getBoolean("bannerEnabled", true)
        set(v) { p().edit().putBoolean("bannerEnabled", v).apply() }

    var bannerSeconds: Int
        get() = p().getInt("bannerSeconds", 5).coerceIn(2, 10)
        set(v) { p().edit().putInt("bannerSeconds", v.coerceIn(2, 10)).apply() }

    var glass: Float
        get() = p().getFloat("glass", 0.30f).coerceIn(0.15f, 0.80f)
        set(v) { p().edit().putFloat("glass", v.coerceIn(0.15f, 0.80f)).apply() }

    var theme: Int
        get() = p().getInt("theme", 0)
        set(v) { p().edit().putInt("theme", v).apply() }

    var hideOriginal: Boolean
        get() = p().getBoolean("hideOriginal", false)
        set(v) { p().edit().putBoolean("hideOriginal", v).apply() }

    var syncClear: Boolean
        get() = p().getBoolean("syncClear", true)
        set(v) { p().edit().putBoolean("syncClear", v).apply() }

    fun isDark(c: Context): Boolean = when (theme) {
        1 -> false
        2 -> true
        else -> (c.resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) ==
            Configuration.UI_MODE_NIGHT_YES
    }

    fun isAppEnabled(pkg: String): Boolean = p().getBoolean("app_$pkg", true)

    fun setAppEnabled(pkg: String, on: Boolean) {
        p().edit().putBoolean("app_$pkg", on).apply()
    }

    // ---- v2 ----

    var bannerStyle: Int
        get() = p().getInt("bannerStyle", 0).coerceIn(0, 2)
        set(v) { p().edit().putInt("bannerStyle", v.coerceIn(0, 2)).apply() }

    var bannerPosition: Int
        get() = p().getInt("bannerPosition", 0).coerceIn(0, 1)
        set(v) { p().edit().putInt("bannerPosition", v.coerceIn(0, 1)).apply() }

    var fontScale: Float
        get() = p().getFloat("fontScale", 1.0f).coerceIn(0.8f, 1.4f)
        set(v) { p().edit().putFloat("fontScale", v.coerceIn(0.8f, 1.4f)).apply() }

    var soundUri: String
        get() = p().getString("soundUri", "") ?: ""
        set(v) { p().edit().putString("soundUri", v).apply() }

    var haptic: Boolean
        get() = p().getBoolean("haptic", true)
        set(v) { p().edit().putBoolean("haptic", v).apply() }

    var autoCopyOtp: Boolean
        get() = p().getBoolean("autoCopyOtp", false)
        set(v) { p().edit().putBoolean("autoCopyOtp", v).apply() }

    var wallpaperMode: Int
        get() = p().getInt("wallpaperMode", 0).coerceIn(0, 1)
        set(v) { p().edit().putInt("wallpaperMode", v.coerceIn(0, 1)).apply() }

    var wallpaperIndex: Int
        get() = p().getInt("wallpaperIndex", 0).coerceIn(0, 5)
        set(v) { p().edit().putInt("wallpaperIndex", v.coerceIn(0, 5)).apply() }

    var wallpaperPath: String
        get() = p().getString("wallpaperPath", "") ?: ""
        set(v) { p().edit().putString("wallpaperPath", v).apply() }

    var accent: Int
        get() = p().getInt("accent", 0xFF0A84FF.toInt())
        set(v) { p().edit().putInt("accent", v).apply() }

    var reduceMotion: Boolean
        get() = p().getBoolean("reduceMotion", false)
        set(v) { p().edit().putBoolean("reduceMotion", v).apply() }

    var historyDays: Int
        get() {
            val v = p().getInt("historyDays", 30)
            return if (v == 7 || v == 30 || v == 90 || v == 0) v else 30
        }
        set(v) {
            val ok = if (v == 7 || v == 30 || v == 90 || v == 0) v else 30
            p().edit().putInt("historyDays", ok).apply()
        }

    var onboarded: Boolean
        get() = p().getBoolean("onboarded", false)
        set(v) { p().edit().putBoolean("onboarded", v).apply() }

    var lockClockMode: Int
        get() = p().getInt("lockClockMode", 0).coerceIn(0, 1)
        set(v) { p().edit().putInt("lockClockMode", v.coerceIn(0, 1)).apply() }

    var lockKeepScreenOn: Boolean
        get() = p().getBoolean("lockKeepScreenOn", false)
        set(v) { p().edit().putBoolean("lockKeepScreenOn", v).apply() }

    var glassBlur: Boolean
        get() = p().getBoolean("glassBlur", true)
        set(v) { p().edit().putBoolean("glassBlur", v).apply() }

    var glassBlurRadius: Int
        get() = p().getInt("glassBlurRadius", 24).coerceIn(8, 40)
        set(v) { p().edit().putInt("glassBlurRadius", v.coerceIn(8, 40)).apply() }

    var islandEnabled: Boolean
        get() = p().getBoolean("islandEnabled", true)
        set(v) { p().edit().putBoolean("islandEnabled", v).apply() }

    var islandAlwaysOn: Boolean
        get() = p().getBoolean("islandAlwaysOn", false)
        set(v) { p().edit().putBoolean("islandAlwaysOn", v).apply() }

    var islandOffsetY: Int
        get() = p().getInt("islandOffsetY", 6).coerceIn(-20, 60)
        set(v) { p().edit().putInt("islandOffsetY", v.coerceIn(-20, 60)).apply() }

    var islandScale: Float
        get() = p().getFloat("islandScale", 1.0f).coerceIn(0.7f, 1.6f)
        set(v) { p().edit().putFloat("islandScale", v.coerceIn(0.7f, 1.6f)).apply() }

    var islandSources: Int
        get() = p().getInt("islandSources", 255)
        set(v) { p().edit().putInt("islandSources", v).apply() }

    var islandHideLandscape: Boolean
        get() = p().getBoolean("islandHideLandscape", true)
        set(v) { p().edit().putBoolean("islandHideLandscape", v).apply() }

    var islandMediaKeepSec: Int
        get() {
            val v = p().getInt("islandMediaKeepSec", 30)
            return if (v == 10 || v == 30 || v == 120 || v == 0) v else 30
        }
        set(v) {
            val ok = if (v == 10 || v == 30 || v == 120 || v == 0) v else 30
            p().edit().putInt("islandMediaKeepSec", ok).apply()
        }
}

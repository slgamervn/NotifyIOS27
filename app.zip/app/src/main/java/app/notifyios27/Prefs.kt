package app.notifyios27

import android.content.Context
import android.content.SharedPreferences
import android.content.res.Configuration

object Prefs {
    private var sp: SharedPreferences? = null

    fun init(c: Context) {
        if (sp == null) {
            sp = c.applicationContext.getSharedPreferences("n27", Context.MODE_PRIVATE)
        }
    }

    private fun p(): SharedPreferences = sp ?: throw IllegalStateException("Prefs.init not called")

    var bannerEnabled: Boolean
        get() = p().getBoolean("bannerEnabled", true)
        set(v) { p().edit().putBoolean("bannerEnabled", v).apply() }

    var bannerSeconds: Int
        get() = p().getInt("bannerSeconds", 5).coerceIn(2, 10)
        set(v) { p().edit().putInt("bannerSeconds", v.coerceIn(2, 10)).apply() }

    var glass: Float
        get() = p().getFloat("glass", 0.30f).coerceIn(0.15f, 0.80f)
        set(v) { p().edit().putFloat("glass", v.coerceIn(0.15f, 0.80f)).apply() }

    /** 0 auto, 1 light, 2 dark, 3 AMOLED black. */
    var theme: Int
        get() = p().getInt("theme", 0).coerceIn(0, 3)
        set(v) { p().edit().putInt("theme", v.coerceIn(0, 3)).apply() }

    var hideOriginal: Boolean
        get() = p().getBoolean("hideOriginal", false)
        set(v) { p().edit().putBoolean("hideOriginal", v).apply() }

    var syncClear: Boolean
        get() = p().getBoolean("syncClear", true)
        set(v) { p().edit().putBoolean("syncClear", v).apply() }

    fun isDark(c: Context): Boolean = when (theme) {
        1 -> false
        2, 3 -> true
        else -> (c.resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) ==
            Configuration.UI_MODE_NIGHT_YES
    }

    fun isAppEnabled(pkg: String): Boolean = p().getBoolean("app_$pkg", true)

    fun setAppEnabled(pkg: String, on: Boolean) {
        p().edit().putBoolean("app_$pkg", on).apply()
    }

    // ---- v2 ----

    var bannerStyle: Int
        get() = p().getInt("bannerStyle", 0).coerceIn(0, 2)
        set(v) { p().edit().putInt("bannerStyle", v.coerceIn(0, 2)).apply() }

    var bannerPosition: Int
        get() = p().getInt("bannerPosition", 0).coerceIn(0, 1)
        set(v) { p().edit().putInt("bannerPosition", v.coerceIn(0, 1)).apply() }

    var fontScale: Float
        get() = p().getFloat("fontScale", 1.0f).coerceIn(0.8f, 1.4f)
        set(v) { p().edit().putFloat("fontScale", v.coerceIn(0.8f, 1.4f)).apply() }

    var soundUri: String
        get() = p().getString("soundUri", "") ?: ""
        set(v) { p().edit().putString("soundUri", v).apply() }

    var haptic: Boolean
        get() = p().getBoolean("haptic", true)
        set(v) { p().edit().putBoolean("haptic", v).apply() }

    var autoCopyOtp: Boolean
        get() = p().getBoolean("autoCopyOtp", false)
        set(v) { p().edit().putBoolean("autoCopyOtp", v).apply() }

    var wallpaperMode: Int
        get() = p().getInt("wallpaperMode", 0).coerceIn(0, 1)
        set(v) { p().edit().putInt("wallpaperMode", v.coerceIn(0, 1)).apply() }

    var wallpaperIndex: Int
        get() = p().getInt("wallpaperIndex", 0).coerceIn(0, 5)
        set(v) { p().edit().putInt("wallpaperIndex", v.coerceIn(0, 5)).apply() }

    var wallpaperPath: String
        get() = p().getString("wallpaperPath", "") ?: ""
        set(v) { p().edit().putString("wallpaperPath", v).apply() }

    var accent: Int
        get() = p().getInt("accent", 0xFF0A84FF.toInt())
        set(v) { p().edit().putInt("accent", v).apply() }

    var reduceMotion: Boolean
        get() = p().getBoolean("reduceMotion", false)
        set(v) { p().edit().putBoolean("reduceMotion", v).apply() }

    var historyDays: Int
        get() {
            val v = p().getInt("historyDays", 30)
            return if (v == 7 || v == 30 || v == 90 || v == 0) v else 30
        }
        set(v) {
            val ok = if (v == 7 || v == 30 || v == 90 || v == 0) v else 30
            p().edit().putInt("historyDays", ok).apply()
        }

    var onboarded: Boolean
        get() = p().getBoolean("onboarded", false)
        set(v) { p().edit().putBoolean("onboarded", v).apply() }

    var lockClockMode: Int
        get() = p().getInt("lockClockMode", 0).coerceIn(0, 1)
        set(v) { p().edit().putInt("lockClockMode", v.coerceIn(0, 1)).apply() }

    var lockKeepScreenOn: Boolean
        get() = p().getBoolean("lockKeepScreenOn", false)
        set(v) { p().edit().putBoolean("lockKeepScreenOn", v).apply() }

    var glassBlur: Boolean
        get() = p().getBoolean("glassBlur", true)
        set(v) { p().edit().putBoolean("glassBlur", v).apply() }

    var glassBlurRadius: Int
        get() = p().getInt("glassBlurRadius", 24).coerceIn(8, 40)
        set(v) { p().edit().putInt("glassBlurRadius", v.coerceIn(8, 40)).apply() }

    var islandEnabled: Boolean
        get() = p().getBoolean("islandEnabled", true)
        set(v) { p().edit().putBoolean("islandEnabled", v).apply() }

    var islandAlwaysOn: Boolean
        get() = p().getBoolean("islandAlwaysOn", false)
        set(v) { p().edit().putBoolean("islandAlwaysOn", v).apply() }

    var islandOffsetY: Int
        get() = p().getInt("islandOffsetY", 6).coerceIn(-20, 60)
        set(v) { p().edit().putInt("islandOffsetY", v.coerceIn(-20, 60)).apply() }

    var islandScale: Float
        get() = p().getFloat("islandScale", 1.0f).coerceIn(0.7f, 1.6f)
        set(v) { p().edit().putFloat("islandScale", v.coerceIn(0.7f, 1.6f)).apply() }

    var islandSources: Int
        get() = p().getInt("islandSources", 255)
        set(v) { p().edit().putInt("islandSources", v).apply() }

    var islandHideLandscape: Boolean
        get() = p().getBoolean("islandHideLandscape", true)
        set(v) { p().edit().putBoolean("islandHideLandscape", v).apply() }

    var islandBelowCamera: Boolean
        get() = p().getBoolean("islandBelowCamera", true)
        set(v) { p().edit().putBoolean("islandBelowCamera", v).apply() }

    var appEnabled: Boolean
        get() = p().getBoolean("appEnabled", true)
        set(v) { p().edit().putBoolean("appEnabled", v).apply() }

    var bannerHideLandscape: Boolean
        get() = p().getBoolean("bannerHideLandscape", true)
        set(v) { p().edit().putBoolean("bannerHideLandscape", v).apply() }

    var dndMode: Int
        get() = p().getInt("dndMode", 1).coerceIn(0, 2)
        set(v) { p().edit().putInt("dndMode", v.coerceIn(0, 2)).apply() }

    var respectRinger: Boolean
        get() = p().getBoolean("respectRinger", true)
        set(v) { p().edit().putBoolean("respectRinger", v).apply() }

    var islandMediaKeepSec: Int
        get() {
            val v = p().getInt("islandMediaKeepSec", 30)
            return if (v == 10 || v == 30 || v == 120 || v == 0) v else 30
        }
        set(v) {
            val ok = if (v == 10 || v == 30 || v == 120 || v == 0) v else 30
            p().edit().putInt("islandMediaKeepSec", ok).apply()
        }

    // ---- v3 ----

    /** 0 auto, 1 full, 2 balanced, 3 lite. */
    var perfMode: Int
        get() = p().getInt("perfMode", 0).coerceIn(0, 3)
        set(v) { p().edit().putInt("perfMode", v.coerceIn(0, 3)).apply() }

    /** 0 auto (system island when the phone has one), 1 always the app's island, 2 system only. */
    var islandMode: Int
        get() = p().getInt("islandMode", 0).coerceIn(0, 2)
        set(v) { p().edit().putInt("islandMode", v.coerceIn(0, 2)).apply() }

    var volumeHud: Boolean
        get() = p().getBoolean("volumeHud", true)
        set(v) { p().edit().putBoolean("volumeHud", v).apply() }

    /** 0 left, 1 right. */
    var volumeSide: Int
        get() = p().getInt("volumeSide", 0).coerceIn(0, 1)
        set(v) { p().edit().putInt("volumeSide", v.coerceIn(0, 1)).apply() }

    var volumeHapticSteps: Boolean
        get() = p().getBoolean("volumeHapticSteps", true)
        set(v) { p().edit().putBoolean("volumeHapticSteps", v).apply() }

    var ccOverlay: Boolean
        get() = p().getBoolean("ccOverlay", false)
        set(v) { p().edit().putBoolean("ccOverlay", v).apply() }

    /** JSON list of {id, on} in display order; empty means the default set. */
    var ccModules: String
        get() = p().getString("ccModules", "") ?: ""
        set(v) { p().edit().putString("ccModules", v).apply() }

    /** 0 the chosen colour, 1 the system accent (API 31+). */
    var accentMode: Int
        get() = p().getInt("accentMode", 0).coerceIn(0, 1)
        set(v) { p().edit().putInt("accentMode", v.coerceIn(0, 1)).apply() }

    var cornerDp: Int
        get() = p().getInt("cornerDp", 24).coerceIn(12, 36)
        set(v) { p().edit().putInt("cornerDp", v.coerceIn(12, 36)).apply() }

    /** 0 circle, 1 squircle, 2 rounded square, 3 none. */
    var iconShape: Int
        get() = p().getInt("iconShape", 2).coerceIn(0, 3)
        set(v) { p().edit().putInt("iconShape", v.coerceIn(0, 3)).apply() }

    var iconSizeDp: Int
        get() = p().getInt("iconSizeDp", 40).coerceIn(32, 52)
        set(v) { p().edit().putInt("iconSizeDp", v.coerceIn(32, 52)).apply() }

    /** 0 system sans, 1 serif, 2 mono, 3 condensed. */
    var fontFamily: Int
        get() = p().getInt("fontFamily", 0).coerceIn(0, 3)
        set(v) { p().edit().putInt("fontFamily", v.coerceIn(0, 3)).apply() }

    /** 0 hairline, 1 none, 2 stronger. */
    var rimStyle: Int
        get() = p().getInt("rimStyle", 0).coerceIn(0, 2)
        set(v) { p().edit().putInt("rimStyle", v.coerceIn(0, 2)).apply() }

    /** 0 slide from left, 1 from top, 2 drop with bounce, 3 zoom, 4 fade, 5 spring from the edge. */
    var bannerEnter: Int
        get() = p().getInt("bannerEnter", 0).coerceIn(0, 5)
        set(v) { p().edit().putInt("bannerEnter", v.coerceIn(0, 5)).apply() }

    /** 0 slide away, 1 fade, 2 shrink to the icon. */
    var bannerExit: Int
        get() = p().getInt("bannerExit", 0).coerceIn(0, 2)
        set(v) { p().edit().putInt("bannerExit", v.coerceIn(0, 2)).apply() }

    /** 0 spring, 1 smooth, 2 bouncy. */
    var animCurve: Int
        get() = p().getInt("animCurve", 0).coerceIn(0, 2)
        set(v) { p().edit().putInt("animCurve", v.coerceIn(0, 2)).apply() }

    /** 0 stack, 1 one after another, 2 list. */
    var bannerStackMode: Int
        get() = p().getInt("bannerStackMode", 0).coerceIn(0, 2)
        set(v) { p().edit().putInt("bannerStackMode", v.coerceIn(0, 2)).apply() }

    var bannerStackMax: Int
        get() = p().getInt("bannerStackMax", 3).coerceIn(2, 5)
        set(v) { p().edit().putInt("bannerStackMax", v.coerceIn(2, 5)).apply() }

    var animSpeed: Float
        get() = p().getFloat("animSpeed", 1.0f).coerceIn(0.5f, 2.0f)
        set(v) { p().edit().putFloat("animSpeed", v.coerceIn(0.5f, 2.0f)).apply() }
}

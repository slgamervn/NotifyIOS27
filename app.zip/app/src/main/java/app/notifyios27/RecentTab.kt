package app.notifyios27

import android.app.Activity
import android.app.NotificationManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.Build
import android.graphics.Typeface
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.animation.DecelerateInterpolator
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** "Gần đây": pinned items, grouped recent stacks, and snoozed items. */
internal class RecentTab(private val a: Activity) : N27Tab {
    private val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
    private val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT

    private var dark = Prefs.isDark(a)
    private val root = LinearLayout(a)
    private val holder = LinearLayout(a)
    private val emptyText = TextView(a)
    private val search: android.widget.EditText
    private val expanded = HashSet<String>()
    private var justExpanded: String? = null
    private var knownKeys = HashSet<String>()
    private var initialized = false
    private var query = ""
    private val timeViews = ArrayList<Pair<TextView, Long>>()

    private val dndChip = TextView(a)
    private var dndReceiver: BroadcastReceiver? = null

    override val view: View get() = root

    private fun updateDndChip() {
        val on = Dnd.active(a)
        dndChip.visibility = if (on) View.VISIBLE else View.GONE
        if (on) {
            dndChip.setTextColor(UiKit.secondary(dark))
            dndChip.background = UiKit.glass(a, 14f)
        }
    }

    private fun registerDnd() {
        if (dndReceiver != null) return
        val r = object : BroadcastReceiver() {
            override fun onReceive(context: Context?, intent: Intent?) {
                try { updateDndChip() } catch (e: Throwable) { }
            }
        }
        try {
            val f = IntentFilter(NotificationManager.ACTION_INTERRUPTION_FILTER_CHANGED)
            if (Build.VERSION.SDK_INT >= 33) a.registerReceiver(r, f, Context.RECEIVER_NOT_EXPORTED)
            else a.registerReceiver(r, f)
            dndReceiver = r
        } catch (e: Throwable) {
        }
    }

    private fun unregisterDnd() {
        val r = dndReceiver ?: return
        dndReceiver = null
        try { a.unregisterReceiver(r) } catch (e: Throwable) { }
    }

    private fun dp(v: Int): Int = UiKit.dp(a, v)

    init {
        root.orientation = LinearLayout.VERTICAL
        dndChip.text = "Không làm phiền đang bật"
        dndChip.textSize = 13f
        dndChip.gravity = Gravity.CENTER_VERTICAL
        dndChip.setPadding(dp(12), dp(6), dp(12), dp(6))
        val moonIcon = MoonDrawable(UiKit.secondary(dark))
        moonIcon.setBounds(0, 0, dp(14), dp(14))
        dndChip.setCompoundDrawables(moonIcon, null, null, null)
        dndChip.compoundDrawablePadding = dp(6)
        dndChip.visibility = View.GONE
        root.addView(dndChip, LinearLayout.LayoutParams(WRAP, WRAP).apply { bottomMargin = dp(10) })
        search = Cards.searchField(a, "Tìm kiếm", dark) { q ->
            query = q
            rebuild()
        }
        search.id = 0x4E270001
        root.addView(search, LinearLayout.LayoutParams(MATCH, WRAP).apply { bottomMargin = dp(12) })
        holder.orientation = LinearLayout.VERTICAL
        root.addView(holder, LinearLayout.LayoutParams(MATCH, WRAP))
        emptyText.textSize = 17f
        emptyText.gravity = Gravity.CENTER
        emptyText.setPadding(0, dp(70), 0, 0)
        root.addView(emptyText, LinearLayout.LayoutParams(MATCH, WRAP))
    }

    override fun onShow() {
        val d = Prefs.isDark(a)
        if (d != dark) dark = d
        search.background = UiKit.glass(a, 16f)
        updateDndChip()
        registerDnd()
        search.setTextColor(UiKit.primary(dark))
        search.setHintTextColor(UiKit.secondary(dark))
        rebuild()
    }

    override fun onHide() {
        unregisterDnd()
    }

    override fun onStoreChanged() = rebuild()

    override fun onTick() {
        for ((tv, t) in timeViews) tv.text = UiKit.relativeTime(t)
    }

    private fun matches(i: NotifItem, q: String): Boolean {
        if (q.isEmpty()) return true
        return Cards.appLabel(a, i).lowercase().contains(q) ||
            i.title.lowercase().contains(q) ||
            i.text.lowercase().contains(q)
    }

    private fun isNew(key: String): Boolean = initialized && !knownKeys.contains(key)

    private fun slideIn(v: View) {
        if (Prefs.reduceMotion) return
        val w = a.resources.displayMetrics.widthPixels.toFloat()
        v.translationX = -w
        v.alpha = 0f
        v.animate().translationX(0f).alpha(1f).setDuration(Perf.dur(380L))
            .setInterpolator(Perf.SPRING_SOFT).start()
    }

    private fun rowLp(): LinearLayout.LayoutParams =
        LinearLayout.LayoutParams(MATCH, WRAP).apply { bottomMargin = dp(10) }

    private fun rebuild() {
        val q = query.trim().lowercase()
        timeViews.clear()
        holder.removeAllViews()

        val all = NotifStore.all().filter { matches(it, q) }
        val pinned = all.filter { it.pinned }.sortedByDescending { it.time }
        val recent = all.filter { !it.pinned }.sortedByDescending { it.time }
        val snoozed: List<Pair<NotifItem, Long>> = try {
            Snooze.pending(a).filter { matches(it.first, q) }
        } catch (e: Exception) {
            emptyList<Pair<NotifItem, Long>>()
        }

        if (pinned.isNotEmpty()) {
            holder.addView(Cards.sectionHeader(a, "Ghim", dark))
            for (item in pinned) {
                val row = makeRow(item)
                holder.addView(row, rowLp())
                if (isNew(item.key)) slideIn(row)
            }
        }

        if (recent.isNotEmpty()) {
            holder.addView(Cards.sectionHeader(a, "Gần đây", dark))
            val groups = StackViews.group(recent)
            val keys = HashSet<String>()
            for (g in groups) keys.add(StackViews.groupKey(g[0]))
            expanded.retainAll(keys)
            for (g in groups) addGroup(StackViews.groupKey(g[0]), g)
        } else {
            expanded.clear()
        }
        justExpanded = null

        if (snoozed.isNotEmpty()) {
            holder.addView(Cards.sectionHeader(a, "Đang nhắc lại", dark))
            for (p in snoozed) holder.addView(makeSnoozed(p.first, p.second), rowLp())
        }

        val keys = HashSet<String>()
        for (i in NotifStore.all()) keys.add(i.key)
        knownKeys = keys
        initialized = true

        val none = pinned.isEmpty() && recent.isEmpty() && snoozed.isEmpty()
        emptyText.setTextColor(UiKit.secondary(dark))
        emptyText.text = if (q.isEmpty()) "Không có thông báo" else "Không tìm thấy kết quả"
        emptyText.visibility = if (none) View.VISIBLE else View.GONE
    }

    private fun addGroup(key: String, list: List<NotifItem>) {
        val unread = list.count { !it.read }
        val g = StackGroup(
            a, list, dark, expanded.contains(key),
            { item -> Cards.card(a, item.copy(read = unread == 0), dark, false, timeViews) },
            { item -> makeRow(item) },
            { open ->
                if (open) {
                    expanded.add(key)
                    justExpanded = key
                } else {
                    expanded.remove(key)
                }
                rebuild()
            },
            {
                for (item in list) Cards.clearItem(item)
                expanded.remove(key)
            },
            justExpanded == key
        )
        holder.addView(g, rowLp())
        if (isNew(list[0].key)) slideIn(g)
        holder.addView(View(a), LinearLayout.LayoutParams(MATCH, dp(4)))
    }

    private fun makeRow(item: NotifItem): View {
        val card = Cards.card(a, item, dark, true, timeViews)
        return N27SwipeRow(
            a, card,
            { Cards.openItem(a, item) },
            { Cards.clearItem(item) },
            { Cards.snooze(a, item, 60) },
            { Cards.showMenu(a, item) }
        )
    }

    private fun makeSnoozed(item: NotifItem, due: Long): View {
        val row = LinearLayout(a)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        row.setPadding(dp(14), dp(12), dp(14), dp(12))
        row.background = UiKit.glass(a, 24f)
        row.addView(UiKit.iconView(a, item.pkg, 36), LinearLayout.LayoutParams(dp(36), dp(36)))
        val col = LinearLayout(a)
        col.orientation = LinearLayout.VERTICAL
        val title = TextView(a)
        title.text = listOf(Cards.appLabel(a, item), item.title).filter { it.isNotBlank() }.joinToString(" · ")
        title.textSize = 14.5f
        title.typeface = Typeface.DEFAULT_BOLD
        title.setTextColor(UiKit.primary(dark))
        title.maxLines = 1
        title.ellipsize = android.text.TextUtils.TruncateAt.END
        col.addView(title, LinearLayout.LayoutParams(MATCH, WRAP))
        val sub = TextView(a)
        val sameDay = SimpleDateFormat("yyyyMMdd", Locale.US).format(Date(due)) ==
            SimpleDateFormat("yyyyMMdd", Locale.US).format(Date())
        val pattern = if (sameDay) "HH:mm" else "dd/MM HH:mm"
        sub.text = "Nhắc lúc " + SimpleDateFormat(pattern, Locale.US).format(Date(due))
        sub.textSize = 13f
        sub.setTextColor(UiKit.secondary(dark))
        col.addView(sub, LinearLayout.LayoutParams(MATCH, WRAP))
        row.addView(col, LinearLayout.LayoutParams(0, WRAP, 1f).apply { leftMargin = dp(12) })
        row.setOnClickListener {
            try {
                Cards.dialog(a).setTitle("Hủy nhắc lại?")
                    .setMessage(Cards.appLabel(a, item) + "\n" + item.title)
                    .setPositiveButton("Hủy nhắc lại") { _, _ ->
                        try { Snooze.cancel(a, item.key) } catch (e: Exception) { }
                        rebuild()
                    }
                    .setNegativeButton("Đóng", null)
                    .show()
            } catch (e: Exception) {
            }
        }
        return row
    }
}

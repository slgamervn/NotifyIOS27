package app.notifyios27

import android.content.Context
import android.content.SharedPreferences
import org.json.JSONArray
import org.json.JSONObject
import java.util.Calendar
import java.util.Locale

data class Decision(
    val store: Boolean,
    val banner: Boolean,
    val sound: Boolean,
    val timeSensitive: Boolean,
    val summary: Boolean
)

object Rules {
    data class AppRule(
        val pkg: String,
        val banner: Boolean = true,
        val sound: Boolean = true,
        val mutedUntil: Long = 0,
        val alias: String? = null,
        val summary: Boolean = false,
        val island: Boolean = true
    )

    private val lock = Any()

    private fun sp(c: Context): SharedPreferences =
        c.applicationContext.getSharedPreferences("n27_rules", Context.MODE_PRIVATE)

    private fun loadRules(c: Context): MutableList<AppRule> {
        val out = ArrayList<AppRule>()
        try {
            val s = sp(c).getString("apps", null) ?: return out
            val arr = JSONArray(s)
            for (i in 0 until arr.length()) {
                try {
                    val o = arr.getJSONObject(i)
                    out.add(
                        AppRule(
                            pkg = o.getString("pkg"),
                            banner = o.optBoolean("banner", true),
                            sound = o.optBoolean("sound", true),
                            mutedUntil = o.optLong("mutedUntil", 0L),
                            alias = if (o.has("alias") && !o.isNull("alias")) o.getString("alias") else null,
                            summary = o.optBoolean("summary", false),
                            island = o.optBoolean("island", true)
                        )
                    )
                } catch (e: Exception) {
                }
            }
        } catch (e: Exception) {
        }
        return out
    }

    private fun saveRules(c: Context, list: List<AppRule>) {
        val arr = JSONArray()
        for (r in list) {
            val o = JSONObject()
            o.put("pkg", r.pkg)
            o.put("banner", r.banner)
            o.put("sound", r.sound)
            o.put("mutedUntil", r.mutedUntil)
            if (r.alias != null) o.put("alias", r.alias)
            o.put("summary", r.summary)
            o.put("island", r.island)
            arr.put(o)
        }
        sp(c).edit().putString("apps", arr.toString()).apply()
    }

    private fun loadWords(c: Context, key: String): List<String> {
        val out = ArrayList<String>()
        try {
            val s = sp(c).getString(key, null) ?: return out
            val arr = JSONArray(s)
            for (i in 0 until arr.length()) {
                val w = arr.optString(i, "")
                if (w.isNotEmpty()) out.add(w)
            }
        } catch (e: Exception) {
        }
        return out
    }

    private fun saveWords(c: Context, key: String, l: List<String>) {
        val arr = JSONArray()
        val seen = HashSet<String>()
        for (w in l) {
            val t = w.trim()
            if (t.isNotEmpty() && seen.add(t.lowercase(Locale.ROOT))) arr.put(t)
        }
        sp(c).edit().putString(key, arr.toString()).apply()
    }

    private fun matchesAny(hay: String, words: List<String>): Boolean {
        for (w in words) {
            val t = w.trim().lowercase(Locale.ROOT)
            if (t.isNotEmpty() && hay.contains(t)) return true
        }
        return false
    }

    fun appRule(c: Context, pkg: String): AppRule = synchronized(lock) {
        loadRules(c).firstOrNull { it.pkg == pkg } ?: AppRule(pkg)
    }

    fun setAppRule(c: Context, rule: AppRule) {
        synchronized(lock) {
            val list = loadRules(c)
            val idx = list.indexOfFirst { it.pkg == rule.pkg }
            if (idx >= 0) list[idx] = rule else list.add(rule)
            saveRules(c, list)
        }
    }

    fun allRules(c: Context): List<AppRule> = synchronized(lock) { loadRules(c) }

    fun muteApp(c: Context, pkg: String, minutes: Int) {
        val now = System.currentTimeMillis()
        val until = if (minutes < 0) {
            val cal = Calendar.getInstance()
            cal.set(Calendar.HOUR_OF_DAY, 0)
            cal.set(Calendar.MINUTE, 0)
            cal.set(Calendar.SECOND, 0)
            cal.set(Calendar.MILLISECOND, 0)
            cal.add(Calendar.DAY_OF_YEAR, 1)
            cal.timeInMillis
        } else {
            now + minutes * 60000L
        }
        setAppRule(c, appRule(c, pkg).copy(mutedUntil = until))
    }

    fun unmuteApp(c: Context, pkg: String) {
        setAppRule(c, appRule(c, pkg).copy(mutedUntil = 0L))
    }

    fun displayName(c: Context, pkg: String): String {
        val a = appRule(c, pkg).alias
        return if (!a.isNullOrBlank()) a else AppIcons.label(c, pkg)
    }

    fun blockWords(c: Context): List<String> = synchronized(lock) { loadWords(c, "block") }

    fun setBlockWords(c: Context, l: List<String>) {
        synchronized(lock) { saveWords(c, "block", l) }
    }

    fun highlightWords(c: Context): List<String> = synchronized(lock) { loadWords(c, "highlight") }

    fun setHighlightWords(c: Context, l: List<String>) {
        synchronized(lock) { saveWords(c, "highlight", l) }
    }

    fun evaluate(c: Context, item: NotifItem): Decision {
        val hay = (item.title + " " + item.text).lowercase(Locale.ROOT)
        // (1) block words
        if (matchesAny(hay, blockWords(c))) {
            return Decision(store = false, banner = false, sound = false, timeSensitive = false, summary = false)
        }
        val rule = appRule(c, item.pkg)
        val ts = item.timeSensitive || matchesAny(hay, highlightWords(c))

        var banner = true
        var sound = true
        var summary = false

        // (2) app banner off (not cancelled by time sensitive)
        if (!rule.banner) banner = false

        if (!ts) {
            // (3) muted
            if (rule.mutedUntil > System.currentTimeMillis()) {
                banner = false
                sound = false
            }
            // (4) focus
            try {
                if (Focus.active(c) != null && !Focus.isAllowed(c, item)) {
                    banner = false
                    sound = false
                }
            } catch (e: Exception) {
            }
            // (5) summary
            if (rule.summary && Summary.config(c).enabled) {
                banner = false
                summary = true
            }
        }

        // (7) app sound off
        if (!rule.sound) sound = false

        return Decision(store = true, banner = banner, sound = sound, timeSensitive = ts, summary = summary)
    }
}

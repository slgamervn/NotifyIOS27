package app.notifyios27

import android.app.Activity
import android.content.Intent
import android.graphics.Typeface
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class SettingsActivity : Activity() {
    private val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
    private val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT

    private var dark = false
    private val stack = ArrayList<SettingsPage>()
    private lateinit var titleView: TextView
    private lateinit var scroll: ScrollView
    private lateinit var body: LinearLayout
    private val handlers = HashMap<Int, (Intent?) -> Unit>()
    private var nextCode = 1000

    private fun dp(v: Int): Int = UiKit.dp(this, v)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Prefs.init(applicationContext)
        dark = Prefs.isDark(this)
        buildUi()
        stack.add(HubPage())
        val saved = savedInstanceState?.getStringArrayList("stack")
        if (saved != null) {
            for (i in 1 until saved.size) {
                try {
                    val p = Class.forName(saved[i]).getDeclaredConstructor().newInstance()
                    if (p is SettingsPage) stack.add(p)
                } catch (e: Throwable) {
                }
            }
        }
        render()
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        val names = ArrayList<String>()
        for (p in stack) names.add(p.javaClass.name)
        outState.putStringArrayList("stack", names)
    }

    override fun onConfigurationChanged(newConfig: android.content.res.Configuration) {
        super.onConfigurationChanged(newConfig)
        try { window.decorView.requestApplyInsets() } catch (e: Throwable) { }
    }

    private fun buildUi() {
        val root = FrameLayout(this)
        root.background = UiKit.wallpaper(this)
        val column = LinearLayout(this)
        column.orientation = LinearLayout.VERTICAL

        val header = LinearLayout(this)
        header.orientation = LinearLayout.HORIZONTAL
        header.gravity = Gravity.CENTER_VERTICAL
        header.setPadding(dp(16), dp(8), dp(16), dp(8))
        val back = TextView(this)
        back.text = "‹"
        back.textSize = 24f
        back.typeface = Typeface.DEFAULT_BOLD
        back.gravity = Gravity.CENTER
        back.minWidth = dp(40)
        back.minHeight = dp(40)
        back.setTextColor(UiKit.primary(dark))
        back.background = UiKit.glass(this, 20f)
        back.setOnClickListener { goBack() }
        header.addView(back, LinearLayout.LayoutParams(WRAP, WRAP))
        titleView = TextView(this)
        titleView.textSize = 22f
        titleView.typeface = Typeface.DEFAULT_BOLD
        titleView.setTextColor(UiKit.primary(dark))
        titleView.maxLines = 1
        titleView.ellipsize = android.text.TextUtils.TruncateAt.END
        header.addView(titleView, LinearLayout.LayoutParams(0, WRAP, 1f).apply { leftMargin = dp(12) })
        column.addView(header, LinearLayout.LayoutParams(MATCH, WRAP))

        scroll = ScrollView(this)
        scroll.isVerticalScrollBarEnabled = false
        scroll.overScrollMode = View.OVER_SCROLL_NEVER
        body = N27MaxWidthColumn(this, 640)
        body.setPadding(dp(16), dp(4), dp(16), dp(32))
        scroll.addView(body, FrameLayout.LayoutParams(MATCH, WRAP, Gravity.CENTER_HORIZONTAL))
        column.addView(scroll, LinearLayout.LayoutParams(MATCH, 0, 1f))

        root.addView(column, FrameLayout.LayoutParams(MATCH, MATCH))
        setContentView(root)
        UiKit.edgeToEdge(this, root, dark) { l, t, r, b -> column.setPadding(l, t, r, b) }
    }

    private fun push(p: SettingsPage) {
        stack.add(p)
        render()
    }

    private fun render() {
        val page = stack[stack.size - 1]
        titleView.text = page.title
        body.removeAllViews()
        try {
            body.addView(page.build(this) { p -> push(p) }, LinearLayout.LayoutParams(MATCH, WRAP))
        } catch (e: Exception) {
            Toast.makeText(this, "Không mở được trang này", Toast.LENGTH_SHORT).show()
        }
        scroll.scrollTo(0, 0)
    }

    private fun goBack() {
        if (stack.size > 1) {
            stack.removeAt(stack.size - 1)
            render()
        } else {
            finish()
        }
    }

    @Suppress("DEPRECATION", "OVERRIDE_DEPRECATION")
    override fun onBackPressed() {
        goBack()
    }

    override fun onResume() {
        super.onResume()
        if (Prefs.isDark(this) != dark) {
            recreate()
            return
        }
        try { stack[stack.size - 1].onResume() } catch (e: Exception) { }
    }

    /** Starts a picker or file dialog; [handler] gets the result Intent, or null when cancelled. */
    fun startForResult(intent: Intent, handler: (Intent?) -> Unit) {
        val code = nextCode++
        handlers[code] = handler
        try {
            startActivityForResult(intent, code)
        } catch (e: Exception) {
            handlers.remove(code)
            Toast.makeText(this, "Không thể mở màn hình này", Toast.LENGTH_SHORT).show()
        }
    }

    @Suppress("DEPRECATION", "OVERRIDE_DEPRECATION")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        val h = handlers.remove(requestCode) ?: return
        try {
            h(if (resultCode == Activity.RESULT_OK) data else null)
        } catch (e: Exception) {
        }
    }

    private class HubPage : SettingsPage {
        override val title: String = "Cài đặt"

        override fun build(a: Activity, push: (SettingsPage) -> Unit): View {
            val box = LinearLayout(a)
            box.orientation = LinearLayout.VERTICAL
            val s0 = SettingsKit.section(a, null)
            s0.addView(SettingsKit.switchRow(a, "Bật notifyIOS27", "Tắt để app ngừng hiện banner và Dynamic Island", Prefs.appEnabled) {
                Prefs.appEnabled = it
                if (!it) AppSwitch.stopAll(a)
            })
            box.addView(s0, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
            box.addView(SettingsKit.spacer(a, 16))
            val s = SettingsKit.section(a, null)
            fun row(label: String, make: () -> SettingsPage) {
                s.addView(SettingsKit.buttonRow(a, label, null) { push(make()) })
            }
            row("Quyền và tình trạng") { PermissionsPage() }
            row("Banner") { BannerPage() }
            row("Dynamic Island") { IslandPage() }
            row("Âm lượng") { VolumePage() }
            row("Trung tâm điều khiển") { ControlCenterPage() }
            row("Giao diện") { AppearancePage() }
            row("Ứng dụng") { AppRulesPage() }
            row("Bộ lọc") { FiltersPage() }
            row("Focus") { FocusPage() }
            row("Tóm tắt") { SummaryPage() }
            row("Lịch sử và dữ liệu") { DataPage() }
            row("Gửi thông báo thử") { TestPage() }
            row("Giới thiệu") { AboutPage() }
            box.addView(s, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
            return box
        }
    }
}

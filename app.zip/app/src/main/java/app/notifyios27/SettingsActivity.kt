package app.notifyios27

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.ColorDrawable
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.text.Editable
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import kotlin.math.roundToInt

class SettingsActivity : Activity() {
    private val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
    private val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT

    private class AppEntry(val pkg: String, val label: String)

    private class RowHolder(val icon: ImageView, val name: TextView, val sw: Switch)

    private var dark = false
    private lateinit var statusNotif: TextView
    private lateinit var statusOverlay: TextView
    private lateinit var statusBattery: TextView
    private val adapter = AppsAdapter()
    private var allApps: List<AppEntry> = emptyList()
    private var query = ""

    private fun dp(v: Int): Int = UiKit.dp(this, v)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Prefs.init(applicationContext)
        dark = Prefs.isDark(this)
        val ctx: Context = this

        val root = FrameLayout(ctx)
        root.background = UiKit.wallpaper(dark)
        val list = ListView(ctx)
        list.divider = null
        list.dividerHeight = 0
        list.setCacheColorHint(Color.TRANSPARENT)
        list.selector = ColorDrawable(Color.TRANSPARENT)
        list.isVerticalScrollBarEnabled = false
        list.clipToPadding = false
        list.descendantFocusability = ViewGroup.FOCUS_AFTER_DESCENDANTS
        list.addHeaderView(buildHeader(), null, false)
        list.addFooterView(buildFooter(), null, false)
        list.adapter = adapter
        root.addView(list, FrameLayout.LayoutParams(MATCH, MATCH))
        setContentView(root)
        UiKit.edgeToEdge(this, root, dark) { l, t, r, b ->
            list.setPadding(l + dp(16), t + dp(8), r + dp(16), b + dp(24))
        }
        loadAppsAsync()
    }

    override fun onResume() {
        super.onResume()
        refreshPerms()
    }

    // ---------- small builders ----------

    private fun label(text: String, size: Float, color: Int, bold: Boolean = false): TextView {
        val t = TextView(this)
        t.text = text
        t.textSize = size
        t.setTextColor(color)
        if (bold) t.typeface = Typeface.DEFAULT_BOLD
        return t
    }

    private fun card(): LinearLayout {
        val c = LinearLayout(this)
        c.orientation = LinearLayout.VERTICAL
        c.setPadding(dp(16), dp(10), dp(16), dp(10))
        c.background = UiKit.glass(this, 24f)
        return c
    }

    private fun sectionTitle(parent: LinearLayout, text: String) {
        val t = label(text.uppercase(), 12.5f, UiKit.secondary(dark), true)
        parent.addView(t, LinearLayout.LayoutParams(MATCH, WRAP).apply {
            topMargin = dp(20)
            bottomMargin = dp(6)
            leftMargin = dp(8)
        })
    }

    private fun divider(): View {
        val v = View(this)
        v.setBackgroundColor(Color.argb(40, 128, 128, 128))
        return v
    }

    private fun addDivider(parent: LinearLayout) {
        parent.addView(divider(), LinearLayout.LayoutParams(MATCH, 1))
    }

    private fun switchRow(title: String, desc: String?, checked: Boolean, onChange: (Boolean) -> Unit): LinearLayout {
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        row.setPadding(0, dp(8), 0, dp(8))
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.addView(label(title, 16f, UiKit.primary(dark)))
        if (desc != null) col.addView(label(desc, 13f, UiKit.secondary(dark)))
        row.addView(col, LinearLayout.LayoutParams(0, WRAP, 1f))
        val sw = Switch(this)
        sw.isChecked = checked
        sw.setOnCheckedChangeListener { _, on -> onChange(on) }
        row.addView(sw, LinearLayout.LayoutParams(WRAP, WRAP).apply { leftMargin = dp(12) })
        return row
    }

    private fun permRow(title: String, status: TextView, onOpen: () -> Unit): LinearLayout {
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        row.setPadding(0, dp(8), 0, dp(8))
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.addView(label(title, 15.5f, UiKit.primary(dark), true))
        col.addView(status)
        row.addView(col, LinearLayout.LayoutParams(0, WRAP, 1f))
        val b = UiKit.pillButton(this, "Mở cài đặt", true)
        b.setOnClickListener { onOpen() }
        row.addView(b, LinearLayout.LayoutParams(WRAP, WRAP).apply { leftMargin = dp(10) })
        return row
    }

    private fun setStatus(t: TextView, ok: Boolean) {
        t.text = if (ok) "Đã cấp" else "Chưa cấp"
        t.setTextColor(if (ok) UiKit.GREEN else UiKit.RED)
    }

    private fun refreshPerms() {
        setStatus(statusNotif, UiKit.notifAccessGranted(this))
        setStatus(statusOverlay, Settings.canDrawOverlays(this))
        setStatus(statusBattery, UiKit.batteryIgnored(this))
    }

    // ---------- header (sections 1-3 + apps search) ----------

    private fun buildHeader(): View {
        val ctx: Context = this
        val prim = UiKit.primary(dark)
        val sec = UiKit.secondary(dark)
        val head = LinearLayout(ctx)
        head.orientation = LinearLayout.VERTICAL

        // top bar
        val bar = LinearLayout(ctx)
        bar.orientation = LinearLayout.HORIZONTAL
        bar.gravity = Gravity.CENTER_VERTICAL
        val back = TextView(ctx)
        back.text = "←"
        back.textSize = 20f
        back.gravity = Gravity.CENTER
        back.setTextColor(prim)
        back.background = UiKit.glass(ctx, 20f)
        back.setOnClickListener { finish() }
        bar.addView(back, LinearLayout.LayoutParams(dp(40), dp(40)))
        bar.addView(label("Cài đặt", 30f, prim, true), LinearLayout.LayoutParams(WRAP, WRAP).apply { leftMargin = dp(12) })
        head.addView(bar, LinearLayout.LayoutParams(MATCH, WRAP).apply { bottomMargin = dp(4) })

        // (1) permissions
        sectionTitle(head, "Quyền truy cập")
        statusNotif = label("", 13f, sec)
        statusOverlay = label("", 13f, sec)
        statusBattery = label("", 13f, sec)
        val perms = card()
        perms.addView(permRow("Truy cập thông báo", statusNotif) { UiKit.openNotifAccess(ctx) })
        addDivider(perms)
        perms.addView(permRow("Hiển thị trên ứng dụng khác", statusOverlay) { UiKit.openOverlay(ctx) })
        addDivider(perms)
        perms.addView(permRow("Bỏ tối ưu hóa pin", statusBattery) { UiKit.openBattery(ctx) })
        head.addView(perms, LinearLayout.LayoutParams(MATCH, WRAP))

        val help = card()
        help.addView(label("Công tắc bị mờ?", 15f, prim, true))
        help.addView(
            label(
                "Vào Cài đặt > Ứng dụng > notifyIOS27 > menu ⋮ > \"Cho phép cài đặt bị hạn chế\", rồi thử lại.",
                13.5f, sec
            ),
            LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(2); bottomMargin = dp(4) }
        )
        head.addView(help, LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(10) })

        // (2) banner
        sectionTitle(head, "Banner")
        val banner = card()
        banner.addView(switchRow("Bật banner thông báo", null, Prefs.bannerEnabled) { Prefs.bannerEnabled = it })
        addDivider(banner)

        val secLabel = label("", 15f, prim)
        secLabel.setPadding(0, dp(10), 0, 0)
        secLabel.text = "Thời gian hiển thị: ${Prefs.bannerSeconds} giây"
        banner.addView(secLabel)
        val secBar = SeekBar(ctx)
        secBar.max = 8
        secBar.progress = (Prefs.bannerSeconds - 2).coerceIn(0, 8)
        tint(secBar)
        secBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                val v = 2 + p
                secLabel.text = "Thời gian hiển thị: $v giây"
                if (fromUser) Prefs.bannerSeconds = v
            }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        banner.addView(secBar, LinearLayout.LayoutParams(MATCH, WRAP))

        val glassLabel = label("", 15f, prim)
        glassLabel.setPadding(0, dp(10), 0, 0)
        glassLabel.text = "Độ đục kính: ${(Prefs.glass * 100f).roundToInt()}%"
        banner.addView(glassLabel)
        val glassBar = SeekBar(ctx)
        glassBar.max = 65
        glassBar.progress = ((Prefs.glass - 0.15f) * 100f).roundToInt().coerceIn(0, 65)
        tint(glassBar)
        glassBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                val v = 0.15f + p / 100f
                glassLabel.text = "Độ đục kính: ${(v * 100f).roundToInt()}%"
                if (fromUser) Prefs.glass = v
            }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        banner.addView(glassBar, LinearLayout.LayoutParams(MATCH, WRAP))

        val themeLabel = label("Giao diện", 15f, prim)
        themeLabel.setPadding(0, dp(10), 0, dp(6))
        banner.addView(themeLabel)
        val seg = LinearLayout(ctx)
        seg.orientation = LinearLayout.HORIZONTAL
        seg.setPadding(dp(3), dp(3), dp(3), dp(3))
        seg.background = UiKit.rounded(ctx, if (dark) Color.argb(40, 255, 255, 255) else Color.argb(30, 0, 0, 0), 13f)
        val names = listOf("Tự động", "Sáng", "Tối")
        for (idx in names.indices) {
            val b = TextView(ctx)
            b.text = names[idx]
            b.textSize = 14f
            b.gravity = Gravity.CENTER
            b.setPadding(0, dp(8), 0, dp(8))
            val selected = Prefs.theme == idx
            b.setTextColor(if (selected) Color.WHITE else prim)
            if (selected) {
                b.typeface = Typeface.DEFAULT_BOLD
                b.background = UiKit.rounded(ctx, UiKit.ACCENT, 10f)
            }
            b.setOnClickListener {
                if (Prefs.theme != idx) {
                    Prefs.theme = idx
                    recreate()
                }
            }
            seg.addView(b, LinearLayout.LayoutParams(0, WRAP, 1f))
        }
        banner.addView(seg, LinearLayout.LayoutParams(MATCH, WRAP).apply { bottomMargin = dp(6) })
        head.addView(banner, LinearLayout.LayoutParams(MATCH, WRAP))

        // (3) behaviour
        sectionTitle(head, "Hành vi")
        val beh = card()
        beh.addView(switchRow("Ẩn thông báo gốc", "Ẩn thông báo của hệ thống, chỉ hiện trong ứng dụng", Prefs.hideOriginal) {
            Prefs.hideOriginal = it
        })
        addDivider(beh)
        beh.addView(switchRow("Xóa cả thông báo gốc khi xóa trong app", null, Prefs.syncClear) {
            Prefs.syncClear = it
        })
        head.addView(beh, LinearLayout.LayoutParams(MATCH, WRAP))

        // (4) apps: title + search (rows come from the ListView adapter)
        sectionTitle(head, "Ứng dụng")
        val search = EditText(ctx)
        search.hint = "Tìm ứng dụng"
        search.setHintTextColor(sec)
        search.setTextColor(prim)
        search.textSize = 15f
        search.setSingleLine(true)
        search.setPadding(dp(14), dp(10), dp(14), dp(10))
        search.background = UiKit.glass(ctx, 16f)
        search.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: Editable?) {
                query = s?.toString()?.trim() ?: ""
                applyFilter()
            }
        })
        head.addView(search, LinearLayout.LayoutParams(MATCH, WRAP).apply { bottomMargin = dp(6) })

        refreshPerms()
        return head
    }

    private fun tint(bar: SeekBar) {
        val c = ColorStateList.valueOf(UiKit.ACCENT)
        bar.progressTintList = c
        bar.thumbTintList = c
    }

    // ---------- footer: test banner ----------

    private fun buildFooter(): View {
        val ctx: Context = this
        val f = LinearLayout(ctx)
        f.orientation = LinearLayout.VERTICAL
        f.setPadding(0, dp(16), 0, dp(8))
        val b = UiKit.pillButton(ctx, "Gửi thông báo thử", true)
        b.textSize = 16f
        b.setPadding(dp(16), dp(14), dp(16), dp(14))
        b.setOnClickListener { sendTest() }
        f.addView(b, LinearLayout.LayoutParams(MATCH, WRAP))
        return f
    }

    private fun sendTest() {
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Cần cấp quyền hiển thị trên ứng dụng khác", Toast.LENGTH_LONG).show()
            UiKit.openOverlay(this)
            return
        }
        val now = System.currentTimeMillis()
        BannerController.show(
            this,
            NotifItem(
                key = "n27-test-$now",
                pkg = packageName,
                appName = "notifyIOS27",
                title = "Thông báo thử",
                text = "Đây là banner thử nghiệm kiểu iOS 27.",
                time = now
            )
        )
    }

    // ---------- apps list ----------

    private fun loadAppsAsync() {
        Thread {
            val apps = loadApps()
            runOnUiThread {
                if (!isFinishing && !isDestroyed) {
                    allApps = apps
                    applyFilter()
                }
            }
        }.start()
    }

    @Suppress("DEPRECATION")
    private fun loadApps(): List<AppEntry> {
        val pm = packageManager
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val infos = if (Build.VERSION.SDK_INT >= 33)
            pm.queryIntentActivities(intent, PackageManager.ResolveInfoFlags.of(0L))
        else
            pm.queryIntentActivities(intent, 0)
        val seen = HashSet<String>()
        val out = ArrayList<AppEntry>()
        for (ri in infos) {
            val p = ri.activityInfo?.packageName ?: continue
            if (p == packageName || !seen.add(p)) continue
            out.add(AppEntry(p, AppIcons.label(this, p)))
        }
        out.sortBy { it.label.lowercase() }
        return out
    }

    private fun applyFilter() {
        adapter.data = if (query.isEmpty()) allApps else allApps.filter { it.label.contains(query, ignoreCase = true) }
        adapter.notifyDataSetChanged()
    }

    private inner class AppsAdapter : BaseAdapter() {
        var data: List<AppEntry> = emptyList()

        override fun getCount(): Int = data.size
        override fun getItem(position: Int): Any = data[position]
        override fun getItemId(position: Int): Long = position.toLong()

        override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
            val ctx: Context = this@SettingsActivity
            val view: View
            val h: RowHolder
            if (convertView == null) {
                val outer = FrameLayout(ctx)
                outer.setPadding(0, dp(3), 0, dp(3))
                val inner = LinearLayout(ctx)
                inner.orientation = LinearLayout.HORIZONTAL
                inner.gravity = Gravity.CENTER_VERTICAL
                inner.setPadding(dp(12), dp(10), dp(12), dp(10))
                inner.background = UiKit.glass(ctx, 18f)
                val icon = UiKit.roundedIcon(ctx, 36)
                inner.addView(icon, LinearLayout.LayoutParams(dp(36), dp(36)))
                val name = TextView(ctx)
                name.textSize = 15f
                name.maxLines = 1
                name.ellipsize = android.text.TextUtils.TruncateAt.END
                name.setTextColor(UiKit.primary(dark))
                inner.addView(name, LinearLayout.LayoutParams(0, WRAP, 1f).apply {
                    leftMargin = dp(12)
                    rightMargin = dp(8)
                })
                val sw = Switch(ctx)
                inner.addView(sw, LinearLayout.LayoutParams(WRAP, WRAP))
                outer.addView(inner, FrameLayout.LayoutParams(MATCH, WRAP))
                h = RowHolder(icon, name, sw)
                outer.tag = h
                view = outer
            } else {
                view = convertView
                h = convertView.tag as RowHolder
            }
            val e = data[position]
            h.name.text = e.label
            UiKit.bindIcon(h.icon, e.pkg)
            h.sw.setOnCheckedChangeListener(null)
            h.sw.isChecked = Prefs.isAppEnabled(e.pkg)
            h.sw.setOnCheckedChangeListener { _, on -> Prefs.setAppEnabled(e.pkg, on) }
            return view
        }
    }
}

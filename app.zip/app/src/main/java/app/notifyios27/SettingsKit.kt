package app.notifyios27

import android.app.Activity
import android.app.AlertDialog
import android.content.res.ColorStateList
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView

internal fun settingsCaption(a: Activity, text: String): TextView {
    val t = TextView(a)
    t.text = text
    t.textSize = 12.5f
    t.setTextColor(UiKit.secondary(Prefs.isDark(a)))
    t.setPadding(UiKit.dp(a, 6), UiKit.dp(a, 6), UiKit.dp(a, 6), UiKit.dp(a, 2))
    return t
}

internal fun settingsDialog(a: Activity): AlertDialog.Builder {
    val dark = Prefs.isDark(a)
    return AlertDialog.Builder(
        a,
        if (dark) android.R.style.Theme_DeviceDefault_Dialog_Alert
        else android.R.style.Theme_DeviceDefault_Light_Dialog_Alert
    )
}

object SettingsKit {
    private const val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
    private const val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT

    private fun dp(a: Activity, v: Int): Int = UiKit.dp(a, v)

    /** Glass card; rows added to it get thin dividers drawn between them. */
    private class GlassSection(private val act: Activity, private val titleCount: Int) : LinearLayout(act) {
        private val paint = Paint()
        private val inset = UiKit.dp(act, 16).toFloat()

        init {
            paint.color = Color.argb(45, 128, 128, 128)
            paint.strokeWidth = 1f
        }

        override fun dispatchDraw(canvas: Canvas) {
            super.dispatchDraw(canvas)
            val n = childCount
            var i = titleCount
            while (i < n - 1) {
                val c = getChildAt(i)
                if (c.visibility == View.VISIBLE) {
                    val y = c.bottom.toFloat()
                    canvas.drawLine(c.left + inset, y, c.right.toFloat(), y, paint)
                }
                i++
            }
        }
    }

    private fun baseRow(a: Activity): LinearLayout {
        val r = LinearLayout(a)
        r.orientation = LinearLayout.HORIZONTAL
        r.gravity = Gravity.CENTER_VERTICAL
        r.setPadding(dp(a, 16), dp(a, 12), dp(a, 16), dp(a, 12))
        r.minimumHeight = dp(a, 48)
        return r
    }

    private fun labelCol(a: Activity, label: String, sub: String?, labelColor: Int): LinearLayout {
        val dark = Prefs.isDark(a)
        val col = LinearLayout(a)
        col.orientation = LinearLayout.VERTICAL
        val l = TextView(a)
        l.text = label
        l.textSize = 16f
        l.setTextColor(labelColor)
        col.addView(l, LinearLayout.LayoutParams(MATCH, WRAP))
        if (!sub.isNullOrBlank()) {
            val s = TextView(a)
            s.text = sub
            s.textSize = 12.5f
            s.setTextColor(UiKit.secondary(dark))
            col.addView(s, LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(a, 2) })
        }
        return col
    }

    fun section(a: Activity, title: String?): LinearLayout {
        val dark = Prefs.isDark(a)
        val hasTitle = !title.isNullOrBlank()
        val s = GlassSection(a, if (hasTitle) 1 else 0)
        s.orientation = LinearLayout.VERTICAL
        s.background = UiKit.glass(a, 20f)
        if (hasTitle) {
            val t = TextView(a)
            t.text = title
            t.textSize = 13f
            t.typeface = Typeface.DEFAULT_BOLD
            t.setTextColor(UiKit.secondary(dark))
            t.setPadding(dp(a, 16), dp(a, 12), dp(a, 16), dp(a, 2))
            s.addView(t, LinearLayout.LayoutParams(MATCH, WRAP))
        }
        return s
    }

    fun switchRow(a: Activity, label: String, sub: String?, checked: Boolean, onChange: (Boolean) -> Unit): View {
        val dark = Prefs.isDark(a)
        val acc = UiKit.accent(a)
        val row = baseRow(a)
        row.addView(labelCol(a, label, sub, UiKit.primary(dark)), LinearLayout.LayoutParams(0, WRAP, 1f))
        val sw = Switch(a)
        sw.isChecked = checked
        try {
            sw.trackTintList = ColorStateList(
                arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf()),
                intArrayOf(acc, Color.argb(110, 128, 128, 128))
            )
            sw.thumbTintList = ColorStateList.valueOf(Color.WHITE)
        } catch (e: Throwable) {
        }
        sw.setOnCheckedChangeListener { _, c -> onChange(c) }
        row.addView(sw, LinearLayout.LayoutParams(WRAP, WRAP).apply { leftMargin = dp(a, 12) })
        row.setOnClickListener { sw.toggle() }
        return row
    }

    fun sliderRow(
        a: Activity, label: String, min: Float, max: Float, value: Float,
        fmt: (Float) -> String, onChange: (Float) -> Unit
    ): View {
        val dark = Prefs.isDark(a)
        val acc = UiKit.accent(a)
        val range = if (max - min <= 0f) 1f else max - min
        val row = LinearLayout(a)
        row.orientation = LinearLayout.VERTICAL
        row.setPadding(dp(a, 16), dp(a, 12), dp(a, 16), dp(a, 8))
        val top = LinearLayout(a)
        top.orientation = LinearLayout.HORIZONTAL
        val l = TextView(a)
        l.text = label
        l.textSize = 16f
        l.setTextColor(UiKit.primary(dark))
        top.addView(l, LinearLayout.LayoutParams(0, WRAP, 1f))
        val v = TextView(a)
        v.textSize = 14f
        v.setTextColor(UiKit.secondary(dark))
        top.addView(v, LinearLayout.LayoutParams(WRAP, WRAP))
        row.addView(top, LinearLayout.LayoutParams(MATCH, WRAP))
        val sb = SeekBar(a)
        sb.max = 1000
        val start = value.coerceIn(min, min + range)
        sb.progress = ((start - min) / range * 1000f).toInt()
        v.text = fmt(start)
        try {
            sb.progressTintList = ColorStateList.valueOf(acc)
            sb.thumbTintList = ColorStateList.valueOf(acc)
        } catch (e: Throwable) {
        }
        sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                val x = min + progress / 1000f * range
                v.text = fmt(x)
                if (fromUser) onChange(x)
            }

            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })
        row.addView(sb, LinearLayout.LayoutParams(MATCH, WRAP))
        return row
    }

    fun buttonRow(a: Activity, label: String, sub: String?, onClick: () -> Unit): View {
        val dark = Prefs.isDark(a)
        val row = baseRow(a)
        row.addView(labelCol(a, label, sub, UiKit.primary(dark)), LinearLayout.LayoutParams(0, WRAP, 1f))
        val chev = TextView(a)
        chev.text = "›"
        chev.textSize = 22f
        chev.setTextColor(UiKit.secondary(dark))
        row.addView(chev, LinearLayout.LayoutParams(WRAP, WRAP).apply { leftMargin = dp(a, 12) })
        row.setOnClickListener { onClick() }
        return row
    }

    fun segmented(a: Activity, options: List<String>, selected: Int, onSelect: (Int) -> Unit): View {
        val dark = Prefs.isDark(a)
        val acc = UiKit.accent(a)
        val outer = LinearLayout(a)
        outer.setPadding(dp(a, 12), dp(a, 8), dp(a, 12), dp(a, 8))
        val box = LinearLayout(a)
        box.orientation = LinearLayout.HORIZONTAL
        box.setPadding(dp(a, 3), dp(a, 3), dp(a, 3), dp(a, 3))
        box.background = UiKit.rounded(a, if (dark) Color.argb(50, 255, 255, 255) else Color.argb(36, 0, 0, 0), 12f)
        val views = ArrayList<TextView>()
        var sel = selected
        fun style() {
            for ((i, tv) in views.withIndex()) {
                if (i == sel) {
                    tv.setTextColor(Color.WHITE)
                    tv.typeface = Typeface.DEFAULT_BOLD
                    tv.background = UiKit.rounded(a, acc, 10f)
                } else {
                    tv.setTextColor(UiKit.primary(dark))
                    tv.typeface = Typeface.DEFAULT
                    tv.background = null
                }
            }
        }
        for ((i, o) in options.withIndex()) {
            val tv = TextView(a)
            tv.text = o
            tv.textSize = 12.5f
            tv.gravity = Gravity.CENTER
            tv.setPadding(dp(a, 4), dp(a, 8), dp(a, 4), dp(a, 8))
            tv.setOnClickListener {
                if (sel != i) {
                    sel = i
                    style()
                    onSelect(i)
                }
            }
            views.add(tv)
            box.addView(tv, LinearLayout.LayoutParams(0, WRAP, 1f))
        }
        style()
        outer.addView(box, LinearLayout.LayoutParams(MATCH, WRAP))
        return outer
    }

    fun textRow(a: Activity, label: String, value: String): View {
        val dark = Prefs.isDark(a)
        val row = baseRow(a)
        val l = TextView(a)
        l.text = label
        l.textSize = 16f
        l.setTextColor(UiKit.primary(dark))
        row.addView(l, LinearLayout.LayoutParams(WRAP, WRAP))
        val v = TextView(a)
        v.text = value
        v.textSize = 15f
        v.gravity = Gravity.END
        v.setTextColor(UiKit.secondary(dark))
        row.addView(v, LinearLayout.LayoutParams(0, WRAP, 1f).apply { leftMargin = dp(a, 12) })
        return row
    }

    fun confirm(a: Activity, msg: String, onYes: () -> Unit) {
        try {
            settingsDialog(a).setMessage(msg)
                .setPositiveButton("Đồng ý") { _, _ -> onYes() }
                .setNegativeButton("Hủy", null)
                .show()
        } catch (e: Exception) {
        }
    }

    fun inputDialog(a: Activity, title: String, hint: String, initial: String, onDone: (String) -> Unit) {
        try {
            val et = EditText(a)
            et.hint = hint
            et.setText(initial)
            et.setSelection(et.text.length)
            et.setSingleLine(true)
            val holder = LinearLayout(a)
            holder.setPadding(dp(a, 20), dp(a, 8), dp(a, 20), 0)
            holder.addView(et, LinearLayout.LayoutParams(MATCH, WRAP))
            settingsDialog(a).setTitle(title)
                .setView(holder)
                .setPositiveButton("Xong") { _, _ -> onDone(et.text.toString()) }
                .setNegativeButton("Hủy", null)
                .show()
        } catch (e: Exception) {
        }
    }

    fun spacer(a: Activity, dp: Int): View {
        val v = View(a)
        v.layoutParams = LinearLayout.LayoutParams(MATCH, UiKit.dp(a, dp))
        return v
    }
}

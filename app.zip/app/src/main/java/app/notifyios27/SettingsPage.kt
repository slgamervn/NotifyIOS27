package app.notifyios27

import android.app.Activity
import android.view.View

interface SettingsPage {
    val title: String
    fun build(a: Activity, push: (SettingsPage) -> Unit): View
    fun onResume() {}
}

package app.notifyios27

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import org.json.JSONArray
import org.json.JSONObject
import java.util.Calendar

object Snooze {
    private const val ACTION = "app.notifyios27.SNOOZE_FIRE"
    private val lock = Any()

    private fun sp(c: Context): SharedPreferences =
        c.applicationContext.getSharedPreferences("n27_snooze", Context.MODE_PRIVATE)

    private fun load(c: Context): MutableList<JSONObject> {
        val out = ArrayList<JSONObject>()
        try {
            val s = sp(c).getString("items", null) ?: return out
            val arr = JSONArray(s)
            for (i in 0 until arr.length()) out.add(arr.getJSONObject(i))
        } catch (e: Exception) {
        }
        return out
    }

    private fun store(c: Context, list: List<JSONObject>, nextRc: Int? = null) {
        val arr = JSONArray()
        for (o in list) arr.put(o)
        val e = sp(c).edit().putString("items", arr.toString())
        if (nextRc != null) e.putInt("nextRc", nextRc)
        e.apply()
    }

    private fun pendingIntent(c: Context, key: String, rc: Int): PendingIntent {
        val i = Intent(c, AlarmReceiver::class.java)
        i.action = ACTION
        i.putExtra("key", key)
        return PendingIntent.getBroadcast(
            c, rc, i, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
    }

    private fun arm(c: Context, key: String, rc: Int, due: Long) {
        try {
            val am = c.getSystemService(Context.ALARM_SERVICE) as AlarmManager
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, due, pendingIntent(c, key, rc))
        } catch (e: Exception) {
        }
    }

    private fun disarm(c: Context, key: String, rc: Int) {
        try {
            val am = c.getSystemService(Context.ALARM_SERVICE) as AlarmManager
            am.cancel(pendingIntent(c, key, rc))
        } catch (e: Exception) {
        }
    }

    private fun toItem(o: JSONObject, time: Long): NotifItem = NotifItem(
        key = o.getString("key"),
        pkg = o.getString("pkg"),
        appName = o.optString("appName"),
        title = o.optString("title"),
        text = o.optString("text"),
        time = time,
        otp = if (o.has("otp") && !o.isNull("otp")) o.getString("otp") else null
    )

    fun snooze(c: Context, item: NotifItem, minutes: Int) {
        val app = c.applicationContext
        val due = System.currentTimeMillis() + minutes * 60000L
        var rc = 0
        var oldRc = -1
        synchronized(lock) {
            val list = load(app)
            val old = list.firstOrNull { it.optString("key") == item.key }
            if (old != null) {
                oldRc = old.optInt("rc", -1)
                list.remove(old)
            }
            rc = sp(app).getInt("nextRc", 10000)
            val o = JSONObject()
            o.put("key", item.key)
            o.put("pkg", item.pkg)
            o.put("appName", item.appName)
            o.put("title", item.title)
            o.put("text", item.text)
            o.put("time", item.time)
            if (item.otp != null) o.put("otp", item.otp)
            o.put("due", due)
            o.put("rc", rc)
            list.add(o)
            store(app, list, rc + 1)
        }
        if (oldRc >= 0) disarm(app, item.key, oldRc)
        try { NotifStore.remove(item.key) } catch (e: Exception) { }
        arm(app, item.key, rc, due)
    }

    fun minutesUntilTonight(): Int {
        val now = System.currentTimeMillis()
        val cal = Calendar.getInstance()
        cal.set(Calendar.HOUR_OF_DAY, 20)
        cal.set(Calendar.MINUTE, 0)
        cal.set(Calendar.SECOND, 0)
        cal.set(Calendar.MILLISECOND, 0)
        if (cal.timeInMillis <= now) return 180
        val m = ((cal.timeInMillis - now + 59999L) / 60000L).toInt()
        return if (m < 1) 1 else m
    }

    fun pending(c: Context): List<Pair<NotifItem, Long>> {
        val app = c.applicationContext
        val out = ArrayList<Pair<NotifItem, Long>>()
        val list = synchronized(lock) { load(app) }
        for (o in list) {
            try {
                out.add(Pair(toItem(o, o.optLong("time")), o.optLong("due")))
            } catch (e: Exception) {
            }
        }
        out.sortBy { it.second }
        return out
    }

    fun cancel(c: Context, key: String) {
        val app = c.applicationContext
        var rc = -1
        synchronized(lock) {
            val list = load(app)
            val old = list.firstOrNull { it.optString("key") == key }
            if (old != null) {
                rc = old.optInt("rc", -1)
                list.remove(old)
                store(app, list)
            }
        }
        if (rc >= 0) disarm(app, key, rc)
    }

    /** Called by AlarmReceiver (and restore) when a snooze is due: re-adds the item with a fresh time and shows it. */
    fun fire(c: Context, key: String) {
        val app = c.applicationContext
        var entry: JSONObject? = null
        synchronized(lock) {
            val list = load(app)
            val old = list.firstOrNull { it.optString("key") == key }
            if (old != null) {
                entry = old
                list.remove(old)
                store(app, list)
            }
        }
        val o = entry ?: return
        try {
            val item = toItem(o, System.currentTimeMillis())
            try { NotifStore.add(item) } catch (e: Exception) { }
            try { OwnNotif.deliver(app, item, true) } catch (e: Exception) { }
        } catch (e: Exception) {
        }
    }

    fun restore(c: Context) {
        val app = c.applicationContext
        val list = synchronized(lock) { load(app) }
        val now = System.currentTimeMillis()
        for (o in list) {
            try {
                val key = o.getString("key")
                val due = o.optLong("due")
                if (due <= now) fire(app, key) else arm(app, key, o.optInt("rc", 0), due)
            } catch (e: Exception) {
            }
        }
    }
}

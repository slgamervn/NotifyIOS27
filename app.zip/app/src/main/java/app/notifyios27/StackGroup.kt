package app.notifyios27

import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.text.TextUtils
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView

/** Small code-built pieces shared by the banner list, the Recent tab, the floating center and the lock screen. */
internal object StackViews {
    private const val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
    private const val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT

    /** Glass pill button ("Thu gọn", "Xoá", "Xoá tất cả"). */
    fun glassButton(c: Context, text: String, dark: Boolean, onClick: () -> Unit): TextView {
        val t = TextView(c)
        t.text = text
        t.textSize = 13f
        t.typeface = Typeface.DEFAULT_BOLD
        t.gravity = Gravity.CENTER
        t.maxLines = 1
        t.setTextColor(UiKit.primary(dark))
        t.setPadding(UiKit.dp(c, 12), UiKit.dp(c, 6), UiKit.dp(c, 12), UiKit.dp(c, 6))
        t.background = Glass.drawable(c, 16f, true)
        t.minHeight = UiKit.dp(c, 32)
        Perf.pressable(t)
        t.setOnClickListener {
            Perf.haptic(t, Perf.H_KEY)
            try { onClick() } catch (e: Exception) { }
        }
        return t
    }

    /** A compact notification card that works with any Context (overlay windows included). */
    fun card(c: Context, item: NotifItem, dark: Boolean, overlay: Boolean, chip: String?): LinearLayout {
        val card = LinearLayout(c)
        card.orientation = LinearLayout.HORIZONTAL
        card.setPadding(UiKit.dp(c, 14), UiKit.dp(c, 12), UiKit.dp(c, 14), UiKit.dp(c, 12))
        card.background = Glass.drawable(c, 22f, overlay)
        val isz = Prefs.iconSizeDp
        card.addView(UiKit.iconView(c, item.pkg, isz), LinearLayout.LayoutParams(UiKit.dp(c, isz), UiKit.dp(c, isz)))
        val col = LinearLayout(c)
        col.orientation = LinearLayout.VERTICAL
        val top = LinearLayout(c)
        top.orientation = LinearLayout.HORIZONTAL
        top.gravity = Gravity.CENTER_VERTICAL
        val name = TextView(c)
        name.text = if (item.appName.isBlank()) AppIcons.label(c, item.pkg) else item.appName
        name.textSize = 12f
        name.maxLines = 1
        name.ellipsize = TextUtils.TruncateAt.END
        name.setTextColor(UiKit.secondary(dark))
        top.addView(name, LinearLayout.LayoutParams(0, WRAP, 1f))
        if (!chip.isNullOrEmpty()) {
            val ch = TextView(c)
            ch.text = chip
            ch.textSize = 10.5f
            ch.typeface = Typeface.DEFAULT_BOLD
            ch.setTextColor(UiKit.primary(dark))
            ch.setPadding(UiKit.dp(c, 6), UiKit.dp(c, 1), UiKit.dp(c, 6), UiKit.dp(c, 1))
            ch.background = UiKit.flat(c, if (dark) Color.argb(46, 255, 255, 255) else Color.argb(26, 0, 0, 0), 8f)
            top.addView(ch, LinearLayout.LayoutParams(WRAP, WRAP).apply { leftMargin = UiKit.dp(c, 6) })
        }
        val time = TextView(c)
        time.text = UiKit.relativeTime(item.time)
        time.textSize = 12f
        time.setTextColor(UiKit.secondary(dark))
        top.addView(time, LinearLayout.LayoutParams(WRAP, WRAP).apply { leftMargin = UiKit.dp(c, 6) })
        col.addView(top, LinearLayout.LayoutParams(MATCH, WRAP))
        if (item.title.isNotBlank()) {
            val t = TextView(c)
            t.text = item.title
            t.textSize = 15f
            t.typeface = Style.typeface(true)
            t.maxLines = 1
            t.ellipsize = TextUtils.TruncateAt.END
            t.setTextColor(UiKit.primary(dark))
            col.addView(t, LinearLayout.LayoutParams(MATCH, WRAP))
        }
        if (item.text.isNotBlank()) {
            val x = TextView(c)
            x.text = item.text
            x.textSize = 14f
            x.typeface = Style.typeface(false)
            x.maxLines = 2
            x.ellipsize = TextUtils.TruncateAt.END
            x.setTextColor(UiKit.primary(dark))
            col.addView(x, LinearLayout.LayoutParams(MATCH, WRAP))
        }
        card.addView(col, LinearLayout.LayoutParams(0, WRAP, 1f).apply { leftMargin = UiKit.dp(c, 12) })
        return card
    }

    fun groupKey(i: NotifItem): String = i.pkg + "|" + (i.groupKey ?: "")

    /** Groups by app and conversation; groups keep the order of their newest item, pinned items are left out. */
    fun group(items: List<NotifItem>): List<List<NotifItem>> {
        val map = LinkedHashMap<String, MutableList<NotifItem>>()
        for (i in items.sortedByDescending { it.time }) {
            if (i.pinned) continue
            map.getOrPut(groupKey(i)) { ArrayList() }.add(i)
        }
        return map.values.toList()
    }
}

/**
 * One notification group, iOS lock-screen style. Collapsed: newest card, two peeking layers and the count.
 * Expanded: a header with "Thu gọn" and "Xoá", then every row.
 */
internal class StackGroup(
    c: Context,
    private val items: List<NotifItem>,
    private val dark: Boolean,
    expanded: Boolean,
    private val cardFor: (NotifItem) -> View,
    private val rowFor: (NotifItem) -> View,
    private val onToggle: (Boolean) -> Unit,
    private val onClearGroup: () -> Unit,
    animateIn: Boolean = false
) : LinearLayout(c) {

    private fun dp(v: Int): Int = UiKit.dp(context, v)

    init {
        orientation = VERTICAL
        if (items.size <= 1) {
            if (items.isNotEmpty()) addView(rowFor(items[0]), LayoutParams(MATCH, WRAP))
        } else if (!expanded) {
            buildCollapsed()
        } else {
            buildExpanded(animateIn)
        }
    }

    private fun buildCollapsed() {
        val f = FrameLayout(context)
        val l2 = View(context)
        l2.background = UiKit.glass(context, 22f, 0.6f)
        f.addView(l2, FrameLayout.LayoutParams(MATCH, dp(20)).apply {
            gravity = Gravity.BOTTOM
            leftMargin = dp(24)
            rightMargin = dp(24)
        })
        val l1 = View(context)
        l1.background = UiKit.glass(context, 22f, 0.8f)
        f.addView(l1, FrameLayout.LayoutParams(MATCH, dp(20)).apply {
            gravity = Gravity.BOTTOM
            bottomMargin = dp(10)
            leftMargin = dp(12)
            rightMargin = dp(12)
        })
        val card = cardFor(items[0])
        f.addView(card, FrameLayout.LayoutParams(MATCH, WRAP).apply {
            gravity = Gravity.TOP
            bottomMargin = dp(20)
        })
        val count = TextView(context)
        count.text = "${items.size}"
        count.textSize = 11f
        count.typeface = Typeface.DEFAULT_BOLD
        count.gravity = Gravity.CENTER
        count.minWidth = dp(20)
        count.setTextColor(Color.WHITE)
        count.setPadding(dp(6), dp(1), dp(6), dp(1))
        count.background = UiKit.rounded(context, UiKit.accent(context), 10f)
        f.addView(count, FrameLayout.LayoutParams(WRAP, WRAP).apply {
            gravity = Gravity.TOP or Gravity.END
            topMargin = dp(-6)
            rightMargin = dp(-2)
        })
        f.clipChildren = false
        clipChildren = false
        Perf.pressable(f)
        f.setOnClickListener {
            Perf.haptic(f, Perf.H_KEY)
            onToggle(true)
        }
        addView(f, LayoutParams(MATCH, WRAP))
    }

    private fun buildExpanded(animateIn: Boolean) {
        val head = LinearLayout(context)
        head.orientation = HORIZONTAL
        head.gravity = Gravity.CENTER_VERTICAL
        val name = TextView(context)
        val first = items[0]
        name.text = if (first.appName.isBlank()) AppIcons.label(context, first.pkg) else first.appName
        name.textSize = 17f
        name.typeface = Typeface.DEFAULT_BOLD
        name.maxLines = 1
        name.ellipsize = TextUtils.TruncateAt.END
        name.setTextColor(UiKit.primary(dark))
        head.addView(name, LayoutParams(0, WRAP, 1f))
        head.addView(StackViews.glassButton(context, "Thu gọn", dark) { onToggle(false) },
            LayoutParams(WRAP, WRAP).apply { leftMargin = dp(8) })
        head.addView(StackViews.glassButton(context, "Xoá", dark) { onClearGroup() },
            LayoutParams(WRAP, WRAP).apply { leftMargin = dp(8) })
        addView(head, LayoutParams(MATCH, WRAP).apply { bottomMargin = dp(8) })
        val d = if (animateIn) Perf.dur(220L) else 0L
        for ((idx, it) in items.withIndex()) {
            val row = rowFor(it)
            addView(row, LayoutParams(MATCH, WRAP).apply { bottomMargin = dp(8) })
            if (d > 0L && idx < 8) {
                row.alpha = 0f
                row.translationY = -dp(12).toFloat() * (idx + 1).coerceAtMost(3)
                row.animate().alpha(1f).translationY(0f).setStartDelay(idx * 24L)
                    .setDuration(d).setInterpolator(Perf.SPRING_SOFT).start()
            }
        }
    }

    private companion object {
        const val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
        const val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT
    }
}

package app.notifyios27

import java.util.TimeZone

object Stats {
    private const val DAY = 86400000L
    private const val HOUR = 3600000L

    private fun offset(): Long = TimeZone.getDefault().getOffset(System.currentTimeMillis()).toLong()

    fun perApp(days: Int): List<Pair<String, Int>> {
        val cutoff = if (days > 0) System.currentTimeMillis() - days * DAY else 0L
        return History.withDb(emptyList<Pair<String, Int>>()) { db ->
            val out = ArrayList<Pair<String, Int>>()
            val cur = db.rawQuery(
                "SELECT pkg, COUNT(*) AS n FROM history WHERE time >= ? " +
                    "GROUP BY pkg ORDER BY n DESC, pkg ASC LIMIT 10",
                arrayOf(cutoff.toString())
            )
            try {
                while (cur.moveToNext()) out.add(Pair(cur.getString(0) ?: "", cur.getInt(1)))
            } finally {
                cur.close()
            }
            out as List<Pair<String, Int>>
        }
    }

    fun perDay(days: Int): List<Int> {
        if (days <= 0) return emptyList()
        val off = offset()
        val today = (System.currentTimeMillis() + off) / DAY
        val first = today - (days - 1)
        val res = IntArray(days)
        History.withDb(Unit) { db ->
            val cur = db.rawQuery(
                "SELECT (time + ?) / ? AS d, COUNT(*) FROM history WHERE time >= ? GROUP BY d",
                arrayOf(off.toString(), DAY.toString(), (first * DAY - off).toString())
            )
            try {
                while (cur.moveToNext()) {
                    val idx = (cur.getLong(0) - first).toInt()
                    if (idx in 0 until days) res[idx] += cur.getInt(1)
                }
            } finally {
                cur.close()
            }
            Unit
        }
        return res.toList()
    }

    fun perHour(days: Int): IntArray {
        val res = IntArray(24)
        val off = offset()
        val cutoff = if (days > 0) System.currentTimeMillis() - days * DAY else 0L
        History.withDb(Unit) { db ->
            val cur = db.rawQuery(
                "SELECT ((time + ?) / ?) % 24 AS h, COUNT(*) FROM history WHERE time >= ? GROUP BY h",
                arrayOf(off.toString(), HOUR.toString(), cutoff.toString())
            )
            try {
                while (cur.moveToNext()) {
                    val h = cur.getInt(0)
                    if (h in 0..23) res[h] += cur.getInt(1)
                }
            } finally {
                cur.close()
            }
            Unit
        }
        return res
    }
}

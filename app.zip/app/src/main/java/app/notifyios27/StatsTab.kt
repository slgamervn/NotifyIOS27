package app.notifyios27

import android.app.Activity
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.text.TextUtils
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.TextView
import java.util.Calendar

/** Vertical bar chart drawn on a Canvas. */
internal class N27BarChart(ctx: Context) : View(ctx) {
    private val d = ctx.resources.displayMetrics.density
    private val barPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val labelPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val valuePaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rect = RectF()
    private var values = IntArray(0)
    private var labels: Array<String> = emptyArray()
    private var labelEvery = 1
    private var showValues = false
    private var color = Color.BLUE
    private var hMul = 1

    init {
        labelPaint.textAlign = Paint.Align.CENTER
        labelPaint.textSize = 11f * d
        valuePaint.textAlign = Paint.Align.CENTER
        valuePaint.textSize = 11f * d
        valuePaint.typeface = Typeface.DEFAULT_BOLD
    }

    fun setData(
        v: IntArray, l: Array<String>, every: Int, values_: Boolean,
        accent: Int, textColor: Int, heightDp: Int
    ) {
        values = v
        labels = l
        labelEvery = if (every < 1) 1 else every
        showValues = values_
        color = accent
        labelPaint.color = textColor
        valuePaint.color = textColor
        hMul = heightDp
        requestLayout()
        invalidate()
    }

    override fun onMeasure(wSpec: Int, hSpec: Int) {
        setMeasuredDimension(View.MeasureSpec.getSize(wSpec), (hMul * d).toInt())
    }

    override fun onDraw(canvas: Canvas) {
        val n = values.size
        if (n == 0) return
        var maxV = 1
        for (x in values) if (x > maxV) maxV = x
        val w = width.toFloat()
        val labelH = 18f * d
        val topPad = if (showValues) 16f * d else 4f * d
        val chartH = height - labelH - topPad
        if (chartH <= 0f) return
        val slot = w / n
        val barW = slot * 0.6f
        val radius = Math.min(barW / 2f, 6f * d)
        val base = topPad + chartH
        for (i in 0 until n) {
            val v = values[i]
            val cx = slot * i + slot / 2f
            val h = if (v <= 0) 2f * d else Math.max(3f * d, chartH * v / maxV)
            barPaint.color = color
            barPaint.alpha = if (v == maxV && v > 0) 255 else 150
            rect.set(cx - barW / 2f, base - h, cx + barW / 2f, base)
            canvas.drawRoundRect(rect, radius, radius, barPaint)
            if (showValues && v > 0) {
                canvas.drawText(v.toString(), cx, base - h - 4f * d, valuePaint)
            }
            if (i % labelEvery == 0 && i < labels.size) {
                canvas.drawText(labels[i], cx, height - 3f * d, labelPaint)
            }
        }
    }
}

/** Horizontal progress-style bar. */
internal class N27HBar(ctx: Context) : View(ctx) {
    private val track = Paint(Paint.ANTI_ALIAS_FLAG)
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rect = RectF()
    private var frac = 0f

    fun set(f: Float, accent: Int, trackColor: Int) {
        frac = f.coerceIn(0f, 1f)
        fill.color = accent
        track.color = trackColor
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        val h = height.toFloat()
        val w = width.toFloat()
        if (w <= 0f || h <= 0f) return
        rect.set(0f, 0f, w, h)
        canvas.drawRoundRect(rect, h / 2f, h / 2f, track)
        val fw = Math.max(h, w * frac)
        rect.set(0f, 0f, Math.min(fw, w), h)
        canvas.drawRoundRect(rect, h / 2f, h / 2f, fill)
    }
}

/** "Thống kê": 7-day chart, hour-of-day chart and top apps. */
internal class StatsTab(private val a: Activity) : N27Tab {
    private val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
    private val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT
    private val root = LinearLayout(a)
    private var dark = Prefs.isDark(a)

    override val view: View get() = root

    private fun dp(v: Int): Int = UiKit.dp(a, v)

    init {
        root.orientation = LinearLayout.VERTICAL
    }

    override fun onShow() {
        dark = Prefs.isDark(a)
        build()
    }

    override fun onHide() {}

    override fun onStoreChanged() {}

    override fun onTick() {}

    private fun cardBox(title: String): LinearLayout {
        val box = LinearLayout(a)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(dp(16), dp(14), dp(16), dp(14))
        box.background = UiKit.glass(a, 24f)
        val t = TextView(a)
        t.text = title
        t.textSize = 15f
        t.typeface = Typeface.DEFAULT_BOLD
        t.setTextColor(UiKit.primary(dark))
        box.addView(t, LinearLayout.LayoutParams(MATCH, WRAP).apply { bottomMargin = dp(8) })
        return box
    }

    private fun addBox(box: View) {
        root.addView(box, LinearLayout.LayoutParams(MATCH, WRAP).apply { bottomMargin = dp(12) })
    }

    private fun build() {
        root.removeAllViews()
        val acc = UiKit.accent(a)
        val sec = UiKit.secondary(dark)
        val days: List<Int> = try { Stats.perDay(7) } catch (e: Exception) { emptyList<Int>() }
        val hours: IntArray = try { Stats.perHour(7) } catch (e: Exception) { IntArray(24) }
        val apps: List<Pair<String, Int>> = try { Stats.perApp(7) } catch (e: Exception) { emptyList<Pair<String, Int>>() }

        if (days.sum() == 0 && hours.sum() == 0 && apps.isEmpty()) {
            val t = TextView(a)
            t.text = "Chưa có dữ liệu thống kê"
            t.textSize = 17f
            t.gravity = Gravity.CENTER
            t.setTextColor(sec)
            t.setPadding(0, dp(70), 0, 0)
            root.addView(t, LinearLayout.LayoutParams(MATCH, WRAP))
            return
        }

        // 7-day chart (oldest first, last = today)
        val dayBox = cardBox("7 ngày qua")
        val dayChart = N27BarChart(a)
        val n = days.size
        val dayLabels = Array(n) { i ->
            val c = Calendar.getInstance()
            c.add(Calendar.DAY_OF_YEAR, -(n - 1 - i))
            val dow = c.get(Calendar.DAY_OF_WEEK)
            if (dow == Calendar.SUNDAY) "CN" else "T$dow"
        }
        dayChart.setData(days.toIntArray(), dayLabels, 1, true, acc, sec, 170)
        dayBox.addView(dayChart, LinearLayout.LayoutParams(MATCH, WRAP))
        addBox(dayBox)

        // 24-hour chart
        val hourBox = cardBox("Theo giờ trong ngày")
        val hourChart = N27BarChart(a)
        val hourLabels = Array(24) { h -> h.toString() }
        hourChart.setData(hours, hourLabels, 3, false, acc, sec, 150)
        hourBox.addView(hourChart, LinearLayout.LayoutParams(MATCH, WRAP))
        addBox(hourBox)

        // top apps
        if (apps.isNotEmpty()) {
            val appBox = cardBox("Ứng dụng nhiều nhất")
            val maxC = Math.max(1, apps[0].second)
            val trackColor = if (dark) Color.argb(40, 255, 255, 255) else Color.argb(30, 0, 0, 0)
            for (p in apps) {
                val row = LinearLayout(a)
                row.orientation = LinearLayout.HORIZONTAL
                row.gravity = Gravity.CENTER_VERTICAL
                row.addView(UiKit.iconView(a, p.first, 32), LinearLayout.LayoutParams(dp(32), dp(32)))
                val col = LinearLayout(a)
                col.orientation = LinearLayout.VERTICAL
                val line = LinearLayout(a)
                line.orientation = LinearLayout.HORIZONTAL
                val name = TextView(a)
                name.text = AppIcons.label(a, p.first)
                name.textSize = 14f
                name.setTextColor(UiKit.primary(dark))
                name.maxLines = 1
                name.ellipsize = TextUtils.TruncateAt.END
                line.addView(name, LinearLayout.LayoutParams(0, WRAP, 1f))
                val cnt = TextView(a)
                cnt.text = p.second.toString()
                cnt.textSize = 13.5f
                cnt.typeface = Typeface.DEFAULT_BOLD
                cnt.setTextColor(sec)
                line.addView(cnt, LinearLayout.LayoutParams(WRAP, WRAP).apply { leftMargin = dp(8) })
                col.addView(line, LinearLayout.LayoutParams(MATCH, WRAP))
                val bar = N27HBar(a)
                bar.set(p.second.toFloat() / maxC, acc, trackColor)
                col.addView(bar, LinearLayout.LayoutParams(MATCH, dp(8)).apply { topMargin = dp(4) })
                row.addView(col, LinearLayout.LayoutParams(0, WRAP, 1f).apply { leftMargin = dp(12) })
                appBox.addView(row, LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(8) })
            }
            addBox(appBox)
        }
    }
}

package app.notifyios27

import android.content.Context
import android.graphics.Typeface

/** Resolved per-notification look and feedback: the app rule wins over the global settings. */
data class ResolvedStyle(val accent: Int, val soundUri: String, val haptic: Int)

object Style {
    const val HAPTIC_DEFAULT = 0
    const val HAPTIC_OFF = 1
    const val HAPTIC_LIGHT = 2
    const val HAPTIC_STRONG = 3

    fun resolve(c: Context, item: NotifItem): ResolvedStyle {
        val r = try { Rules.appRule(c, item.pkg) } catch (e: Throwable) { null }
        val accent = if (r != null && r.accentColor != 0) r.accentColor else UiKit.accent(c)
        val sound = if (r != null && r.soundUri.isNotEmpty()) r.soundUri else Prefs.soundUri
        return ResolvedStyle(accent, sound, r?.hapticStyle ?: HAPTIC_DEFAULT)
    }

    val FONTS = listOf("Hệ thống", "Serif", "Mono", "Hẹp")

    private val families = arrayOf("sans-serif", "serif", "monospace", "sans-serif-condensed")

    /** System font family chosen in Appearance. */
    fun typeface(bold: Boolean): Typeface {
        val f = families[(try { Prefs.fontFamily } catch (e: Throwable) { 0 }).coerceIn(0, 3)]
        return Typeface.create(f, if (bold) Typeface.BOLD else Typeface.NORMAL)
    }
}

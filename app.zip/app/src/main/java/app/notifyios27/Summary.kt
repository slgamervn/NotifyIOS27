package app.notifyios27

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import org.json.JSONArray
import org.json.JSONObject
import java.util.Calendar

object Summary {
    data class Config(
        val enabled: Boolean = false,
        val times: List<Int> = listOf(480, 1080),
        val apps: Set<String> = emptySet()
    )

    private const val ACTION = "app.notifyios27.SUMMARY_FIRE"
    private const val REQ = 7001
    private val lock = Any()

    private fun sp(c: Context): SharedPreferences =
        c.applicationContext.getSharedPreferences("n27_summary", Context.MODE_PRIVATE)

    fun config(c: Context): Config = synchronized(lock) {
        val p = sp(c)
        var times: List<Int> = listOf(480, 1080)
        try {
            val s = p.getString("times", null)
            if (s != null) {
                val arr = JSONArray(s)
                val l = ArrayList<Int>()
                for (i in 0 until arr.length()) l.add(arr.getInt(i))
                times = l
            }
        } catch (e: Exception) {
        }
        val apps = HashSet<String>()
        try {
            val s = p.getString("apps", null)
            if (s != null) {
                val arr = JSONArray(s)
                for (i in 0 until arr.length()) apps.add(arr.getString(i))
            }
        } catch (e: Exception) {
        }
        Config(p.getBoolean("enabled", false), times, apps)
    }

    fun save(c: Context, cfg: Config) {
        synchronized(lock) {
            val t = JSONArray()
            for (m in cfg.times) t.put(m)
            val a = JSONArray()
            for (s in cfg.apps) a.put(s)
            sp(c).edit()
                .putBoolean("enabled", cfg.enabled)
                .putString("times", t.toString())
                .putString("apps", a.toString())
                .apply()
        }
    }

    private fun loadCounts(c: Context): JSONObject {
        return try {
            JSONObject(sp(c).getString("counts", null) ?: "{}")
        } catch (e: Exception) {
            JSONObject()
        }
    }

    fun defer(c: Context, item: NotifItem) {
        synchronized(lock) {
            val o = loadCounts(c)
            o.put(item.pkg, o.optInt(item.pkg, 0) + 1)
            sp(c).edit().putString("counts", o.toString()).apply()
        }
    }

    fun pendingCount(c: Context): Int = synchronized(lock) {
        val o = loadCounts(c)
        var n = 0
        val it = o.keys()
        while (it.hasNext()) n += o.optInt(it.next(), 0)
        n
    }

    fun deliverNow(c: Context) {
        val app = c.applicationContext
        val pairs = ArrayList<Pair<String, Int>>()
        synchronized(lock) {
            val o = loadCounts(app)
            val it = o.keys()
            while (it.hasNext()) {
                val k = it.next()
                val n = o.optInt(k, 0)
                if (n > 0) pairs.add(Pair(k, n))
            }
            if (pairs.isEmpty()) return
            sp(app).edit().putString("counts", "{}").apply()
        }
        pairs.sortByDescending { it.second }
        var total = 0
        for (p in pairs) total += p.second
        val sb = StringBuilder()
        for (p in pairs) {
            if (sb.isNotEmpty()) sb.append(" · ")
            sb.append(Rules.displayName(app, p.first)).append(' ').append(p.second)
        }
        val now = System.currentTimeMillis()
        val item = NotifItem(
            key = "n27-summary-$now",
            pkg = app.packageName,
            appName = "Tóm tắt thông báo",
            title = "Có $total thông báo mới",
            text = sb.toString(),
            time = now
        )
        try { NotifStore.add(item) } catch (e: Exception) { }
        try { BannerController.show(app, item, true) } catch (e: Exception) { }
    }

    private fun pendingIntent(c: Context): PendingIntent {
        val i = Intent(c, AlarmReceiver::class.java)
        i.action = ACTION
        return PendingIntent.getBroadcast(
            c, REQ, i, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
    }

    fun reschedule(c: Context) {
        val app = c.applicationContext
        try {
            val am = app.getSystemService(Context.ALARM_SERVICE) as AlarmManager
            val pi = pendingIntent(app)
            val cfg = config(app)
            if (!cfg.enabled || cfg.times.isEmpty()) {
                am.cancel(pi)
                return
            }
            val now = System.currentTimeMillis()
            var best = Long.MAX_VALUE
            for (m in cfg.times) {
                val cal = Calendar.getInstance()
                cal.set(Calendar.HOUR_OF_DAY, (m / 60).coerceIn(0, 23))
                cal.set(Calendar.MINUTE, (m % 60).coerceIn(0, 59))
                cal.set(Calendar.SECOND, 0)
                cal.set(Calendar.MILLISECOND, 0)
                if (cal.timeInMillis <= now) cal.add(Calendar.DAY_OF_YEAR, 1)
                if (cal.timeInMillis < best) best = cal.timeInMillis
            }
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, best, pi)
        } catch (e: Exception) {
        }
    }
}

package app.notifyios27

import android.app.Activity
import android.app.TimePickerDialog
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.TextView

internal fun n27Hm(min: Int): String = String.format(java.util.Locale.US, "%02d:%02d", min / 60, min % 60)

class SummaryPage : SettingsPage {
    override val title: String = "Tóm tắt"
    private var root: LinearLayout? = null
    private var act: Activity? = null

    override fun build(a: Activity, push: (SettingsPage) -> Unit): View {
        act = a
        val r = LinearLayout(a)
        r.orientation = LinearLayout.VERTICAL
        root = r
        render()
        return r
    }

    override fun onResume() {
        render()
    }

    private fun update(a: Activity, times: List<Int>?, enabled: Boolean?) {
        val cfg = Summary.config(a)
        Summary.save(a, cfg.copy(enabled = enabled ?: cfg.enabled, times = times ?: cfg.times))
        Summary.reschedule(a)
    }

    private fun render() {
        val a = act ?: return
        val r = root ?: return
        val dark = Prefs.isDark(a)
        val cfg = Summary.config(a)
        r.removeAllViews()
        val mp = ViewGroup.LayoutParams.MATCH_PARENT
        val wc = ViewGroup.LayoutParams.WRAP_CONTENT

        val top = SettingsKit.section(a, null)
        top.addView(SettingsKit.switchRow(a, "Bật tóm tắt", "Gom thông báo của các ứng dụng đã chọn và gửi vào giờ định sẵn", cfg.enabled) {
            update(a, null, it)
        })
        r.addView(top, LinearLayout.LayoutParams(mp, wc))
        r.addView(SettingsKit.spacer(a, 8))

        val sec = SettingsKit.section(a, "Giờ gửi")
        for (m in cfg.times.sorted()) {
            val row = LinearLayout(a)
            row.orientation = LinearLayout.HORIZONTAL
            row.gravity = Gravity.CENTER_VERTICAL
            row.setPadding(UiKit.dp(a, 16), UiKit.dp(a, 6), UiKit.dp(a, 8), UiKit.dp(a, 6))
            val tv = TextView(a)
            tv.text = n27Hm(m)
            tv.textSize = 17f
            tv.setTextColor(UiKit.primary(dark))
            row.addView(tv, LinearLayout.LayoutParams(0, wc, 1f))
            val del = TextView(a)
            del.text = "✕"
            del.textSize = 18f
            del.gravity = Gravity.CENTER
            del.setTextColor(UiKit.secondary(dark))
            del.setPadding(UiKit.dp(a, 12), UiKit.dp(a, 10), UiKit.dp(a, 12), UiKit.dp(a, 10))
            del.setOnClickListener {
                update(a, Summary.config(a).times.filter { it != m }, null)
                render()
            }
            row.addView(del, LinearLayout.LayoutParams(wc, wc))
            sec.addView(row, LinearLayout.LayoutParams(mp, wc))
        }
        sec.addView(SettingsKit.buttonRow(a, "Thêm giờ", null) {
            try {
                TimePickerDialog(a, { _, h, mi ->
                    val v = h * 60 + mi
                    val cur = Summary.config(a).times
                    if (!cur.contains(v)) update(a, (cur + v).sorted(), null)
                    render()
                }, 8, 0, true).show()
            } catch (e: Exception) {
            }
        })
        r.addView(sec, LinearLayout.LayoutParams(mp, wc))
        r.addView(SettingsKit.spacer(a, 8))

        val pending = Summary.pendingCount(a)
        val act2 = SettingsKit.section(a, null)
        act2.addView(SettingsKit.textRow(a, "Đang chờ gửi", "$pending thông báo"))
        act2.addView(SettingsKit.buttonRow(a, "Gửi tóm tắt ngay", null) {
            Summary.deliverNow(a)
            render()
        })
        r.addView(act2, LinearLayout.LayoutParams(mp, wc))
        r.addView(n27Note(a, "Các ứng dụng cần gom vào tóm tắt được chọn trong mục Ứng dụng (công tắc “Gộp vào tóm tắt”)."))
    }
}

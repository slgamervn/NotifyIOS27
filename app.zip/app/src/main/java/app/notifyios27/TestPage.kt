package app.notifyios27

import android.app.Activity
import android.app.PendingIntent
import android.app.RemoteInput
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.Toast

class TestPage : SettingsPage {
    override val title: String = "Gửi thông báo thử"
    private var seq = 0

    override fun build(a: Activity, push: (SettingsPage) -> Unit): View {
        val b = LinearLayout(a)
        b.orientation = LinearLayout.VERTICAL
        val wrap = ViewGroup.LayoutParams.WRAP_CONTENT
        val match = ViewGroup.LayoutParams.MATCH_PARENT
        val s = SettingsKit.section(a, "Banner thử")
        s.addView(SettingsKit.buttonRow(a, "Thông báo thường", null) { send(a, sample(a, "Thông báo thử", "Đây là một thông báo thử.")) })
        s.addView(SettingsKit.buttonRow(a, "Có mã OTP", null) {
            send(a, sample(a, "Ngân hàng", "Mã xác thực của bạn là 482913", otp = "482913"))
        })
        s.addView(SettingsKit.buttonRow(a, "Có nút trả lời", null) {
            send(a, sample(a, "Tin nhắn", "Bạn có rảnh tối nay không?", actions = listOf(replyAction(a))))
        })
        s.addView(SettingsKit.buttonRow(a, "Có ảnh", null) {
            send(a, sample(a, "Ảnh mới", "Một bức ảnh vừa được gửi cho bạn.", picture = makePicture()))
        })
        s.addView(SettingsKit.buttonRow(a, "Time Sensitive", null) {
            send(a, sample(a, "Khẩn cấp", "Thông báo quan trọng cần xem ngay.", urgent = true))
        })
        s.addView(SettingsKit.buttonRow(a, "Gửi 5 thông báo liên tiếp", null) { burst(a) })
        b.addView(s, LinearLayout.LayoutParams(match, wrap))
        return b
    }

    private fun sample(
        a: Activity, title: String, text: String, otp: String? = null,
        actions: List<NotifAction> = emptyList(), picture: Bitmap? = null, urgent: Boolean = false
    ): NotifItem {
        seq++
        val now = System.currentTimeMillis()
        return NotifItem(
            key = "n27-test-$now-$seq",
            pkg = a.packageName,
            appName = "notifyIOS27",
            title = title,
            text = text,
            time = now,
            timeSensitive = urgent,
            otp = otp,
            actions = actions,
            bigPicture = picture
        )
    }

    private fun replyAction(a: Activity): NotifAction {
        val ri = RemoteInput.Builder("reply").setLabel("Trả lời").build()
        val intent = Intent("app.notifyios27.TEST_REPLY")
        intent.setPackage(a.packageName)
        val flags = PendingIntent.FLAG_UPDATE_CURRENT or
            (if (Build.VERSION.SDK_INT >= 31) PendingIntent.FLAG_MUTABLE else 0)
        val pi = PendingIntent.getBroadcast(a, 27, intent, flags)
        return NotifAction("Trả lời", pi, "reply", arrayOf(ri))
    }

    private fun makePicture(): Bitmap {
        val bmp = Bitmap.createBitmap(640, 320, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        p.color = Color.parseColor("#3C4A3E")
        c.drawRect(0f, 0f, 640f, 320f, p)
        p.color = Color.parseColor("#D8CFC4")
        c.drawCircle(470f, 120f, 64f, p)
        return bmp
    }

    private fun send(a: Activity, item: NotifItem) {
        val ok = try { Settings.canDrawOverlays(a) } catch (e: Exception) { false }
        if (!ok) {
            try { Toast.makeText(a, "Cần cấp quyền hiển thị trên ứng dụng khác", Toast.LENGTH_LONG).show() } catch (e: Exception) { }
            UiKit.openOverlay(a)
            return
        }
        try {
            BannerController.show(a, item, true)
        } catch (e: Exception) {
        }
    }

    private fun burst(a: Activity) {
        val ok = try { Settings.canDrawOverlays(a) } catch (e: Exception) { false }
        if (!ok) {
            send(a, sample(a, "", ""))
            return
        }
        val h = Handler(Looper.getMainLooper())
        for (i in 1..5) {
            h.postDelayed({
                send(a, sample(a, "Tin nhắn thử $i", "Đây là thông báo thử số $i trong 5."))
            }, (i - 1) * 1000L)
        }
    }
}

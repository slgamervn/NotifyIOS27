package app.notifyios27

import android.content.Context
import android.graphics.Color
import android.os.Build

/** Personal look: accent source, AMOLED, corner radius, icon shape and the four presets. */
object Theme {
    /** 12 flat accents. */
    val PALETTE = intArrayOf(
        0xFF0A84FF.toInt(), 0xFF30D158.toInt(), 0xFFFF9F0A.toInt(), 0xFFFF453A.toInt(),
        0xFFBF5AF2.toInt(), 0xFFFF375F.toInt(), 0xFF64D2FF.toInt(), 0xFFFFD60A.toInt(),
        0xFF5E5CE6.toInt(), 0xFFAC8E68.toInt(), 0xFF8E8E93.toInt(), 0xFF1C1C1E.toInt()
    )

    fun systemAccentAvailable(): Boolean = Build.VERSION.SDK_INT >= 31

    fun accent(c: Context): Int {
        if (Prefs.accentMode == 1 && Build.VERSION.SDK_INT >= 31) {
            try { return c.getColor(android.R.color.system_accent1_500) } catch (e: Throwable) { }
        }
        return Prefs.accent
    }

    fun amoled(): Boolean = try { Prefs.theme == 3 } catch (e: Throwable) { false }

    /** Scales a design radius by the user's corner setting (24 dp = as designed). */
    fun corner(dp: Float): Float = dp * (try { Prefs.cornerDp } catch (e: Throwable) { 24 }) / 24f

    /** Icon corner radius for an icon of [sizePx]: circle, squircle, rounded square or none. */
    fun iconRadius(sizePx: Float): Float = when (try { Prefs.iconShape } catch (e: Throwable) { 2 }) {
        0 -> sizePx / 2f
        1 -> sizePx * 0.3f
        2 -> sizePx * 0.225f
        else -> 0f
    }

    val PRESETS = listOf("iOS Glass", "AMOLED", "Sáng", "Mono")

    /** Sets every theme field at once. */
    fun applyPreset(i: Int) {
        when (i) {
            0 -> set(0, 0, 0xFF0A84FF.toInt(), 24, 2, 0.30f, 40, 0, 0)
            1 -> set(3, 0, 0xFF0A84FF.toInt(), 24, 2, 0.55f, 40, 0, 1)
            2 -> set(1, 0, 0xFF0A84FF.toInt(), 22, 1, 0.45f, 40, 0, 0)
            else -> set(0, 0, Color.rgb(142, 142, 147), 14, 3, 0.70f, 36, 2, 2)
        }
    }

    private fun set(
        theme: Int, accentMode: Int, accent: Int, corner: Int, icon: Int, glass: Float,
        iconSize: Int, font: Int, rim: Int
    ) {
        Prefs.iconSizeDp = iconSize
        Prefs.fontFamily = font
        Prefs.rimStyle = rim
        Prefs.theme = theme
        Prefs.accentMode = accentMode
        Prefs.accent = accent
        Prefs.cornerDp = corner
        Prefs.iconShape = icon
        Prefs.glass = glass
    }
}

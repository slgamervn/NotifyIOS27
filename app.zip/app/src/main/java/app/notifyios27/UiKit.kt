package app.notifyios27

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ColorFilter
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.Rect
import android.graphics.Outline
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.Drawable
import android.graphics.drawable.LayerDrawable
import android.net.Uri
import android.os.Build
import android.os.PowerManager
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.ViewOutlineProvider
import android.view.WindowInsets
import android.view.WindowInsetsController
import android.view.WindowManager
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

object UiKit {
    val ACCENT: Int = Color.parseColor("#0A84FF")
    val RED: Int = Color.parseColor("#FF3B30")
    val GREEN: Int = Color.parseColor("#34C759")
    val ORANGE: Int = Color.parseColor("#FF9F0A")


    /** Card explaining how to allow restricted settings for sideloaded apps. */
    fun restrictedCard(c: Context, dark: Boolean): View {
        val card = LinearLayout(c)
        card.orientation = LinearLayout.VERTICAL
        card.background = glass(c, 22f)
        card.setPadding(dp(c, 16), dp(c, 14), dp(c, 16), dp(c, 14))
        val t = TextView(c)
        t.text = "Không bật được quyền? Android chặn app cài ngoài Play Store: " +
            "Cài đặt > Ứng dụng > notifyIOS27 > menu ba chấm > Cho phép cài đặt bị hạn chế"
        t.textSize = 14f
        t.setTextColor(primary(dark))
        card.addView(t, LinearLayout.LayoutParams(
            android.view.ViewGroup.LayoutParams.MATCH_PARENT, android.view.ViewGroup.LayoutParams.WRAP_CONTENT
        ))
        val b = pillButton(c, "Mở thông tin ứng dụng", true)
        b.setOnClickListener {
            safeStart(c, Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + c.packageName)))
        }
        val lp = LinearLayout.LayoutParams(
            android.view.ViewGroup.LayoutParams.MATCH_PARENT, android.view.ViewGroup.LayoutParams.WRAP_CONTENT
        )
        lp.topMargin = dp(c, 10)
        card.addView(b, lp)
        return card
    }

    /** Smaller side of the screen in px (stable across rotation). */
    fun smallSide(c: Context): Int {
        val m = c.resources.displayMetrics
        return Math.min(m.widthPixels, m.heightPixels)
    }

    /** Full display size (w, h) in px: WindowMetrics on API 30+, real metrics below. */
    @Suppress("DEPRECATION")
    fun screenSize(c: Context): IntArray {
        try {
            val wm = c.getSystemService(Context.WINDOW_SERVICE) as WindowManager
            if (Build.VERSION.SDK_INT >= 30) {
                val b = wm.maximumWindowMetrics.bounds
                if (b.width() > 0 && b.height() > 0) return intArrayOf(b.width(), b.height())
            } else {
                val m = android.util.DisplayMetrics()
                wm.defaultDisplay.getRealMetrics(m)
                if (m.widthPixels > 0) return intArrayOf(m.widthPixels, m.heightPixels)
            }
        } catch (e: Throwable) {
        }
        val m = c.resources.displayMetrics
        return intArrayOf(m.widthPixels, m.heightPixels)
    }

    fun isLandscape(c: Context): Boolean {
        val m = c.resources.displayMetrics
        return m.widthPixels > m.heightPixels
    }

    /** Safe insets (systemBars + displayCutout) as l, t, r, b in px; never throws. */
    fun safeInsets(c: Context): IntArray {
        try {
            if (Build.VERSION.SDK_INT >= 30) {
                val wm = c.getSystemService(Context.WINDOW_SERVICE) as WindowManager
                val i = wm.currentWindowMetrics.windowInsets.getInsetsIgnoringVisibility(
                    WindowInsets.Type.systemBars() or WindowInsets.Type.displayCutout()
                )
                return intArrayOf(i.left, i.top, i.right, i.bottom)
            }
        } catch (e: Throwable) {
        }
        var top = 0
        try {
            val id = c.resources.getIdentifier("status_bar_height", "dimen", "android")
            if (id > 0) top = c.resources.getDimensionPixelSize(id)
        } catch (e: Throwable) {
        }
        return intArrayOf(0, top, 0, 0)
    }

    fun dp(c: Context, v: Int): Int = (v * c.resources.displayMetrics.density + 0.5f).toInt()
    fun dpf(c: Context, v: Float): Float = v * c.resources.displayMetrics.density

    fun primary(dark: Boolean): Int = if (dark) Color.WHITE else Color.parseColor("#1C1C1E")
    fun secondary(dark: Boolean): Int =
        if (dark) Color.argb(170, 255, 255, 255) else Color.argb(150, 60, 60, 67)

    fun wallpaper(dark: Boolean): FlatDrawable =
        FlatDrawable(if (dark) Color.parseColor("#15161A") else Color.parseColor("#E9E9EE"), 0f)

    fun rounded(c: Context, color: Int, radiusDp: Float): FlatDrawable =
        FlatDrawable(color, dpf(c, radiusDp))

    /** Flat fill with an optional hairline stroke; [oval] draws a circle. */
    fun flat(c: Context, color: Int, radiusDp: Float, strokeColor: Int = 0, strokeDp: Float = 1f, oval: Boolean = false): FlatDrawable {
        val d = FlatDrawable(color, dpf(c, radiusDp), oval)
        if (strokeColor != 0) d.setStroke(Math.max(1f, dpf(c, strokeDp)), strokeColor)
        return d
    }

    /** Liquid Glass fill (drawn by [Glass]); alphaMul scales the whole drawable. */
    fun glass(c: Context, radiusDp: Float = 24f, alphaMul: Float = 1f): Drawable {
        val d = Glass.drawable(c, radiusDp)
        if (alphaMul < 0.999f) d.alpha = (alphaMul * 255f).toInt().coerceIn(0, 255)
        return d
    }

    // ---- v2 ----

    fun accent(c: Context): Int = try { Theme.accent(c) } catch (e: Throwable) { ACCENT }

    /** Six flat tones; index 0 follows light / dark. Each array holds one colour. */
    fun presetWallpapers(): List<Pair<String, IntArray>> = listOf(
        Pair("Mặc định", intArrayOf(Color.parseColor("#15161A"))),
        Pair("Cát", intArrayOf(Color.parseColor("#D8CFC4"))),
        Pair("Biển", intArrayOf(Color.parseColor("#1F3B4D"))),
        Pair("Rêu", intArrayOf(Color.parseColor("#3C4A3E"))),
        Pair("Sương", intArrayOf(Color.parseColor("#DDE3EA"))),
        Pair("Than", intArrayOf(Color.parseColor("#0B0B0D")))
    )

    private var wpPath: String? = null
    private var wpMod: Long = 0L
    private var wpBmp: Bitmap? = null

    private fun loadWallpaperBitmap(path: String): Bitmap? {
        try {
            val f = java.io.File(path)
            if (!f.exists()) return null
            val mod = f.lastModified()
            val cached = wpBmp
            if (cached != null && wpPath == path && wpMod == mod) return cached
            val o = BitmapFactory.Options()
            o.inJustDecodeBounds = true
            BitmapFactory.decodeFile(path, o)
            if (o.outWidth <= 0 || o.outHeight <= 0) return null
            var sample = 1
            val cap = if (Perf.lite) 1080 else 1600
            while (Math.max(o.outWidth, o.outHeight) / sample > cap) sample *= 2
            val o2 = BitmapFactory.Options()
            o2.inSampleSize = sample
            val bmp = BitmapFactory.decodeFile(path, o2) ?: return null
            wpPath = path
            wpMod = mod
            wpBmp = bmp
            return bmp
        } catch (e: Throwable) {
            return null
        }
    }

    /** Wallpaper from Prefs (custom image or one of the 6 presets); a missing image falls back to preset 0. */
    fun wallpaper(c: Context): Drawable {
        val dark = try { Prefs.isDark(c) } catch (e: Throwable) { false }
        try {
            if (Prefs.wallpaperMode == 1) {
                val p = Prefs.wallpaperPath
                if (p.isNotBlank()) {
                    val bmp = loadWallpaperBitmap(p)
                    if (bmp != null) {
                        val veil = ColorDrawable(if (dark) Color.argb(110, 0, 0, 0) else Color.argb(60, 255, 255, 255))
                        return LayerDrawable(arrayOf<Drawable>(CenterCropDrawable(bmp), veil))
                    }
                }
            }
            val idx = Prefs.wallpaperIndex.coerceIn(0, 5)
            if (Theme.amoled()) return FlatDrawable(Color.BLACK, 0f)
            if (idx == 0) return wallpaper(dark)
            return FlatDrawable(presetWallpapers()[idx].second[0], 0f)
        } catch (e: Throwable) {
            return wallpaper(dark)
        }
    }

    private class CenterCropDrawable(private val bmp: Bitmap) : Drawable() {
        private val paint = Paint(Paint.FILTER_BITMAP_FLAG or Paint.ANTI_ALIAS_FLAG)
        private val m = Matrix()

        override fun onBoundsChange(b: Rect) {
            super.onBoundsChange(b)
            val bw = bmp.width.toFloat()
            val bh = bmp.height.toFloat()
            if (bw <= 0f || bh <= 0f || b.width() <= 0 || b.height() <= 0) return
            val s = Math.max(b.width() / bw, b.height() / bh)
            m.reset()
            m.postScale(s, s)
            m.postTranslate(b.left + (b.width() - bw * s) / 2f, b.top + (b.height() - bh * s) / 2f)
        }

        override fun draw(canvas: Canvas) {
            val b = bounds
            if (b.width() <= 0 || b.height() <= 0) return
            canvas.save()
            canvas.clipRect(b)
            canvas.drawBitmap(bmp, m, paint)
            canvas.restore()
        }

        override fun setAlpha(alpha: Int) {
            paint.alpha = alpha
            invalidateSelf()
        }

        override fun setColorFilter(colorFilter: ColorFilter?) {
            paint.colorFilter = colorFilter
            invalidateSelf()
        }

        @Suppress("OVERRIDE_DEPRECATION")
        override fun getOpacity(): Int = PixelFormat.OPAQUE
    }

    fun pillButton(c: Context, text: String, filled: Boolean): TextView {
        val dark = Prefs.isDark(c)
        val t = TextView(c)
        t.text = text
        t.textSize = 13.5f
        t.gravity = Gravity.CENTER
        t.setPadding(dp(c, 14), dp(c, 9), dp(c, 14), dp(c, 9))
        t.setTextColor(if (filled) Color.WHITE else primary(dark))
        t.typeface = android.graphics.Typeface.DEFAULT_BOLD
        t.background = rounded(
            c,
            if (filled) accent(c) else if (dark) Color.argb(50, 255, 255, 255) else Color.argb(40, 0, 0, 0),
            20f
        )
        t.isClickable = true
        return t
    }

    fun roundedIcon(c: Context, sizeDp: Int): ImageView {
        val iv = ImageView(c)
        iv.scaleType = ImageView.ScaleType.CENTER_CROP
        iv.outlineProvider = object : ViewOutlineProvider() {
            override fun getOutline(view: View, outline: Outline) {
                outline.setRoundRect(0, 0, view.width, view.height, Theme.iconRadius(Math.min(view.width, view.height).toFloat()))
            }
        }
        iv.clipToOutline = true
        return iv
    }

    fun bindIcon(iv: ImageView, pkg: String) {
        val d = AppIcons.icon(iv.context, pkg)
        iv.setImageDrawable(d)
        iv.setBackgroundColor(if (d == null) Color.argb(90, 128, 128, 128) else Color.TRANSPARENT)
    }

    fun iconView(c: Context, pkg: String, sizeDp: Int): ImageView {
        val iv = roundedIcon(c, sizeDp)
        bindIcon(iv, pkg)
        return iv
    }

    fun relativeTime(time: Long): String {
        val diff = System.currentTimeMillis() - time
        val min = diff / 60000L
        return when {
            diff < 60000L -> "bây giờ"
            min < 60L -> "$min phút"
            min < 60L * 24L -> "${min / 60L} giờ"
            min < 60L * 48L -> "hôm qua"
            else -> "${min / (60L * 24L)} ngày"
        }
    }

    fun notifAccessGranted(c: Context): Boolean {
        val flat = Settings.Secure.getString(c.contentResolver, "enabled_notification_listeners") ?: return false
        return flat.contains(c.packageName)
    }

    fun batteryIgnored(c: Context): Boolean {
        val pm = c.getSystemService(Context.POWER_SERVICE) as PowerManager
        return pm.isIgnoringBatteryOptimizations(c.packageName)
    }

    fun safeStart(c: Context, i: Intent) {
        try {
            if (c !is Activity) i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            c.startActivity(i)
        } catch (e: Exception) {
            Toast.makeText(c, "Không thể mở màn hình cài đặt", Toast.LENGTH_SHORT).show()
        }
    }

    fun openNotifAccess(c: Context) =
        safeStart(c, Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))

    fun openOverlay(c: Context) =
        safeStart(c, Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + c.packageName)))

    fun openBattery(c: Context) =
        safeStart(c, Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))

    /** Edge-to-edge window + status/nav icon colours; insets are handed to [onInsets] (l, t, r, b). */
    @Suppress("DEPRECATION")
    fun edgeToEdge(a: Activity, root: View, dark: Boolean, onInsets: (Int, Int, Int, Int) -> Unit) {
        val w = a.window
        w.statusBarColor = Color.TRANSPARENT
        w.navigationBarColor = Color.TRANSPARENT
        if (Build.VERSION.SDK_INT >= 29) w.isNavigationBarContrastEnforced = false
        if (Build.VERSION.SDK_INT >= 30) {
            w.setDecorFitsSystemWindows(false)
            val mask = WindowInsetsController.APPEARANCE_LIGHT_STATUS_BARS or
                WindowInsetsController.APPEARANCE_LIGHT_NAVIGATION_BARS
            w.insetsController?.setSystemBarsAppearance(if (dark) 0 else mask, mask)
        } else {
            var f = View.SYSTEM_UI_FLAG_LAYOUT_STABLE or
                View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or
                View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
            if (!dark) f = f or View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR or View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR
            w.decorView.systemUiVisibility = f
        }
        root.setOnApplyWindowInsetsListener { _, ins ->
            if (Build.VERSION.SDK_INT >= 30) {
                val b = ins.getInsets(WindowInsets.Type.systemBars() or WindowInsets.Type.displayCutout())
                onInsets(b.left, b.top, b.right, b.bottom)
            } else {
                onInsets(
                    ins.systemWindowInsetLeft, ins.systemWindowInsetTop,
                    ins.systemWindowInsetRight, ins.systemWindowInsetBottom
                )
            }
            ins
        }
        root.requestApplyInsets()
    }
}

/** Flat rounded fill (or circle) with an optional hairline stroke. No gradients. */
class FlatDrawable(color: Int, var radius: Float, private val oval: Boolean = false) : Drawable() {
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val stroke = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rect = android.graphics.RectF()
    private var strokeW = 0f
    private var gAlpha = 255
    private val baseA: Int
    private var strokeA = 0

    init {
        paint.color = color
        baseA = Color.alpha(color)
        stroke.style = Paint.Style.STROKE
    }

    fun setStroke(widthPx: Float, color: Int) {
        strokeW = widthPx
        stroke.strokeWidth = widthPx
        stroke.color = color
        strokeA = Color.alpha(color)
        invalidateSelf()
    }

    override fun draw(canvas: Canvas) {
        val b = bounds
        if (b.width() <= 0 || b.height() <= 0) return
        val h = strokeW / 2f
        rect.set(b.left + h, b.top + h, b.right - h, b.bottom - h)
        paint.alpha = baseA * gAlpha / 255
        if (oval) canvas.drawOval(rect, paint)
        else if (radius <= 0f) canvas.drawRect(b, paint)
        else canvas.drawRoundRect(rect, radius, radius, paint)
        if (strokeW > 0f) {
            stroke.alpha = strokeA * gAlpha / 255
            if (oval) canvas.drawOval(rect, stroke) else canvas.drawRoundRect(rect, radius, radius, stroke)
        }
    }

    override fun setAlpha(alpha: Int) {
        gAlpha = alpha.coerceIn(0, 255)
        invalidateSelf()
    }

    override fun setColorFilter(colorFilter: ColorFilter?) {
        paint.colorFilter = colorFilter
        invalidateSelf()
    }

    @Suppress("OVERRIDE_DEPRECATION")
    override fun getOpacity(): Int = PixelFormat.TRANSLUCENT
}

/** Vertical column that never gets wider than [maxDp]; place it with gravity CENTER_HORIZONTAL in a FrameLayout/ScrollView. */
class N27MaxWidthColumn(c: Context, private val maxDp: Int = 640) : LinearLayout(c) {
    init {
        orientation = LinearLayout.VERTICAL
    }

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        val max = (maxDp * resources.displayMetrics.density + 0.5f).toInt()
        val size = MeasureSpec.getSize(widthMeasureSpec)
        val mode = MeasureSpec.getMode(widthMeasureSpec)
        val spec = if (mode != MeasureSpec.UNSPECIFIED && size > max) {
            MeasureSpec.makeMeasureSpec(max, MeasureSpec.EXACTLY)
        } else {
            widthMeasureSpec
        }
        super.onMeasure(spec, heightMeasureSpec)
    }
}

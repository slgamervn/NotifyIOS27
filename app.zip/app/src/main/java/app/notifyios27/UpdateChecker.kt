package app.notifyios27

import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings
import android.widget.Toast
import androidx.core.content.FileProvider
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.Executors

object UpdateChecker {
    private const val UPDATES_URL = "https://notifyios27-slg-7f71.vercel.app/updates.json"
    private val executor = Executors.newSingleThreadExecutor()

    fun check(activity: Activity) {
        executor.execute {
            try {
                val conn = URL(UPDATES_URL).openConnection() as HttpURLConnection
                conn.connectTimeout = 8000
                conn.readTimeout = 8000
                conn.requestMethod = "GET"
                if (conn.responseCode != 200) return@execute
                val json = conn.inputStream.bufferedReader().use { it.readText() }
                val obj = JSONObject(json)
                val remoteCode = obj.optInt("versionCode", 0)
                val remoteName = obj.optString("versionName", "")
                val url = obj.optString("url", "")
                val notes = obj.optString("notes", "")
                val force = obj.optBoolean("force", false)
                val current = try {
                    val pi = activity.packageManager.getPackageInfo(activity.packageName, 0)
                    if (android.os.Build.VERSION.SDK_INT >= 28) pi.longVersionCode.toInt() else pi.versionCode
                } catch (_: Exception) { 0 }
                if (remoteCode <= current || url.isEmpty()) return@execute

                activity.runOnUiThread {
                    showDialog(activity, remoteName, notes, url, force)
                }
            } catch (_: Throwable) {
                // silent
            }
        }
    }

    private fun showDialog(activity: Activity, name: String, notes: String, url: String, force: Boolean) {
        if (activity.isFinishing) return
        val msg = if (notes.isNotEmpty()) notes else "Có bản mới $name."
        val builder = AlertDialog.Builder(activity)
            .setTitle("Cập nhật $name")
            .setMessage(msg)
            .setPositiveButton("Tải và cài") { _, _ -> downloadAndInstall(activity, url) }
        if (!force) {
            builder.setNegativeButton("Để sau", null)
        }
        builder.setCancelable(!force).show()
    }

    private fun downloadAndInstall(activity: Activity, url: String) {
        Toast.makeText(activity, "Đang tải bản mới…", Toast.LENGTH_SHORT).show()
        executor.execute {
            try {
                val conn = URL(url).openConnection() as HttpURLConnection
                conn.connectTimeout = 15000
                conn.readTimeout = 30000
                conn.instanceFollowRedirects = true
                if (conn.responseCode != 200) throw Exception("HTTP ${conn.responseCode}")
                val file = File(activity.cacheDir, "update.apk")
                conn.inputStream.use { input ->
                    FileOutputStream(file).use { output -> input.copyTo(output) }
                }
                activity.runOnUiThread { install(activity, file) }
            } catch (e: Throwable) {
                activity.runOnUiThread {
                    Toast.makeText(activity, "Không tải được: ${e.message}", Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    private fun install(activity: Activity, file: File) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O && !activity.packageManager.canRequestPackageInstalls()) {
            val intent = Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES)
                .setData(Uri.parse("package:${activity.packageName}"))
            activity.startActivity(intent)
            Toast.makeText(activity, "Hãy cho phép cài từ nguồn này rồi thử lại", Toast.LENGTH_LONG).show()
            return
        }
        val uri = FileProvider.getUriForFile(activity, "${activity.packageName}.provider", file)
        val intent = Intent(Intent.ACTION_VIEW)
            .setDataAndType(uri, "application/vnd.android.package-archive")
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        try {
            activity.startActivity(intent)
        } catch (e: Throwable) {
            Toast.makeText(activity, "Không mở được trình cài", Toast.LENGTH_SHORT).show()
        }
    }
}

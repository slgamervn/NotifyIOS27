@file:Suppress("DEPRECATION")
package app.notifyios27

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings
import android.widget.Toast
import androidx.core.content.FileProvider
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.security.MessageDigest
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean

object UpdateChecker {
    private const val UPDATES_URL = "https://notifyios27-slg-7f71.vercel.app/updates.json"
    private const val APK_NAME = "notifyIOS27-release.apk"
    private const val CHECKSUMS_NAME = "SHA256SUMS.txt"
    private const val MAX_CHECKSUM_BYTES = 16L * 1024L
    private const val MAX_APK_BYTES = 100L * 1024L * 1024L

    private val executor = Executors.newSingleThreadExecutor()
    private val checking = AtomicBoolean(false)

    fun check(activity: Activity) {
        if (!checking.compareAndSet(false, true)) return
        executor.execute {
            var conn: HttpURLConnection? = null
            try {
                if (activity.isFinishing || activity.isDestroyed) return@execute
                conn = URL(UPDATES_URL).openConnection() as HttpURLConnection
                conn.connectTimeout = 8000
                conn.readTimeout = 8000
                conn.requestMethod = "GET"
                conn.useCaches = false
                if (conn.responseCode != HttpURLConnection.HTTP_OK) return@execute

                val json = conn.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
                val obj = JSONObject(json)
                val remoteCode = obj.optLong("versionCode", 0L)
                val remoteName = obj.optString("versionName", "").trim()
                val url = obj.optString("url", "").trim()
                val notes = obj.optString("notes", "")
                val force = obj.optBoolean("force", false)

                if (remoteCode < 1L || remoteName.isEmpty() || !isTrustedReleaseUrl(url)) return@execute

                val appContext = activity.applicationContext
                val currentCode = try {
                    val info = appContext.packageManager.getPackageInfo(appContext.packageName, 0)
                    if (Build.VERSION.SDK_INT >= 28) info.longVersionCode else info.versionCode.toLong()
                } catch (_: Exception) {
                    return@execute
                }
                if (remoteCode <= currentCode) return@execute

                activity.runOnUiThread {
                    if (!activity.isFinishing && !activity.isDestroyed) {
                        showDialog(activity, remoteName, notes, url, force, remoteCode)
                    }
                }
            } catch (_: Throwable) {
                // Update checks are best-effort; the installed app remains usable offline.
            } finally {
                conn?.disconnect()
                checking.set(false)
            }
        }
    }

    private fun isTrustedReleaseUrl(raw: String): Boolean {
        val uri = try {
            Uri.parse(raw)
        } catch (_: Exception) {
            return false
        }
        val path = uri.pathSegments
        return uri.scheme.equals("https", ignoreCase = true) &&
            uri.host.equals("github.com", ignoreCase = true) &&
            uri.userInfo == null &&
            (uri.port == -1 || uri.port == 443) &&
            uri.query == null &&
            uri.fragment == null &&
            path.size == 6 &&
            path[0] == "slgamervn" &&
            path[1].equals("NotifyIOS27", ignoreCase = true) &&
            path[2] == "releases" &&
            path[3] == "download" &&
            path[4].isNotBlank() &&
            path[5] == APK_NAME
    }

    private fun showDialog(activity: Activity, name: String, notes: String, url: String, force: Boolean, expectedVersionCode: Long) {
        if (activity.isFinishing || activity.isDestroyed) return
        val msg = if (notes.isNotEmpty()) notes else "Có bản mới " + name + "."
        val dialog = AlertDialog.Builder(activity)
            .setTitle("Cập nhật " + name)
            .setMessage(msg)
            .setPositiveButton("Tải và cài") { _, _ -> downloadAndInstall(activity, url, expectedVersionCode) }
            .apply {
                if (!force) setNegativeButton("Để sau", null)
                setCancelable(!force)
            }
            .create()
        dialog.show()
    }

    private fun readExpectedChecksum(apkUrl: String): String {
        val checksumUrl = apkUrl.substringBeforeLast('/') + "/" + CHECKSUMS_NAME
        var conn: HttpURLConnection? = null
        try {
            conn = URL(checksumUrl).openConnection() as HttpURLConnection
            conn.connectTimeout = 15000
            conn.readTimeout = 15000
            conn.requestMethod = "GET"
            conn.instanceFollowRedirects = true
            conn.useCaches = false
            if (conn.responseCode != HttpURLConnection.HTTP_OK) {
                throw IOException("Không tải được tệp kiểm tra SHA-256.")
            }
            if (conn.contentLengthLong > MAX_CHECKSUM_BYTES) {
                throw IOException("Tệp kiểm tra SHA-256 quá lớn.")
            }

            var bytesRead = 0L
            var expected: String? = null
            conn.inputStream.bufferedReader(Charsets.US_ASCII).use { reader ->
                while (true) {
                    val line = reader.readLine() ?: break
                    bytesRead += line.length + 1L
                    if (bytesRead > MAX_CHECKSUM_BYTES) {
                        throw IOException("Tệp kiểm tra SHA-256 quá lớn.")
                    }
                    val columns = line.trim().split(Regex("\\s+"))
                    if (columns.size == 2 &&
                        (columns[1] == APK_NAME || columns[1] == "*" + APK_NAME)
                    ) {
                        if (expected != null) throw IOException("Tệp kiểm tra có mục APK trùng lặp.")
                        val candidate = columns[0]
                        if (!candidate.matches(Regex("[0-9a-fA-F]{64}"))) {
                            throw IOException("Mã SHA-256 trong Release không hợp lệ.")
                        }
                        expected = candidate
                    }
                }
            }
            return expected ?: throw IOException("Release thiếu SHA256SUMS.txt cho APK.")
        } finally {
            conn?.disconnect()
        }
    }

    private fun downloadAndInstall(activity: Activity, url: String, expectedVersionCode: Long) {
        if (!isTrustedReleaseUrl(url)) {
            Toast.makeText(activity, "Nguồn cập nhật không hợp lệ.", Toast.LENGTH_LONG).show()
            return
        }
        Toast.makeText(activity, "Đang tải và kiểm tra bản mới…", Toast.LENGTH_SHORT).show()
        executor.execute {
            val updateDir = File(activity.cacheDir, "updates")
            val partial = File(updateDir, "update.apk.part")
            var conn: HttpURLConnection? = null
            try {
                if (!updateDir.exists() && !updateDir.mkdirs()) {
                    throw IOException("Không tạo được thư mục cập nhật.")
                }
                val expectedHash = readExpectedChecksum(url)
                conn = URL(url).openConnection() as HttpURLConnection
                conn.connectTimeout = 15000
                conn.readTimeout = 30000
                conn.instanceFollowRedirects = true
                conn.useCaches = false
                if (conn.responseCode != HttpURLConnection.HTTP_OK) {
                    throw IOException("Tải APK thất bại: HTTP " + conn.responseCode)
                }

                val declaredSize = conn.contentLengthLong
                if (declaredSize == 0L || declaredSize > MAX_APK_BYTES) {
                    throw IOException("Kích thước APK không hợp lệ.")
                }

                if (partial.exists() && !partial.delete()) {
                    throw IOException("Không thể dọn tệp tải dở.")
                }

                val digest = MessageDigest.getInstance("SHA-256")
                var total = 0L
                conn.inputStream.use { input ->
                    FileOutputStream(partial).use { output ->
                        val buffer = ByteArray(8192)
                        while (true) {
                            val count = input.read(buffer)
                            if (count < 0) break
                            if (count == 0) continue
                            total += count
                            if (total > MAX_APK_BYTES) {
                                throw IOException("APK vượt quá giới hạn kích thước.")
                            }
                            digest.update(buffer, 0, count)
                            output.write(buffer, 0, count)
                        }
                    }
                }

                if (total == 0L || (declaredSize > 0L && total != declaredSize)) {
                    throw IOException("Tệp APK tải về không đầy đủ.")
                }

                val actualHash = digest.digest().joinToString("") {
                    (it.toInt() and 0xff).toString(16).padStart(2, '0')
                }
                if (!actualHash.equals(expectedHash, ignoreCase = true)) {
                    throw IOException("Mã SHA-256 không khớp. Đã chặn cài đặt.")
                }

                val archiveInfo = activity.packageManager.getPackageArchiveInfo(partial.absolutePath, 0)
                    ?: throw IOException("Tệp tải về không phải APK hợp lệ.")
                if (archiveInfo.packageName != activity.packageName) {
                    throw IOException("APK không thuộc ứng dụng NotifyIOS27.")
                }
                val archiveVersionCode = if (Build.VERSION.SDK_INT >= 28) {
                    archiveInfo.longVersionCode
                } else {
                    archiveInfo.versionCode.toLong()
                }
                if (archiveVersionCode != expectedVersionCode) {
                    throw IOException("Version của APK không khớp với thông tin bản cập nhật.")
                }
                val installedInfo = activity.packageManager.getPackageInfo(activity.packageName, 0)
                val installedVersionCode = if (Build.VERSION.SDK_INT >= 28) {
                    installedInfo.longVersionCode
                } else {
                    installedInfo.versionCode.toLong()
                }
                if (archiveVersionCode <= installedVersionCode) {
                    throw IOException("APK không phải phiên bản mới hơn bản đang cài.")
                }

                val file = File(updateDir, "update.apk")
                if (file.exists() && !file.delete()) {
                    throw IOException("Không thể thay thế tệp cập nhật cũ.")
                }
                if (!partial.renameTo(file)) {
                    partial.copyTo(file, overwrite = true)
                    partial.delete()
                }

                activity.runOnUiThread {
                    if (activity.isFinishing || activity.isDestroyed) {
                        file.delete()
                    } else {
                        install(activity, file)
                    }
                }
            } catch (e: Throwable) {
                partial.delete()
                activity.runOnUiThread {
                    if (!activity.isFinishing && !activity.isDestroyed) {
                        Toast.makeText(
                            activity,
                            "Không thể tải hoặc xác minh bản cập nhật: " + e.message,
                            Toast.LENGTH_LONG
                        ).show()
                    }
                }
            } finally {
                conn?.disconnect()
            }
        }
    }

    private fun install(activity: Activity, file: File) {
        if (activity.isFinishing || activity.isDestroyed || !file.isFile || file.length() == 0L) return
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O && !activity.packageManager.canRequestPackageInstalls()) {
            val intent = Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES)
                .setData(Uri.parse("package:" + activity.packageName))
            activity.startActivity(intent)
            Toast.makeText(activity, "Hãy cho phép cài từ nguồn này rồi thử lại.", Toast.LENGTH_LONG).show()
            return
        }

        val uri = FileProvider.getUriForFile(activity, activity.packageName + ".provider", file)
        val intent = Intent(Intent.ACTION_VIEW)
            .setDataAndType(uri, "application/vnd.android.package-archive")
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        try {
            activity.startActivity(intent)
        } catch (_: Throwable) {
            Toast.makeText(activity, "Không mở được trình cài Android.", Toast.LENGTH_SHORT).show()
        }
    }
}

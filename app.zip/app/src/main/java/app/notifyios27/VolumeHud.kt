package app.notifyios27

import android.app.Activity
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.database.ContentObserver
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.RectF
import android.media.AudioManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.LinearLayout

/** iOS 27 style volume HUD: a slim glass pill on the edge opposite the system panel. */
object VolumeHud {
    private const val ACTION = "android.media.VOLUME_CHANGED_ACTION"
    private const val EXTRA_TYPE = "android.media.EXTRA_VOLUME_STREAM_TYPE"

    private val main = Handler(Looper.getMainLooper())
    private var app: Context? = null
    private var started = false
    private var listening = false
    private var root: FrameLayout? = null
    private var pill: VolumePill? = null
    private var lp: WindowManager.LayoutParams? = null
    private var hiding = false
    private var stream = AudioManager.STREAM_MUSIC
    private var pendingStream = -1

    private val hideRun = Runnable { hide() }
    private val showRun = Runnable {
        val s = pendingStream
        pendingStream = -1
        if (s >= 0) showFor(s)
    }

    private val volReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            val t = intent?.getIntExtra(EXTRA_TYPE, -1) ?: -1
            changed(if (t >= 0) t else AudioManager.STREAM_MUSIC)
        }
    }

    private val observer = object : ContentObserver(main) {
        override fun onChange(selfChange: Boolean) {}

        override fun onChange(selfChange: Boolean, uri: android.net.Uri?) {
            // fallback for phones that do not send the broadcast; only volume keys count
            val k = uri?.lastPathSegment ?: return
            if (!k.startsWith("volume")) return
            if (pendingStream < 0) changed(stream)
        }
    }

    private val screenReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            when (intent?.action) {
                Intent.ACTION_SCREEN_ON -> listen(true)
                Intent.ACTION_SCREEN_OFF -> {
                    listen(false)
                    removeNow()
                }
            }
        }
    }

    fun start(c: Context) {
        val ctx = c.applicationContext ?: c
        main.post {
            app = ctx
            if (!started) {
                started = true
                try {
                    val f = IntentFilter()
                    f.addAction(Intent.ACTION_SCREEN_ON)
                    f.addAction(Intent.ACTION_SCREEN_OFF)
                    if (Build.VERSION.SDK_INT >= 33) ctx.registerReceiver(screenReceiver, f, Context.RECEIVER_NOT_EXPORTED)
                    else ctx.registerReceiver(screenReceiver, f)
                } catch (e: Throwable) {
                }
            }
            val pm = ctx.getSystemService(Context.POWER_SERVICE) as? PowerManager
            listen(pm?.isInteractive != false)
        }
    }

    /** Re-reads the switch; called from the settings page. */
    fun refresh(c: Context) = start(c)

    private fun listen(on: Boolean) {
        val ctx = app ?: return
        val want = on && Prefs.volumeHud
        if (want == listening) return
        listening = want
        if (want) {
            try {
                // sent by the system, which still reaches a not-exported receiver
                if (Build.VERSION.SDK_INT >= 33) ctx.registerReceiver(volReceiver, IntentFilter(ACTION), Context.RECEIVER_NOT_EXPORTED)
                else ctx.registerReceiver(volReceiver, IntentFilter(ACTION))
            } catch (e: Throwable) {
            }
            try {
                ctx.contentResolver.registerContentObserver(Settings.System.CONTENT_URI, true, observer)
            } catch (e: Throwable) {
            }
        } else {
            try { ctx.unregisterReceiver(volReceiver) } catch (e: Throwable) { }
            try { ctx.contentResolver.unregisterContentObserver(observer) } catch (e: Throwable) { }
            main.removeCallbacks(showRun)
        }
    }

    private fun changed(s: Int) {
        pendingStream = s
        main.removeCallbacks(showRun)
        main.postDelayed(showRun, 40L)
    }

    private fun audio(c: Context): AudioManager? = c.getSystemService(Context.AUDIO_SERVICE) as? AudioManager

    private fun showFor(s: Int) {
        val ctx = app ?: return
        if (!Prefs.volumeHud || !Prefs.appEnabled) return
        if (!(try { Settings.canDrawOverlays(ctx) } catch (e: Throwable) { false })) return
        val am = audio(ctx) ?: return
        stream = s
        val max = try { am.getStreamMaxVolume(s) } catch (e: Throwable) { 0 }
        if (max <= 0) return
        val cur = try { am.getStreamVolume(s) } catch (e: Throwable) { 0 }
        val p = ensure(ctx) ?: return
        if (!p.dragging) p.set(s, cur, max)
        main.removeCallbacks(hideRun)
        main.postDelayed(hideRun, 1800L)
    }

    private fun ensure(ctx: Context): VolumePill? {
        val existing = pill
        if (existing != null) {
            if (hiding) {
                hiding = false
                val r = root
                val l = lp
                if (r != null && l != null) {
                    l.flags = l.flags and WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE.inv()
                    try { (ctx.getSystemService(Context.WINDOW_SERVICE) as WindowManager).updateViewLayout(r, l) } catch (e: Throwable) { }
                }
                existing.animate().cancel()
                existing.animate().alpha(1f).translationX(0f).setDuration(Perf.dur(140L)).start()
            }
            return existing
        }
        return try {
            val wm = ctx.getSystemService(Context.WINDOW_SERVICE) as WindowManager
            val d = ctx.resources.displayMetrics.density
            val pw = (44 * d).toInt()
            val ph = (180 * d).toInt()
            val r = FrameLayout(ctx)
            r.clipChildren = false
            val p = VolumePill(ctx)
            p.onTouch = { down ->
                main.removeCallbacks(hideRun)
                if (!down) main.postDelayed(hideRun, 1800L)
            }
            p.onLevel = { idx ->
                try { audio(ctx)?.setStreamVolume(stream, idx, 0) } catch (e: SecurityException) { } catch (e: Throwable) { }
            }
            val pad = (pw * 0.1f).toInt() + 1
            r.setPadding(pad, (ph * 0.08f).toInt(), pad, (ph * 0.08f).toInt())
            r.addView(p, FrameLayout.LayoutParams(pw, ph, Gravity.CENTER))
            val side = Prefs.volumeSide
            val l = WindowManager.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                    WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT
            )
            l.gravity = (if (side == 1) Gravity.END else Gravity.START) or Gravity.CENTER_VERTICAL
            l.x = (8 * d).toInt() + UiKit.safeInsets(ctx).let { if (side == 1) it[2] else it[0] }
            wm.addView(r, l)
            root = r
            pill = p
            lp = l
            hiding = false
            val off = (if (side == 1) 1 else -1) * 24 * d
            p.alpha = 0f
            p.translationX = off
            p.animate().alpha(1f).translationX(0f).setDuration(Perf.dur(180L)).setInterpolator(Perf.SPRING_SOFT).start()
            p
        } catch (e: Throwable) {
            removeNow()
            null
        }
    }

    private fun hide() {
        val p = pill ?: return
        if (p.dragging) {
            main.postDelayed(hideRun, 1800L)
            return
        }
        val r = root
        val l = lp
        hiding = true
        if (r != null && l != null) {
            // no longer touchable while it fades
            l.flags = l.flags or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
            try { (r.context.getSystemService(Context.WINDOW_SERVICE) as WindowManager).updateViewLayout(r, l) } catch (e: Throwable) { }
        }
        val d = r?.resources?.displayMetrics?.density ?: 1f
        val off = (if (Prefs.volumeSide == 1) 1 else -1) * 24 * d
        p.animate().alpha(0f).translationX(off).setDuration(Perf.dur(200L)).withEndAction {
            if (hiding) removeNow()
        }.start()
    }

    fun removeNow() {
        main.removeCallbacks(hideRun)
        val r = root
        root = null
        pill?.animate()?.cancel()
        pill = null
        lp = null
        hiding = false
        if (r != null) {
            try { (r.context.getSystemService(Context.WINDOW_SERVICE) as WindowManager).removeViewImmediate(r) } catch (e: Throwable) { }
        }
    }
}

/** The pill itself: flat fill rising from the bottom and a code-drawn glyph. */
internal class VolumePill(c: Context) : View(c) {
    var onTouch: ((Boolean) -> Unit)? = null
    var onLevel: ((Int) -> Unit)? = null
    var dragging = false
        private set

    private val d = c.resources.displayMetrics.density
    private val dark = Prefs.isDark(c)
    private val fillP = Paint(Paint.ANTI_ALIAS_FLAG)
    private val glyphP = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rect = RectF()
    private val clip = Path()
    private val glyph = Path()
    private val arc = RectF()
    private var stream = AudioManager.STREAM_MUSIC
    private var level = 0
    private var max = 15
    private var shown = 0f

    init {
        background = Glass.drawable(c, 22f, true)
        fillP.color = if (dark) Color.WHITE else Color.rgb(28, 28, 30)
        glyphP.style = Paint.Style.STROKE
        glyphP.strokeWidth = 1.8f * d
        glyphP.strokeCap = Paint.Cap.ROUND
        glyphP.strokeJoin = Paint.Join.ROUND
    }

    fun set(s: Int, cur: Int, m: Int) {
        stream = s
        max = m.coerceAtLeast(1)
        level = cur.coerceIn(0, max)
        shown = level.toFloat() / max
        invalidate()
    }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        super.onSizeChanged(w, h, ow, oh)
        clip.reset()
        rect.set(0f, 0f, w.toFloat(), h.toFloat())
        val r = w / 2f
        clip.addRoundRect(rect, r, r, Path.Direction.CW)
    }

    override fun onDraw(canvas: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        if (w <= 0f || h <= 0f) return
        canvas.save()
        canvas.clipPath(clip)
        val top = h - h * shown
        fillP.alpha = if (dark) 235 else 230
        canvas.drawRect(0f, top, w, h, fillP)
        canvas.restore()
        // glyph sits near the bottom; it flips colour when the fill covers it
        val cy = h - w * 0.62f
        glyphP.color = if (top < cy) (if (dark) Color.rgb(28, 28, 30) else Color.WHITE) else (if (dark) Color.WHITE else Color.rgb(28, 28, 30))
        drawGlyph(canvas, w / 2f, cy, w * 0.2f)
    }

    private fun drawGlyph(cv: Canvas, cx: Float, cy: Float, s: Float) {
        glyph.reset()
        when (stream) {
            AudioManager.STREAM_RING, AudioManager.STREAM_NOTIFICATION, AudioManager.STREAM_SYSTEM -> {
                // bell
                glyph.moveTo(cx - s, cy + s * 0.6f)
                glyph.lineTo(cx + s, cy + s * 0.6f)
                glyph.moveTo(cx - s * 0.8f, cy + s * 0.6f)
                glyph.quadTo(cx - s * 0.8f, cy - s * 1.1f, cx, cy - s * 1.1f)
                glyph.quadTo(cx + s * 0.8f, cy - s * 1.1f, cx + s * 0.8f, cy + s * 0.6f)
                glyph.moveTo(cx - s * 0.25f, cy + s * 0.95f)
                glyph.lineTo(cx + s * 0.25f, cy + s * 0.95f)
                cv.drawPath(glyph, glyphP)
                if (level == 0) cv.drawLine(cx - s, cy - s, cx + s, cy + s, glyphP)
            }
            AudioManager.STREAM_ALARM -> {
                // alarm clock
                cv.drawCircle(cx, cy, s * 0.9f, glyphP)
                cv.drawLine(cx, cy, cx, cy - s * 0.5f, glyphP)
                cv.drawLine(cx, cy, cx + s * 0.4f, cy, glyphP)
                cv.drawLine(cx - s * 1.0f, cy - s * 0.8f, cx - s * 0.6f, cy - s * 1.1f, glyphP)
                cv.drawLine(cx + s * 1.0f, cy - s * 0.8f, cx + s * 0.6f, cy - s * 1.1f, glyphP)
            }
            else -> {
                // speaker; waves by level: mute, low, mid, high
                val x0 = cx - s * 1.1f
                glyph.moveTo(x0, cy - s * 0.35f)
                glyph.lineTo(x0 + s * 0.45f, cy - s * 0.35f)
                glyph.lineTo(x0 + s * 0.95f, cy - s * 0.8f)
                glyph.lineTo(x0 + s * 0.95f, cy + s * 0.8f)
                glyph.lineTo(x0 + s * 0.45f, cy + s * 0.35f)
                glyph.lineTo(x0, cy + s * 0.35f)
                glyph.close()
                cv.drawPath(glyph, glyphP)
                val f = level.toFloat() / max
                if (level == 0) {
                    cv.drawLine(cx + s * 0.25f, cy - s * 0.35f, cx + s * 0.95f, cy + s * 0.35f, glyphP)
                    cv.drawLine(cx + s * 0.95f, cy - s * 0.35f, cx + s * 0.25f, cy + s * 0.35f, glyphP)
                } else {
                    val waves = if (f < 0.34f) 1 else if (f < 0.67f) 2 else 3
                    for (i in 1..waves) {
                        val r = s * (0.35f + 0.38f * i)
                        arc.set(cx - r, cy - r, cx + r, cy + r)
                        cv.drawArc(arc, -40f, 80f, false, glyphP)
                    }
                }
            }
        }
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                dragging = true
                onTouch?.invoke(true)
                animate().scaleX(1.15f).scaleY(1.15f).setDuration(Perf.dur(120L)).start()
                track(e.y)
            }
            MotionEvent.ACTION_MOVE -> track(e.y)
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                dragging = false
                animate().scaleX(1f).scaleY(1f).setDuration(Perf.dur(160L)).start()
                onTouch?.invoke(false)
            }
        }
        return true
    }

    private fun track(y: Float) {
        val h = height.toFloat().coerceAtLeast(1f)
        val f = (1f - y / h).coerceIn(0f, 1f)
        shown = f
        val idx = Math.round(f * max)
        if (idx != level) {
            level = idx
            onLevel?.invoke(idx)
            if (Prefs.volumeHapticSteps) Perf.haptic(this, Perf.H_TICK)
        }
        invalidate()
    }
}

class VolumePage : SettingsPage {
    override val title: String = "Âm lượng"

    override fun build(a: Activity, push: (SettingsPage) -> Unit): View {
        val b = LinearLayout(a)
        b.orientation = LinearLayout.VERTICAL
        val s = SettingsKit.section(a, "Âm lượng")
        s.addView(SettingsKit.switchRow(a, "Thanh âm lượng kiểu iOS", null, Prefs.volumeHud) {
            Prefs.volumeHud = it
            if (!it) VolumeHud.removeNow()
            VolumeHud.refresh(a)
        })
        s.addView(SettingsKit.segmented(a, listOf("Cạnh trái", "Cạnh phải"), Prefs.volumeSide) {
            Prefs.volumeSide = it
            VolumeHud.removeNow()
        })
        s.addView(SettingsKit.switchRow(a, "Rung theo từng nấc", null, Prefs.volumeHapticSteps) {
            Prefs.volumeHapticSteps = it
        })
        s.addView(settingsCaption(a, "Android không cho ẩn bảng âm lượng của hệ thống, nên thanh này hiện ở cạnh đối diện."))
        b.addView(s, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        return b
    }
}
